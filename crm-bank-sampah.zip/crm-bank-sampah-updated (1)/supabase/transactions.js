/**
 * supabase/transactions.js
 * ------------------------------------------------------
 * Layanan CRUD untuk Transaksi Setoran Sampah
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Mengambil semua transaksi beserta nama nasabahnya
export async function getTransactions() {
  const { data, error } = await supabase
    .from("transactions")
    .select(`
      *,
      customers ( full_name )
    `)
    .order("created_at", { ascending: false });
    
  return { data, error };
}

// Menambah transaksi baru
export async function createTransaction(transactionData) {
  const { data, error } = await supabase
    .from("transactions")
    .insert([transactionData])
    .select();
    
  return { data, error };
}

// Memperbarui transaksi
export async function updateTransaction(id, transactionData) {
  const { data, error } = await supabase
    .from("transactions")
    .update(transactionData)
    .eq("id", id)
    .select();

  return { data, error };
}

// Menghapus transaksi
export async function deleteTransaction(id) {
  const { data, error } = await supabase
    .from("transactions")
    .delete()
    .eq("id", id);

  return { data, error };
}

// ==========================================
// ESTIMASI HARGA SAMPAH (waste_prices, dikelola Admin)
// ==========================================

export async function getWastePrices() {
  const { data, error } = await supabase
    .from("waste_prices")
    .select("*")
    .order("waste_type", { ascending: true });

  return { data, error };
}

export async function updateWastePrice(id, priceData) {
  const { data, error } = await supabase
    .from("waste_prices")
    .update({ ...priceData, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select();

  return { data, error };
}

// ==========================================
// SALDO DIGITAL: ringkasan saldo per nasabah
// (lifetime setoran selesai - penarikan disetujui)
// ==========================================

export async function getSaldoDigitalOverview() {
  try {
    const [
      { data: customers, error: errCust },
      { data: transactions, error: errTx },
      { data: withdrawals, error: errWd },
    ] = await Promise.all([
      supabase.from("customers").select("id, full_name, status"),
      supabase.from("transactions").select("customer_id, total_reward, status"),
      supabase.from("withdrawals").select("customer_id, amount, status"),
    ]);

    if (errCust) throw errCust;
    if (errTx) throw errTx;
    if (errWd) throw errWd;

    const earnedByCustomer = {};
    (transactions || [])
      .filter((tx) => tx.status === "Selesai")
      .forEach((tx) => {
        if (!tx.customer_id) return;
        earnedByCustomer[tx.customer_id] = (earnedByCustomer[tx.customer_id] || 0) + (parseFloat(tx.total_reward) || 0);
      });

    const withdrawnByCustomer = {};
    (withdrawals || [])
      .filter((w) => w.status === "Disetujui")
      .forEach((w) => {
        if (!w.customer_id) return;
        withdrawnByCustomer[w.customer_id] = (withdrawnByCustomer[w.customer_id] || 0) + (parseFloat(w.amount) || 0);
      });

    const overview = (customers || []).map((c) => {
      const earned = earnedByCustomer[c.id] || 0;
      const withdrawn = withdrawnByCustomer[c.id] || 0;
      return {
        id: c.id,
        name: c.full_name,
        status: c.status,
        totalEarned: earned,
        totalWithdrawn: withdrawn,
        currentBalance: Math.max(0, earned - withdrawn),
      };
    });

    return { data: overview.sort((a, b) => b.currentBalance - a.currentBalance), error: null };
  } catch (error) {
    return { data: [], error };
  }
}

// Khusus Portal Nasabah: saldo digital milik sendiri
export async function getMySaldoDigital(customerId) {
  try {
    const [
      { data: transactions, error: errTx },
      { data: withdrawals, error: errWd },
    ] = await Promise.all([
      supabase.from("transactions").select("total_reward, status").eq("customer_id", customerId),
      supabase.from("withdrawals").select("amount, status").eq("customer_id", customerId),
    ]);

    if (errTx) throw errTx;
    if (errWd) throw errWd;

    const totalEarned = (transactions || [])
      .filter((tx) => tx.status === "Selesai")
      .reduce((sum, tx) => sum + (parseFloat(tx.total_reward) || 0), 0);

    const totalWithdrawn = (withdrawals || [])
      .filter((w) => w.status === "Disetujui")
      .reduce((sum, w) => sum + (parseFloat(w.amount) || 0), 0);

    return { currentBalance: Math.max(0, totalEarned - totalWithdrawn), totalEarned, totalWithdrawn, error: null };
  } catch (error) {
    return { currentBalance: 0, totalEarned: 0, totalWithdrawn: 0, error };
  }
}

// ==========================================
// RIWAYAT PENARIKAN SALDO (withdrawals)
// ==========================================

export async function getWithdrawals() {
  const { data, error } = await supabase
    .from("withdrawals")
    .select(`*, customers ( full_name )`)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createWithdrawal(withdrawalData) {
  const { data, error } = await supabase
    .from("withdrawals")
    .insert([withdrawalData])
    .select();

  return { data, error };
}

export async function updateWithdrawal(id, withdrawalData) {
  const { data, error } = await supabase
    .from("withdrawals")
    .update(withdrawalData)
    .eq("id", id)
    .select();

  return { data, error };
}

export async function deleteWithdrawal(id) {
  const { data, error } = await supabase
    .from("withdrawals")
    .delete()
    .eq("id", id);

  return { data, error };
}

// Khusus Portal Nasabah: lihat & ajukan penarikan saldo milik sendiri
export async function getMyWithdrawals(customerId) {
  const { data, error } = await supabase
    .from("withdrawals")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function requestWithdrawal(withdrawalData) {
  const { data, error } = await supabase
    .from("withdrawals")
    .insert([{ ...withdrawalData, status: "Menunggu" }])
    .select();

  return { data, error };
}