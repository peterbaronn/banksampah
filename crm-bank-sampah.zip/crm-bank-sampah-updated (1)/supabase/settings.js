/**
 * supabase/settings.js
 * ------------------------------------------------------
 * Layanan untuk mengelola pengaturan akun, ubah nama, 
 * dan pembaruan password.
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Memperbarui nama lengkap di tabel profiles dan metadata auth
export async function updateProfileName(userId, newName) {
  // 1. Update ke tabel public.profiles
  const { data, error } = await supabase
    .from("profiles")
    .update({ full_name: newName })
    .eq("id", userId);

  // 2. Update juga ke metadata user Supabase agar tersinkronisasi
  if (!error) {
    await supabase.auth.updateUser({
      data: { full_name: newName }
    });
  }

  return { data, error };
}

// Memperbarui password user yang sedang login
export async function updatePassword(newPassword) {
  const { data, error } = await supabase.auth.updateUser({
    password: newPassword
  });
  
  return { data, error };
}