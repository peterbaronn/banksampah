/**
 * supabase/supabase.js
 * ------------------------------------------------------
 * Inisialisasi client Supabase.
 *
 * File ini HANYA bertugas membuat dan mengekspor instance
 * client Supabase. Query, autentikasi, dan CRUD akan
 * ditambahkan pada tahap pengembangan berikutnya.
 * ------------------------------------------------------
 */

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { CONFIG } from "../js/config.js";

export const supabase = createClient(
  CONFIG.SUPABASE_URL,
  CONFIG.SUPABASE_ANON_KEY
);

export default supabase;
