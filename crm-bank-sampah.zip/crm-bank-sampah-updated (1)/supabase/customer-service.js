/**
 * supabase/customer-service.js
 * ------------------------------------------------------
 * Layanan CRUD untuk Modul Customer Service (Tiket Bantuan)
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

export async function getCustomerServices() {
  const { data, error } = await supabase
    .from("customer_services")
    .select(`
      *,
      customers ( full_name )
    `)
    .order("created_at", { ascending: false });
    
  return { data, error };
}

export async function createCustomerService(serviceData) {
  const { data, error } = await supabase
    .from("customer_services")
    .insert([serviceData])
    .select();
  return { data, error };
}

export async function updateCustomerService(id, serviceData) {
  const { data, error } = await supabase
    .from("customer_services")
    .update(serviceData)
    .eq("id", id)
    .select();
  return { data, error };
}

export async function deleteCustomerService(id) {
  const { data, error } = await supabase
    .from("customer_services")
    .delete()
    .eq("id", id);
  return { data, error };
}

// ==========================================
// FAQ (dikelola Admin, ditampilkan di Portal Nasabah)
// ==========================================

export async function getFaqs(onlyPublished = false) {
  let query = supabase.from("faqs").select("*").order("sort_order", { ascending: true });
  if (onlyPublished) query = query.eq("is_published", true);
  const { data, error } = await query;
  return { data, error };
}

export async function createFaq(faqData) {
  const { data, error } = await supabase.from("faqs").insert([faqData]).select();
  return { data, error };
}

export async function updateFaq(id, faqData) {
  const { data, error } = await supabase.from("faqs").update(faqData).eq("id", id).select();
  return { data, error };
}

export async function deleteFaq(id) {
  const { data, error } = await supabase.from("faqs").delete().eq("id", id);
  return { data, error };
}

// ==========================================
// CHATBOT RULES (keyword -> response, dikelola Admin)
// ==========================================

export async function getChatbotRules(onlyActive = false) {
  let query = supabase.from("chatbot_rules").select("*").order("created_at", { ascending: true });
  if (onlyActive) query = query.eq("is_active", true);
  const { data, error } = await query;
  return { data, error };
}

export async function createChatbotRule(ruleData) {
  const { data, error } = await supabase.from("chatbot_rules").insert([ruleData]).select();
  return { data, error };
}

export async function updateChatbotRule(id, ruleData) {
  const { data, error } = await supabase.from("chatbot_rules").update(ruleData).eq("id", id).select();
  return { data, error };
}

export async function deleteChatbotRule(id) {
  const { data, error } = await supabase.from("chatbot_rules").delete().eq("id", id);
  return { data, error };
}