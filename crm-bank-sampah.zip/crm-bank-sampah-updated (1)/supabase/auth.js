/**
 * supabase/auth.js
 * ------------------------------------------------------
 * Layanan autentikasi menggunakan Supabase.
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Proses login dengan email & password
export async function login(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
}

export async function registerNasabah(email, password, fullName, phone) {
  // 1. Daftarkan kredensial ke Supabase Auth
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
        role: "Nasabah"
      }
    }
  });

  if (authError) return { error: authError };

  // CEGAH ERROR {}: Jika email sudah pernah dipakai, Supabase sering mengembalikan user = null
  if (!authData || !authData.user) {
    return { error: { message: "Email ini sudah terdaftar. Silakan gunakan email lain atau coba login." } };
  }

  // 2. Simpan profil ke tabel customers
  const { error: custError } = await supabase
    .from("customers")
    .insert([{
      auth_id: authData.user.id,
      email: email,
      full_name: fullName,
      phone: phone,
      status: 'Aktif'
    }]);
  
  if (custError) {
    // Jika gagal menyimpan profil, kita hapus dulu akun auth-nya (Rollback) agar tidak nyangkut
    await supabase.auth.signOut();
    return { error: { message: "Gagal membuat profil nasabah: " + (custError.message || custError.details || "Database error") } };
  }

  return { data: authData, error: null };
}

// Proses logout
export async function logout() {
  const { error } = await supabase.auth.signOut();
  return { error };
}

// Cek sesi / token yang sedang aktif
export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  return { session: data?.session, error };
}

// Ambil data profil (termasuk Role) dari tabel public.profiles (Untuk Admin/Staff)
export async function getUserProfile(userId) {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single();
  
  return { profile: data, error };
}

// ------------------------------------------------------
// STRUKTUR AKSES ADMIN vs USER (NASABAH)
// ------------------------------------------------------
// Menentukan peran (role) pemilik sesi login saat ini dengan
// mengecek dua kemungkinan sumber data:
//   1. Tabel "profiles"  -> berarti akun Admin / Staff
//   2. Tabel "customers" (dicocokkan lewat auth_id) -> akun Nasabah
// Dipakai oleh guard di js/app.js (area Admin) dan
// js/utils/nasabah-guard.js (area Nasabah) supaya masing-masing
// sisi tidak bisa saling mengakses halaman yang bukan haknya.
export async function getUserRole(userId) {
  const { data: adminProfile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();

  if (adminProfile) {
    return { role: "admin", profile: adminProfile };
  }

  const { data: nasabahProfile } = await supabase
    .from("customers")
    .select("*")
    .eq("auth_id", userId)
    .maybeSingle();

  if (nasabahProfile) {
    return { role: "nasabah", profile: nasabahProfile };
  }

  return { role: null, profile: null };
}