/**
 * supabase/complaints.js
 * ------------------------------------------------------
 * Layanan CRUD untuk Modul Complaint Management
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

export async function getComplaints() {
  const { data, error } = await supabase
    .from("complaints")
    .select(`
      *,
      customers ( full_name )
    `)
    .order("created_at", { ascending: false });
    
  return { data, error };
}

// Khusus Portal Nasabah: hanya ambil pengaduan milik nasabah yang sedang login
export async function getComplaintsByCustomer(customerId) {
  const { data, error } = await supabase
    .from("complaints")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createComplaint(complaintData) {
  const { data, error } = await supabase
    .from("complaints")
    .insert([complaintData])
    .select();
  return { data, error };
}

export async function updateComplaint(id, complaintData) {
  const { data, error } = await supabase
    .from("complaints")
    .update(complaintData)
    .eq("id", id)
    .select();
  return { data, error };
}

export async function deleteComplaint(id) {
  const { data, error } = await supabase
    .from("complaints")
    .delete()
    .eq("id", id);
  return { data, error };
}

// ==========================================
// LIVE CHAT PER PENGADUAN (complaint_messages)
// ==========================================

export async function getComplaintMessages(complaintId) {
  const { data, error } = await supabase
    .from("complaint_messages")
    .select("*")
    .eq("complaint_id", complaintId)
    .order("created_at", { ascending: true });

  return { data, error };
}

export async function sendComplaintMessage(messageData) {
  const { data, error } = await supabase
    .from("complaint_messages")
    .insert([messageData])
    .select();

  return { data, error };
}