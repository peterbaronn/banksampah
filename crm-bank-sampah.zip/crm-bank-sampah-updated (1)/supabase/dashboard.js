/**
 * supabase/dashboard.js
 * ------------------------------------------------------
 * Layanan untuk mengambil & mengagregasi data statistik
 * untuk halaman Dashboard & Analytics.
 *
 * Modul ini menghitung:
 *  - Statistik utama (Total Nasabah, Total Transaksi, Total
 *    Setoran Sampah, Total Saldo)
 *  - Grafik Aktivitas (transaksi 14 hari terakhir)
 *  - Grafik Pertumbuhan Nasabah (nasabah baru / bulan, 6 bulan)
 *  - Statistik Membership (tier dihitung otomatis dari total
 *    saldo yang pernah didapat nasabah — akan digantikan oleh
 *    data membership_level asli saat modul Loyalty Program
 *    dikembangkan lebih lanjut)
 *  - Statistik Reward (klaim penukaran hadiah)
 *  - Statistik Complaint (berdasarkan status)
 *  - Statistik Penjemputan (berdasarkan status)
 *  - Leaderboard Nasabah (top 10 berdasarkan total setoran)
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Batas tier membership (sementara, berdasarkan akumulasi total_reward
// dari transaksi berstatus "Selesai"). Bisa disesuaikan / dipindah ke
// tabel konfigurasi saat modul Loyalty Program dibangun.
const MEMBERSHIP_TIERS = [
  { key: "Platinum", min: 500000 },
  { key: "Gold", min: 200000 },
  { key: "Silver", min: 50000 },
  { key: "Bronze", min: 0 },
];

function getMembershipTier(totalReward) {
  return MEMBERSHIP_TIERS.find((tier) => totalReward >= tier.min)?.key || "Bronze";
}

function toDateKey(isoString) {
  return new Date(isoString).toISOString().slice(0, 10); // YYYY-MM-DD
}

function toMonthKey(isoString) {
  return new Date(isoString).toISOString().slice(0, 7); // YYYY-MM
}

function lastNDates(n) {
  const dates = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dates.push(d.toISOString().slice(0, 10));
  }
  return dates;
}

function lastNMonths(n) {
  const months = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    months.push(d.toISOString().slice(0, 7));
  }
  return months;
}

export async function getDashboardData() {
  try {
    // 1. Ambil seluruh data mentah yang dibutuhkan (paralel)
    const [
      { data: customers, error: errCust },
      { data: transactions, error: errTx },
      { data: complaints, error: errComp },
      { data: schedules, error: errSched },
      { data: redemptions, error: errRedeem },
    ] = await Promise.all([
      supabase.from("customers").select("id, full_name, status, created_at"),
      supabase.from("transactions").select("customer_id, weight_kg, total_reward, status, waste_type, created_at, customers(full_name)"),
      supabase.from("complaints").select("status, created_at"),
      supabase.from("schedules").select("status, pickup_date, created_at"),
      supabase.from("reward_redemptions").select("points_used, status, created_at"),
    ]);

    if (errCust) throw errCust;
    if (errTx) throw errTx;
    if (errComp) throw errComp;
    if (errSched) throw errSched;
    if (errRedeem) throw errRedeem;

    const allCustomers = customers || [];
    const allTx = transactions || [];
    const allComplaints = complaints || [];
    const allSchedules = schedules || [];
    const allRedemptions = redemptions || [];

    const completedTx = allTx.filter((tx) => tx.status === "Selesai");

    // 2. Statistik utama
    const totalCustomers = allCustomers.length;
    const activeCustomers = allCustomers.filter((c) => c.status === "Aktif").length;
    const totalTransactions = allTx.length;
    const totalWeight = completedTx.reduce((sum, tx) => sum + (parseFloat(tx.weight_kg) || 0), 0);
    const totalReward = completedTx.reduce((sum, tx) => sum + (parseFloat(tx.total_reward) || 0), 0);
    const activeComplaints = allComplaints.filter((c) => ["Menunggu", "Diproses"].includes(c.status)).length;

    // 3. Grafik Aktivitas — jumlah transaksi per hari, 14 hari terakhir
    const activityDates = lastNDates(14);
    const activityMap = Object.fromEntries(activityDates.map((d) => [d, 0]));
    allTx.forEach((tx) => {
      const key = toDateKey(tx.created_at);
      if (key in activityMap) activityMap[key] += 1;
    });
    const activityChart = {
      labels: activityDates.map((d) => new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })),
      values: activityDates.map((d) => activityMap[d]),
    };

    // 4. Grafik Pertumbuhan Nasabah — nasabah baru per bulan, 6 bulan terakhir
    const growthMonths = lastNMonths(6);
    const growthMap = Object.fromEntries(growthMonths.map((m) => [m, 0]));
    allCustomers.forEach((c) => {
      const key = toMonthKey(c.created_at);
      if (key in growthMap) growthMap[key] += 1;
    });
    const growthChart = {
      labels: growthMonths.map((m) => new Date(`${m}-01`).toLocaleDateString("id-ID", { month: "short", year: "2-digit" })),
      values: growthMonths.map((m) => growthMap[m]),
    };

    // 5. Statistik Membership — tier dihitung dari akumulasi total_reward per nasabah
    const rewardByCustomer = {};
    completedTx.forEach((tx) => {
      if (!tx.customer_id) return;
      rewardByCustomer[tx.customer_id] = (rewardByCustomer[tx.customer_id] || 0) + (parseFloat(tx.total_reward) || 0);
    });
    const membershipCount = { Platinum: 0, Gold: 0, Silver: 0, Bronze: 0 };
    Object.values(rewardByCustomer).forEach((total) => {
      membershipCount[getMembershipTier(total)] += 1;
    });
    // Nasabah tanpa transaksi selesai otomatis masuk Bronze
    const customersWithTx = Object.keys(rewardByCustomer).length;
    membershipCount.Bronze += Math.max(0, totalCustomers - customersWithTx);

    // 6. Statistik Reward — dari reward_redemptions
    const rewardStats = {
      totalRedemptions: allRedemptions.length,
      totalPointsUsed: allRedemptions
        .filter((r) => r.status === "Disetujui")
        .reduce((sum, r) => sum + (parseFloat(r.points_used) || 0), 0),
      byStatus: {
        Menunggu: allRedemptions.filter((r) => r.status === "Menunggu").length,
        Disetujui: allRedemptions.filter((r) => r.status === "Disetujui").length,
        Ditolak: allRedemptions.filter((r) => r.status === "Ditolak").length,
      },
    };

    // 7. Statistik Complaint — berdasarkan status
    const complaintStats = {
      total: allComplaints.length,
      byStatus: {
        Menunggu: allComplaints.filter((c) => c.status === "Menunggu").length,
        Diproses: allComplaints.filter((c) => c.status === "Diproses").length,
        Selesai: allComplaints.filter((c) => c.status === "Selesai").length,
      },
    };

    // 8. Statistik Penjemputan — berdasarkan status
    const schedulingStats = {
      total: allSchedules.length,
      byStatus: {
        Terjadwal: allSchedules.filter((s) => s.status === "Terjadwal").length,
        Selesai: allSchedules.filter((s) => s.status === "Selesai").length,
        Dibatalkan: allSchedules.filter((s) => s.status === "Dibatalkan").length,
      },
    };

    // 9. Leaderboard Nasabah — top 10 berdasarkan total berat setoran (selesai)
    const weightByCustomer = {};
    const nameByCustomer = {};
    completedTx.forEach((tx) => {
      if (!tx.customer_id) return;
      weightByCustomer[tx.customer_id] = (weightByCustomer[tx.customer_id] || 0) + (parseFloat(tx.weight_kg) || 0);
      nameByCustomer[tx.customer_id] = tx.customers?.full_name || "Nasabah Dihapus";
    });
    const leaderboard = Object.entries(weightByCustomer)
      .map(([customerId, weight]) => ({
        customerId,
        name: nameByCustomer[customerId],
        totalWeight: weight,
        totalReward: rewardByCustomer[customerId] || 0,
      }))
      .sort((a, b) => b.totalWeight - a.totalWeight)
      .slice(0, 10);

    // 10. 5 Transaksi Terbaru (semua status)
    const recentTransactions = [...allTx]
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 5);

    return {
      stats: {
        customers: totalCustomers,
        activeCustomers,
        transactions: totalTransactions,
        weight: totalWeight,
        reward: totalReward,
        complaints: activeComplaints,
      },
      activityChart,
      growthChart,
      membershipCount,
      rewardStats,
      complaintStats,
      schedulingStats,
      leaderboard,
      recentTransactions,
      error: null,
    };
  } catch (error) {
    return {
      stats: null,
      activityChart: null,
      growthChart: null,
      membershipCount: null,
      rewardStats: null,
      complaintStats: null,
      schedulingStats: null,
      leaderboard: null,
      recentTransactions: null,
      error,
    };
  }
}
