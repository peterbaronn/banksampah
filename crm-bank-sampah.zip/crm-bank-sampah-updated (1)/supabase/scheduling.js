/**
 * supabase/scheduling.js
 * ------------------------------------------------------
 * Layanan untuk Modul Scheduling:
 *  - Booking Penjemputan (CRUD jadwal, fitur lama)
 *  - Tracking Driver (master data driver + assign ke jadwal)
 *  - Estimasi Kedatangan / ETA
 *  - Reschedule Jadwal
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Mengambil semua jadwal jemput, diurutkan dari yang paling dekat
export async function getSchedules() {
  const { data, error } = await supabase
    .from("schedules")
    .select(`
      *,
      customers ( full_name, phone, address ),
      drivers ( name, phone, vehicle_plate )
    `)
    .order("pickup_date", { ascending: true })
    .order("pickup_time", { ascending: true });

  return { data, error };
}

export async function createSchedule(scheduleData) {
  const { data, error } = await supabase
    .from("schedules")
    .insert([scheduleData])
    .select();
  return { data, error };
}

export async function updateSchedule(id, scheduleData) {
  const { data, error } = await supabase
    .from("schedules")
    .update(scheduleData)
    .eq("id", id)
    .select();
  return { data, error };
}

export async function deleteSchedule(id) {
  const { data, error } = await supabase
    .from("schedules")
    .delete()
    .eq("id", id);
  return { data, error };
}

// Reschedule: ubah tanggal/waktu + tandai status kembali Terjadwal,
// dan naikkan penghitung reschedule_count untuk audit.
export async function rescheduleSchedule(id, newDate, newTime, currentCount = 0) {
  const { data, error } = await supabase
    .from("schedules")
    .update({
      pickup_date: newDate,
      pickup_time: newTime,
      status: "Terjadwal",
      reschedule_count: (currentCount || 0) + 1,
    })
    .eq("id", id)
    .select();
  return { data, error };
}

// ==========================================
// TRACKING DRIVER (master data driver/petugas)
// ==========================================

export async function getDrivers(onlyActive = false) {
  let query = supabase.from("drivers").select("*").order("name", { ascending: true });
  if (onlyActive) query = query.eq("status", "Aktif");
  const { data, error } = await query;
  return { data, error };
}

export async function createDriver(driverData) {
  const { data, error } = await supabase.from("drivers").insert([driverData]).select();
  return { data, error };
}

export async function updateDriver(id, driverData) {
  const { data, error } = await supabase.from("drivers").update(driverData).eq("id", id).select();
  return { data, error };
}

export async function deleteDriver(id) {
  const { data, error } = await supabase.from("drivers").delete().eq("id", id);
  return { data, error };
}
