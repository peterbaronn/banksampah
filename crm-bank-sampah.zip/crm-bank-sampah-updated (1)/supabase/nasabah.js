/**
 * supabase/nasabah.js
 * ------------------------------------------------------
 * Layanan khusus Portal Nasabah (Layanan Mandiri)
 * ------------------------------------------------------
 */
import { supabase } from "./supabase.js";

// 1. Ambil Profil Nasabah
export async function getNasabahProfile(authId) {
  const { data, error } = await supabase
    .from("customers")
    .select("*")
    .eq("auth_id", authId)
    .single();
  return { profile: data, error };
}

// 2. Ambil Riwayat Transaksi Nasabah
export async function getNasabahTransactions(customerId) {
  const { data, error } = await supabase
    .from("transactions")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });
  return { data, error };
}

// 3. Ambil Jadwal Penjemputan Milik Nasabah
export async function getNasabahSchedules(customerId) {
  const { data, error } = await supabase
    .from("schedules")
    .select("*, drivers ( name, phone, vehicle_plate )")
    .eq("customer_id", customerId)
    .order("pickup_date", { ascending: false });
  return { data, error };
}

// 4. Buat Request Penjemputan Baru
export async function requestPenjemputan(scheduleData) {
  const { data, error } = await supabase
    .from("schedules")
    .insert([scheduleData])
    .select();
  return { data, error };
}

// 5. Ambil Riwayat Penukaran Poin/Reward Nasabah
export async function getNasabahRewards(customerId) {
  const { data, error } = await supabase
    .from("reward_redemptions")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });
  return { data, error };
}

// 6. Buat Request Klaim Reward
export async function requestReward(rewardData) {
  const { data, error } = await supabase
    .from("reward_redemptions")
    .insert([rewardData])
    .select();
  return { data, error };
}