/**
 * supabase/engagement.js
 * ------------------------------------------------------
 * Layanan untuk seluruh Modul Customer Engagement:
 *  - Notifikasi & Broadcast (WA/Email/SMS/In-App)
 *  - Reminder
 *  - Ucapan Ulang Tahun
 *  - Campaign
 *  - Edukasi
 *  - Log Interaksi manual (Telepon/Kunjungan/dll — fitur lama)
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// ==========================================
// LOG INTERAKSI MANUAL (fitur lama, dipertahankan)
// ==========================================

export async function getEngagements() {
  const { data, error } = await supabase
    .from("engagements")
    .select(`
      *,
      customers ( full_name )
    `)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createEngagement(engagementData) {
  const { data, error } = await supabase
    .from("engagements")
    .insert([engagementData])
    .select();
  return { data, error };
}

export async function updateEngagement(id, engagementData) {
  const { data, error } = await supabase
    .from("engagements")
    .update(engagementData)
    .eq("id", id)
    .select();
  return { data, error };
}

export async function deleteEngagement(id) {
  const { data, error } = await supabase
    .from("engagements")
    .delete()
    .eq("id", id);
  return { data, error };
}

// ==========================================
// NOTIFIKASI, BROADCAST, REMINDER, UCAPAN ULANG TAHUN
// (satu tabel "notifications"; customer_id NULL = broadcast ke semua)
// ==========================================

export async function getNotifications() {
  const { data, error } = await supabase
    .from("notifications")
    .select(`*, customers ( full_name )`)
    .order("created_at", { ascending: false });

  return { data, error };
}

// Dipakai Portal Nasabah: notifikasi milik nasabah ini + broadcast umum (customer_id NULL)
export async function getMyNotifications(customerId) {
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .or(`customer_id.eq.${customerId},customer_id.is.null`)
    .order("created_at", { ascending: false })
    .limit(20);

  return { data, error };
}

export async function createNotification(notificationData) {
  const { data, error } = await supabase
    .from("notifications")
    .insert([notificationData])
    .select();

  return { data, error };
}

// Broadcast ke banyak nasabah sekaligus (insert banyak baris, satu per nasabah)
export async function broadcastToCustomers(customerIds, notificationBase) {
  const rows = customerIds.map((id) => ({ ...notificationBase, customer_id: id }));
  const { data, error } = await supabase.from("notifications").insert(rows).select();
  return { data, error };
}

export async function deleteNotification(id) {
  const { data, error } = await supabase.from("notifications").delete().eq("id", id);
  return { data, error };
}

// Nasabah yang berulang tahun bulan ini (butuh kolom customers.birth_date)
export async function getBirthdaysThisMonth() {
  const { data, error } = await supabase
    .from("customers")
    .select("id, full_name, birth_date, status")
    .not("birth_date", "is", null);

  if (error) return { data: [], error };

  const currentMonth = new Date().getMonth();
  const filtered = (data || []).filter((c) => new Date(c.birth_date).getMonth() === currentMonth);

  return { data: filtered, error: null };
}

// ==========================================
// CAMPAIGN
// ==========================================

export async function getCampaigns() {
  const { data, error } = await supabase
    .from("campaigns")
    .select("*")
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createCampaign(campaignData) {
  const { data, error } = await supabase.from("campaigns").insert([campaignData]).select();
  return { data, error };
}

export async function updateCampaign(id, campaignData) {
  const { data, error } = await supabase.from("campaigns").update(campaignData).eq("id", id).select();
  return { data, error };
}

export async function deleteCampaign(id) {
  const { data, error } = await supabase.from("campaigns").delete().eq("id", id);
  return { data, error };
}

// ==========================================
// EDUKASI (dikelola Admin, ditampilkan di Portal Nasabah)
// ==========================================

export async function getEducationalContent(onlyPublished = false) {
  let query = supabase.from("educational_content").select("*").order("sort_order", { ascending: true });
  if (onlyPublished) query = query.eq("is_published", true);
  const { data, error } = await query;
  return { data, error };
}

export async function createEducationalContent(contentData) {
  const { data, error } = await supabase.from("educational_content").insert([contentData]).select();
  return { data, error };
}

export async function updateEducationalContent(id, contentData) {
  const { data, error } = await supabase.from("educational_content").update(contentData).eq("id", id).select();
  return { data, error };
}

export async function deleteEducationalContent(id) {
  const { data, error } = await supabase.from("educational_content").delete().eq("id", id);
  return { data, error };
}
