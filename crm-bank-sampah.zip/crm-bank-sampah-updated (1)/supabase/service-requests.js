/**
 * supabase/service-requests.js
 * ------------------------------------------------------
 * Layanan untuk Customer Service - Call Request & Appointment
 * Booking (khusus Portal Nasabah).
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

export async function getMyServiceRequests(customerId) {
  const { data, error } = await supabase
    .from("service_requests")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createServiceRequest(requestData) {
  const { data, error } = await supabase
    .from("service_requests")
    .insert([requestData])
    .select();

  return { data, error };
}

// ==========================================
// SISI ADMIN: kelola seluruh Call Request & Appointment Booking
// ==========================================

export async function getAllServiceRequests() {
  const { data, error } = await supabase
    .from("service_requests")
    .select(`*, customers ( full_name, phone )`)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function updateServiceRequest(id, requestData) {
  const { data, error } = await supabase
    .from("service_requests")
    .update(requestData)
    .eq("id", id)
    .select();

  return { data, error };
}

export async function deleteServiceRequest(id) {
  const { data, error } = await supabase
    .from("service_requests")
    .delete()
    .eq("id", id);

  return { data, error };
}
