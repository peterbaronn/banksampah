/**
 * supabase/customers.js
 * ------------------------------------------------------
 * Layanan CRUD (Create, Read, Update, Delete) Nasabah,
 * beserta agregasi Riwayat Aktivitas per nasabah.
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Mengambil semua data nasabah (mendukung pencarian & filter segmen)
export async function getCustomers(searchQuery = "", segmentFilter = "") {
  let query = supabase
    .from("customers")
    .select("*")
    .order("created_at", { ascending: false });

  // Jika ada kata kunci pencarian, filter berdasarkan nama atau telepon
  if (searchQuery) {
    query = query.or(`full_name.ilike.%${searchQuery}%,phone.ilike.%${searchQuery}%`);
  }

  // Filter berdasarkan segmen nasabah (jika dipilih)
  if (segmentFilter) {
    query = query.eq("segment", segmentFilter);
  }

  const { data, error } = await query;
  return { data, error };
}

// Mengambil peta "tanggal aktivitas terakhir" untuk semua nasabah,
// dihitung dari transaksi terbaru masing-masing. Dipakai untuk
// menampilkan kolom "Terakhir Aktif" & indikator Status Keaktifan.
export async function getLastActivityMap() {
  const { data, error } = await supabase
    .from("transactions")
    .select("customer_id, created_at")
    .order("created_at", { ascending: false });

  if (error) return { map: {}, error };

  const map = {};
  (data || []).forEach((tx) => {
    if (!tx.customer_id) return;
    if (!map[tx.customer_id]) map[tx.customer_id] = tx.created_at; // sudah urut terbaru -> terlama
  });

  return { map, error: null };
}

// Menambah data nasabah baru
export async function createCustomer(customerData) {
  const { data, error } = await supabase
    .from("customers")
    .insert([customerData])
    .select();
    
  return { data, error };
}

// Memperbarui data nasabah
export async function updateCustomer(id, customerData) {
  const { data, error } = await supabase
    .from("customers")
    .update(customerData)
    .eq("id", id)
    .select();

  return { data, error };
}

// Menghapus data nasabah
export async function deleteCustomer(id) {
  const { data, error } = await supabase
    .from("customers")
    .delete()
    .eq("id", id);

  return { data, error };
}

// Mengambil Riwayat Aktivitas lengkap seorang nasabah:
// transaksi setoran, pengaduan, jadwal penjemputan, dan
// penukaran reward — masing-masing 5 data terbaru.
export async function getCustomerActivity(customerId) {
  try {
    const [
      { data: transactions, error: errTx },
      { data: complaints, error: errComp },
      { data: schedules, error: errSched },
      { data: redemptions, error: errRedeem },
    ] = await Promise.all([
      supabase
        .from("transactions")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase
        .from("complaints")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase
        .from("schedules")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase
        .from("reward_redemptions")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false })
        .limit(5),
    ]);

    if (errTx) throw errTx;
    if (errComp) throw errComp;
    if (errSched) throw errSched;
    if (errRedeem) throw errRedeem;

    return {
      transactions: transactions || [],
      complaints: complaints || [],
      schedules: schedules || [],
      redemptions: redemptions || [],
      error: null,
    };
  } catch (error) {
    return { transactions: [], complaints: [], schedules: [], redemptions: [], error };
  }
}