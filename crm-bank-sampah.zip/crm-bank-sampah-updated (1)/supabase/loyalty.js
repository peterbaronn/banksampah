/**
 * supabase/loyalty.js
 * ------------------------------------------------------
 * Layanan untuk seluruh Modul Loyalty Program:
 *  - Reward Point & Membership Level (dihitung otomatis)
 *  - Reward Catalog (Voucher / Cashback / Sembako)
 *  - Riwayat Penukaran Hadiah
 *  - Referral Program
 *  - Achievement Badge (dihitung otomatis)
 * ------------------------------------------------------
 */

import { supabase } from "./supabase.js";

// Batas tier membership berdasarkan akumulasi total saldo (total_reward)
// dari transaksi berstatus "Selesai" + bonus referral disetujui.
// Konsisten dengan logika di modul Dashboard & Analytics.
export const MEMBERSHIP_TIERS = [
  { key: "Platinum", min: 500000 },
  { key: "Gold", min: 200000 },
  { key: "Silver", min: 50000 },
  { key: "Bronze", min: 0 },
];

export function getMembershipTier(totalReward) {
  return MEMBERSHIP_TIERS.find((tier) => totalReward >= tier.min)?.key || "Bronze";
}

// Konversi saldo (Rp) menjadi Poin Reward. 1 poin = Rp 1.000.
const POINTS_CONVERSION_RATE = 1000;

// ==========================================
// RIWAYAT PENUKARAN HADIAH (reward_redemptions)
// ==========================================

export async function getRedemptions() {
  const { data, error } = await supabase
    .from("reward_redemptions")
    .select(`*, customers ( full_name )`)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createRedemption(redemptionData) {
  const { data, error } = await supabase.from("reward_redemptions").insert([redemptionData]).select();
  return { data, error };
}

export async function updateRedemption(id, redemptionData) {
  const { data, error } = await supabase.from("reward_redemptions").update(redemptionData).eq("id", id).select();
  return { data, error };
}

export async function deleteRedemption(id) {
  const { data, error } = await supabase.from("reward_redemptions").delete().eq("id", id);
  return { data, error };
}

// ==========================================
// REWARD CATALOG (Voucher / Cashback / Sembako)
// ==========================================

export async function getRewardCatalog(onlyActive = false) {
  let query = supabase.from("reward_catalog").select("*").order("category", { ascending: true }).order("name", { ascending: true });
  if (onlyActive) query = query.eq("is_active", true);
  const { data, error } = await query;
  return { data, error };
}

export async function createCatalogItem(itemData) {
  const { data, error } = await supabase.from("reward_catalog").insert([itemData]).select();
  return { data, error };
}

export async function updateCatalogItem(id, itemData) {
  const { data, error } = await supabase.from("reward_catalog").update(itemData).eq("id", id).select();
  return { data, error };
}

export async function deleteCatalogItem(id) {
  const { data, error } = await supabase.from("reward_catalog").delete().eq("id", id);
  return { data, error };
}

// ==========================================
// REFERRAL PROGRAM (referrals)
// ==========================================

export async function getReferrals() {
  const { data, error } = await supabase
    .from("referrals")
    .select(`*, referrer:referrer_id ( full_name )`)
    .order("created_at", { ascending: false });

  return { data, error };
}

export async function createReferral(referralData) {
  const { data, error } = await supabase.from("referrals").insert([referralData]).select();
  return { data, error };
}

export async function updateReferral(id, referralData) {
  const { data, error } = await supabase.from("referrals").update(referralData).eq("id", id).select();
  return { data, error };
}

export async function deleteReferral(id) {
  const { data, error } = await supabase.from("referrals").delete().eq("id", id);
  return { data, error };
}

// ==========================================
// RINGKASAN LOYALTY UNTUK SATU NASABAH (Portal Nasabah)
// Versi ringan dari getLoyaltyOverview() di atas, hanya
// mengambil data milik satu customer_id agar nasabah tidak
// perlu (dan tidak boleh) menarik data seluruh nasabah lain.
// ==========================================
export async function getMyLoyaltySummary(customerId) {
  try {
    const [
      { data: customer, error: errCust },
      { data: transactions, error: errTx },
      { data: redemptions, error: errRedeem },
      { data: referrals, error: errRef },
    ] = await Promise.all([
      supabase.from("customers").select("id, full_name, created_at").eq("id", customerId).maybeSingle(),
      supabase.from("transactions").select("weight_kg, total_reward, status").eq("customer_id", customerId),
      supabase.from("reward_redemptions").select("points_used, status").eq("customer_id", customerId),
      supabase.from("referrals").select("bonus_points, status").eq("referrer_id", customerId),
    ]);

    if (errCust) throw errCust;
    if (errTx) throw errTx;
    if (errRedeem) throw errRedeem;
    if (errRef) throw errRef;

    const completedTx = (transactions || []).filter((tx) => tx.status === "Selesai");
    const approvedRedemptions = (redemptions || []).filter((r) => r.status === "Disetujui");
    const approvedReferrals = (referrals || []).filter((r) => r.status === "Disetujui");

    const totalWeight = completedTx.reduce((sum, tx) => sum + (parseFloat(tx.weight_kg) || 0), 0);
    const txCount = completedTx.length;
    const referralBonus = approvedReferrals.reduce((sum, r) => sum + (parseFloat(r.bonus_points) || 0) * POINTS_CONVERSION_RATE, 0);
    const lifetimeReward = completedTx.reduce((sum, tx) => sum + (parseFloat(tx.total_reward) || 0), 0) + referralBonus;

    const pointsEarned = Math.floor(lifetimeReward / POINTS_CONVERSION_RATE);
    const pointsUsed = Math.floor(approvedRedemptions.reduce((sum, r) => sum + (parseFloat(r.points_used) || 0), 0) / POINTS_CONVERSION_RATE);
    const pointsBalance = Math.max(0, pointsEarned - pointsUsed);
    const tier = getMembershipTier(lifetimeReward);

    const badges = [];
    const daysSinceJoin = customer ? (Date.now() - new Date(customer.created_at).getTime()) / (1000 * 60 * 60 * 24) : 999;
    if (daysSinceJoin <= 30) badges.push("Nasabah Baru");
    if (txCount >= 5) badges.push("Setoran Rutin");
    if (txCount >= 15) badges.push("Kontributor Aktif");
    if (totalWeight >= 50) badges.push("Peduli Lingkungan");
    if (approvedReferrals.length >= 3) badges.push("Juara Referral");
    if (tier === "Platinum") badges.push("Member Platinum");

    return { tier, pointsBalance, totalWeight, txCount, referralCount: approvedReferrals.length, badges, error: null };
  } catch (error) {
    return { tier: "Bronze", pointsBalance: 0, totalWeight: 0, txCount: 0, referralCount: 0, badges: [], error };
  }
}

export async function getLoyaltyOverview() {
  try {
    const [
      { data: customers, error: errCust },
      { data: transactions, error: errTx },
      { data: redemptions, error: errRedeem },
      { data: referrals, error: errRef },
    ] = await Promise.all([
      supabase.from("customers").select("id, full_name, status, created_at"),
      supabase.from("transactions").select("customer_id, weight_kg, total_reward, status"),
      supabase.from("reward_redemptions").select("customer_id, points_used, status, category"),
      supabase.from("referrals").select("referrer_id, bonus_points, status"),
    ]);

    if (errCust) throw errCust;
    if (errTx) throw errTx;
    if (errRedeem) throw errRedeem;
    if (errRef) throw errRef;

    const allCustomers = customers || [];
    const completedTx = (transactions || []).filter((tx) => tx.status === "Selesai");
    const approvedRedemptions = (redemptions || []).filter((r) => r.status === "Disetujui");
    const approvedReferrals = (referrals || []).filter((r) => r.status === "Disetujui");

    // Total saldo lifetime per nasabah (dari transaksi selesai)
    const rewardByCustomer = {};
    completedTx.forEach((tx) => {
      if (!tx.customer_id) return;
      rewardByCustomer[tx.customer_id] = (rewardByCustomer[tx.customer_id] || 0) + (parseFloat(tx.total_reward) || 0);
    });

    // Total berat lifetime per nasabah (untuk badge "Peduli Lingkungan")
    const weightByCustomer = {};
    const txCountByCustomer = {};
    completedTx.forEach((tx) => {
      if (!tx.customer_id) return;
      weightByCustomer[tx.customer_id] = (weightByCustomer[tx.customer_id] || 0) + (parseFloat(tx.weight_kg) || 0);
      txCountByCustomer[tx.customer_id] = (txCountByCustomer[tx.customer_id] || 0) + 1;
    });

    // Bonus poin referral disetujui per nasabah (referrer)
    const referralBonusByCustomer = {};
    const referralCountByCustomer = {};
    approvedReferrals.forEach((r) => {
      if (!r.referrer_id) return;
      referralBonusByCustomer[r.referrer_id] = (referralBonusByCustomer[r.referrer_id] || 0) + (parseFloat(r.bonus_points) || 0) * POINTS_CONVERSION_RATE;
      referralCountByCustomer[r.referrer_id] = (referralCountByCustomer[r.referrer_id] || 0) + 1;
    });

    // Poin terpakai (disetujui) per nasabah
    const pointsUsedByCustomer = {};
    approvedRedemptions.forEach((r) => {
      if (!r.customer_id) return;
      pointsUsedByCustomer[r.customer_id] = (pointsUsedByCustomer[r.customer_id] || 0) + (parseFloat(r.points_used) || 0);
    });

    // Susun ringkasan per nasabah: total saldo, tier, saldo poin (balance), badge
    const customerSummaries = allCustomers.map((c) => {
      const lifetimeReward = (rewardByCustomer[c.id] || 0) + (referralBonusByCustomer[c.id] || 0);
      const pointsEarned = Math.floor(lifetimeReward / POINTS_CONVERSION_RATE);
      const pointsUsed = Math.floor((pointsUsedByCustomer[c.id] || 0) / POINTS_CONVERSION_RATE);
      const pointsBalance = Math.max(0, pointsEarned - pointsUsed);
      const tier = getMembershipTier(lifetimeReward);
      const totalWeight = weightByCustomer[c.id] || 0;
      const txCount = txCountByCustomer[c.id] || 0;
      const referralCount = referralCountByCustomer[c.id] || 0;

      const badges = [];
      const daysSinceJoin = (Date.now() - new Date(c.created_at).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceJoin <= 30) badges.push("Nasabah Baru");
      if (txCount >= 5) badges.push("Setoran Rutin");
      if (txCount >= 15) badges.push("Kontributor Aktif");
      if (totalWeight >= 50) badges.push("Peduli Lingkungan");
      if (referralCount >= 3) badges.push("Juara Referral");
      if (tier === "Platinum") badges.push("Member Platinum");

      return {
        id: c.id,
        name: c.full_name,
        status: c.status,
        tier,
        lifetimeReward,
        pointsBalance,
        totalWeight,
        txCount,
        referralCount,
        badges,
      };
    });

    // Total statistik
    const membershipCount = { Platinum: 0, Gold: 0, Silver: 0, Bronze: 0 };
    let totalPointsBalance = 0;
    customerSummaries.forEach((s) => {
      membershipCount[s.tier] += 1;
      totalPointsBalance += s.pointsBalance;
    });

    // Ringkasan badge (nama badge -> jumlah nasabah yang meraihnya + daftar nama)
    const badgeDefinitions = [
      { key: "Nasabah Baru", icon: "person_add", description: "Bergabung dalam 30 hari terakhir" },
      { key: "Setoran Rutin", icon: "recycling", description: "Sudah menyetor sampah minimal 5 kali" },
      { key: "Kontributor Aktif", icon: "military_tech", description: "Sudah menyetor sampah minimal 15 kali" },
      { key: "Peduli Lingkungan", icon: "eco", description: "Total setoran sampah mencapai 50 kg atau lebih" },
      { key: "Juara Referral", icon: "diversity_3", description: "Berhasil mereferensikan 3 nasabah baru atau lebih" },
      { key: "Member Platinum", icon: "workspace_premium", description: "Mencapai membership tier Platinum" },
    ];
    const badgeStats = badgeDefinitions.map((def) => {
      const holders = customerSummaries.filter((s) => s.badges.includes(def.key));
      return { ...def, count: holders.length, holders: holders.map((h) => h.name).slice(0, 5) };
    });

    return {
      customerSummaries: customerSummaries.sort((a, b) => b.pointsBalance - a.pointsBalance),
      membershipCount,
      totalPointsBalance,
      totalRedemptions: (redemptions || []).length,
      totalReferralsApproved: approvedReferrals.length,
      badgeStats,
      error: null,
    };
  } catch (error) {
    return {
      customerSummaries: [],
      membershipCount: null,
      totalPointsBalance: 0,
      totalRedemptions: 0,
      totalReferralsApproved: 0,
      badgeStats: [],
      error,
    };
  }
}
