/**
 * components/footer.js
 * ------------------------------------------------------
 * Bertanggung jawab memuat markup footer (partials/footer.html)
 * ke dalam elemen dengan id "app-footer".
 * ------------------------------------------------------
 */

import { CONFIG } from "../config.js";

/**
 * Menginisialisasi footer pada elemen target.
 * @param {string} targetSelector - selector elemen container footer
 */
export async function initFooter(targetSelector = "#app-footer") {
  const container = document.querySelector(targetSelector);
  if (!container) return;

  try {
    const response = await fetch(`${CONFIG.PARTIALS_PATH}footer.html`);
    const html = await response.text();
    container.innerHTML = html;

    setYear(container);
  } catch (error) {
    console.error("[footer.js] Gagal memuat footer:", error);
  }
}

function setYear(container) {
  const yearEl = container.querySelector("#footer-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}
