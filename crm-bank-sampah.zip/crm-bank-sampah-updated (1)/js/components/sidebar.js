/**
 * components/sidebar.js
 * ------------------------------------------------------
 * Bertanggung jawab memuat markup sidebar (partials/sidebar.html)
 * ke dalam elemen dengan id "app-sidebar", menandai menu
 * yang aktif, serta menangani mode collapse (desktop) dan
 * drawer (mobile).
 * ------------------------------------------------------
 */

import { CONFIG } from "../config.js";

const COLLAPSE_STORAGE_KEY = "crm-sidebar-collapsed";

/**
 * Menginisialisasi sidebar pada elemen target.
 * @param {string} targetSelector - selector elemen container sidebar
 * @param {string} activePage - identifier halaman aktif (data-page)
 */
export async function initSidebar(targetSelector = "#app-sidebar", activePage = "") {
  const container = document.querySelector(targetSelector);
  if (!container) return;

  try {
    const response = await fetch(`${CONFIG.PARTIALS_PATH}sidebar.html`);
    const html = await response.text();
    container.innerHTML = html;

    setActiveLink(container, activePage);
    setVersion(container);
    initCollapseToggle(container);
    restoreCollapsedState();
  } catch (error) {
    console.error("[sidebar.js] Gagal memuat sidebar:", error);
  }
}

function setActiveLink(container, activePage) {
  if (!activePage) return;

  const links = container.querySelectorAll(".sidebar__link");
  links.forEach((link) => {
    const isActive = link.dataset.page === activePage;
    link.classList.toggle("is-active", isActive);
  });
}

function setVersion(container) {
  const versionEl = container.querySelector("#app-version");
  if (versionEl) {
    versionEl.textContent = CONFIG.APP_VERSION;
  }
}

/**
 * Mengatur tombol collapse/expand sidebar (desktop & tablet).
 */
function initCollapseToggle(container) {
  const toggleBtn = container.querySelector("#sidebar-toggle");
  const appLayout = document.querySelector(".app-layout");
  if (!toggleBtn || !appLayout) return;

  toggleBtn.addEventListener("click", () => {
    const isCollapsed = appLayout.classList.toggle("is-collapsed");
    localStorage.setItem(COLLAPSE_STORAGE_KEY, isCollapsed ? "1" : "0");
  });
}

/**
 * Mengembalikan state collapse sidebar dari sesi sebelumnya.
 */
function restoreCollapsedState() {
  const appLayout = document.querySelector(".app-layout");
  if (!appLayout) return;

  const saved = localStorage.getItem(COLLAPSE_STORAGE_KEY);
  if (saved === "1") {
    appLayout.classList.add("is-collapsed");
  }
}

/**
 * Membuka/menutup sidebar sebagai drawer pada layar mobile.
 * Dipanggil dari navbar.js saat tombol menu (hamburger) ditekan.
 */
export function toggleMobileDrawer() {
  const sidebar = document.querySelector(".app-sidebar");
  const overlay = getOrCreateOverlay();
  if (!sidebar) return;

  const isOpen = sidebar.classList.toggle("is-open");
  overlay.classList.toggle("is-visible", isOpen);
}

function closeMobileDrawer() {
  const sidebar = document.querySelector(".app-sidebar");
  const overlay = document.querySelector(".sidebar-overlay");
  if (sidebar) sidebar.classList.remove("is-open");
  if (overlay) overlay.classList.remove("is-visible");
}

function getOrCreateOverlay() {
  let overlay = document.querySelector(".sidebar-overlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    overlay.addEventListener("click", closeMobileDrawer);
    document.body.appendChild(overlay);
  }
  return overlay;
}
