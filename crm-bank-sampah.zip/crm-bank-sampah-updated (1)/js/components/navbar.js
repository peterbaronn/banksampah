/**
 * components/navbar.js
 */

import { CONFIG } from "../config.js";
import { toggleMobileDrawer } from "./sidebar.js";
import { initDropdown } from "../utils/dropdown.js";
import { logout, getSession, getUserProfile } from "../../supabase/auth.js"; 

export async function initNavbar(targetSelector = "#app-navbar", pageTitle = "") {
  const container = document.querySelector(targetSelector);
  if (!container) return;

  try {
    const response = await fetch(`${CONFIG.PARTIALS_PATH}navbar.html`);
    const html = await response.text();
    container.innerHTML = html;

    setPageTitle(container, pageTitle);
    initMobileMenuButton(container);
    initUserDropdown(container);
    initLogoutButton(container);
    
    // Panggil fungsi untuk memuat data profil ke UI navbar
    await loadUserProfile(container);
  } catch (error) {
    console.error("[navbar.js] Gagal memuat navbar:", error);
  }
}

function setPageTitle(container, pageTitle) {
  const titleEl = container.querySelector("#navbar-page-title");
  if (titleEl && pageTitle) titleEl.textContent = pageTitle;
}

function initMobileMenuButton(container) {
  const menuBtn = container.querySelector("#navbar-menu-btn");
  if (menuBtn) menuBtn.addEventListener("click", toggleMobileDrawer);
}

function initUserDropdown(container) {
  const trigger = container.querySelector("#user-menu-trigger");
  const menu = container.querySelector("#user-menu");
  if (trigger && menu) initDropdown(trigger, menu);
}

function initLogoutButton(container) {
  const logoutBtn = container.querySelector("#btn-logout");
  if (!logoutBtn) return;

  logoutBtn.addEventListener("click", async () => {
    try {
      await logout();
      window.location.replace("/pages/login.html");
    } catch (error) {
      console.error("Gagal logout:", error);
    }
  });
}

// Fungsi Baru: Menarik data nama dan role dari Supabase
async function loadUserProfile(container) {
  const { session } = await getSession();
  if (!session) return;

  const { profile } = await getUserProfile(session.user.id);
  if (profile) {
    container.querySelector(".navbar__user-name").textContent = profile.full_name;
    container.querySelector(".navbar__user-role").textContent = profile.role;
    // Ambil inisial huruf pertama untuk Avatar
    container.querySelector(".navbar__avatar").textContent = profile.full_name.charAt(0).toUpperCase();
  }
}