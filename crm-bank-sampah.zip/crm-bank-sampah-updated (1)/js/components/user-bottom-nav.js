/**
 * components/user-bottom-nav.js
 * ------------------------------------------------------
 * Memuat markup bottom navigation (partials/user-bottom-nav.html)
 * ke dalam elemen dengan id "user-bottom-nav-slot" pada setiap
 * halaman Portal Nasabah, lalu menandai menu yang aktif
 * berdasarkan atribut data-page pada tag <body>.
 *
 * Ini adalah versi Nasabah dari components/sidebar.js (Admin),
 * bagian dari Struktur Akses Admin vs User.
 * ------------------------------------------------------
 */

import { CONFIG } from "../config.js";

export async function initUserBottomNav(targetSelector = "#user-bottom-nav-slot") {
  const container = document.querySelector(targetSelector);
  if (!container) return;

  try {
    const response = await fetch(`${CONFIG.PARTIALS_PATH}user-bottom-nav.html`);
    const html = await response.text();
    container.innerHTML = html;

    const activePage = document.body.dataset.page || "";
    const links = container.querySelectorAll(".bottom-nav__item");
    links.forEach((link) => {
      link.classList.toggle("is-active", link.dataset.page === activePage);
    });
  } catch (error) {
    console.error("[user-bottom-nav.js] Gagal memuat bottom nav:", error);
  }
}
