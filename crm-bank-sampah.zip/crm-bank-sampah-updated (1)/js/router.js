/**
 * router.js
 * ------------------------------------------------------
 * Aplikasi ini BELUM menggunakan SPA. Navigasi antar
 * halaman ditangani langsung oleh browser melalui tag <a>
 * pada partials/sidebar.html.
 *
 * File ini hanya menyediakan fungsi bantu (helper) untuk
 * mengetahui identitas halaman yang sedang aktif, sehingga
 * komponen seperti sidebar dapat menyorot menu yang tepat.
 * ------------------------------------------------------
 */

/**
 * Mengambil nama halaman aktif dari atribut
 * data-page yang didefinisikan pada tag <body>.
 * Contoh: <body data-page="dashboard">
 * @returns {string}
 */
export function getCurrentPage() {
  return document.body.dataset.page || "";
}

/**
 * Mengambil judul halaman aktif dari atribut
 * data-title yang didefinisikan pada tag <body>.
 * Contoh: <body data-page="dashboard" data-title="Dashboard">
 * @returns {string}
 */
export function getCurrentPageTitle() {
  return document.body.dataset.title || "";
}
