/**
 * utils/modal.js
 * ------------------------------------------------------
 * Perilaku reusable untuk komponen Modal.
 *
 * Markup standar yang diharapkan:
 * <div class="modal-overlay" id="modal-contoh">
 *   <div class="modal">
 *     <div class="modal__header">...</div>
 *     <div class="modal__body">...</div>
 *     <div class="modal__footer">...</div>
 *   </div>
 * </div>
 *
 * Elemen pemicu buka modal:
 * <button data-modal-target="modal-contoh">Buka</button>
 *
 * Elemen penutup di dalam modal:
 * <button data-modal-close>Tutup</button>
 * ------------------------------------------------------
 */

/**
 * Membuka modal berdasarkan id.
 * @param {string} modalId
 */
export function openModal(modalId) {
  const overlay = document.getElementById(modalId);
  if (!overlay) return;

  overlay.classList.add("is-open");
  document.body.style.overflow = "hidden";
}

/**
 * Menutup modal berdasarkan id.
 * @param {string} modalId
 */
export function closeModal(modalId) {
  const overlay = document.getElementById(modalId);
  if (!overlay) return;

  overlay.classList.remove("is-open");
  document.body.style.overflow = "";
}

/**
 * Menutup seluruh modal yang sedang terbuka.
 */
function closeAllModals() {
  document.querySelectorAll(".modal-overlay.is-open").forEach((overlay) => {
    overlay.classList.remove("is-open");
  });
  document.body.style.overflow = "";
}

/**
 * Menginisialisasi seluruh trigger buka/tutup modal pada halaman.
 * Panggil sekali saat halaman dimuat.
 */
export function initModals(root = document) {
  // Tombol pembuka modal
  root.querySelectorAll("[data-modal-target]").forEach((trigger) => {
    trigger.addEventListener("click", () => {
      const targetId = trigger.getAttribute("data-modal-target");
      openModal(targetId);
    });
  });

  // Tombol penutup di dalam modal
  root.querySelectorAll("[data-modal-close]").forEach((closeBtn) => {
    closeBtn.addEventListener("click", () => {
      const overlay = closeBtn.closest(".modal-overlay");
      if (overlay) overlay.classList.remove("is-open");
      document.body.style.overflow = "";
    });
  });

  // Klik di luar area modal (pada overlay) untuk menutup
  root.querySelectorAll(".modal-overlay").forEach((overlay) => {
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) {
        overlay.classList.remove("is-open");
        document.body.style.overflow = "";
      }
    });
  });

  // Tombol Esc untuk menutup modal aktif
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeAllModals();
  });
}
