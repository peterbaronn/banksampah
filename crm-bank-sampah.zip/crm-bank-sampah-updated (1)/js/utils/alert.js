/**
 * utils/alert.js
 * ------------------------------------------------------
 * Alert bergaya modern (Toast) yang muncul di tengah atas.
 * Tidak menggeser layout dan hilang otomatis (Auto-close).
 * ------------------------------------------------------
 */

export function initAlerts(root = document) {
  root.querySelectorAll("[data-alert-close]").forEach((closeBtn) => {
    closeBtn.addEventListener("click", () => {
      const alertEl = closeBtn.closest(".alert");
      if (alertEl) {
        alertEl.remove();
      }
    });
  });
}

export function showAlert(containerSelector, type, title, message, timeout = 4000) {
  // 1. Buat kontainer khusus yang melayang jika belum ada
  let toastContainer = document.querySelector(".alert-toast-container");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.className = "alert-toast-container";
    document.body.appendChild(toastContainer);
  }

  const icons = {
    success: "check_circle",
    warning: "warning",
    danger: "error",
    info: "info",
  };

  // 2. Buat elemen alert
  const alertEl = document.createElement("div");
  alertEl.className = `alert alert--${type}`;
  alertEl.innerHTML = `
    <span class="material-symbols-outlined">${icons[type] || "info"}</span>
    <div class="alert__content">
      <div class="alert__title">${title}</div>
      <p>${message}</p>
    </div>
    <button type="button" class="alert__close" data-alert-close>
      <span class="material-symbols-outlined">close</span>
    </button>
  `;

  // 3. Masukkan ke dalam pop-up container (mengabaikan container lama)
  toastContainer.prepend(alertEl);
  initAlerts(alertEl);

  // 4. Logika otomatis hilang setelah X detik
  if (timeout > 0) {
    setTimeout(() => {
      if (alertEl.parentNode) {
        // Berikan efek memudar sebelum dihapus dari layar
        alertEl.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        alertEl.style.opacity = '0';
        alertEl.style.transform = 'translateY(-10px)';
        
        // Hapus elemen dari sistem setelah animasi selesai
        setTimeout(() => alertEl.remove(), 400); 
      }
    }, timeout);
  }
}