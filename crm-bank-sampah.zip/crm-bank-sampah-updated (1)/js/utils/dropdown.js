/**
 * utils/dropdown.js
 * ------------------------------------------------------
 * Perilaku reusable untuk komponen Dropdown.
 * Menangani buka/tutup dropdown, serta menutup otomatis
 * saat klik di luar area dropdown atau menekan tombol Esc.
 * ------------------------------------------------------
 */

/**
 * Menginisialisasi satu pasang trigger + menu dropdown.
 * @param {HTMLElement} trigger - elemen yang diklik untuk membuka dropdown
 * @param {HTMLElement} menu - elemen menu dropdown yang akan ditampilkan
 */
export function initDropdown(trigger, menu) {
  if (!trigger || !menu) return;

  const close = () => menu.classList.remove("is-open");
  const toggle = (event) => {
    event.stopPropagation();
    menu.classList.toggle("is-open");
  };

  trigger.addEventListener("click", toggle);

  document.addEventListener("click", (event) => {
    if (!menu.contains(event.target) && !trigger.contains(event.target)) {
      close();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
  });

  // Menutup dropdown saat salah satu item di dalamnya diklik
  menu.querySelectorAll(".dropdown__item").forEach((item) => {
    item.addEventListener("click", close);
  });
}

/**
 * Menginisialisasi seluruh dropdown pada halaman berdasarkan
 * struktur markup standar:
 * <div class="dropdown">
 *   <button data-dropdown-trigger>...</button>
 *   <div class="dropdown__menu" data-dropdown-menu>...</div>
 * </div>
 */
export function initAllDropdowns(root = document) {
  root.querySelectorAll(".dropdown").forEach((wrapper) => {
    const trigger = wrapper.querySelector("[data-dropdown-trigger]");
    const menu = wrapper.querySelector(".dropdown__menu");
    if (trigger && menu) {
      initDropdown(trigger, menu);
    }
  });
}
