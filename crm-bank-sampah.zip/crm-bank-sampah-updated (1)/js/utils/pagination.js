/**
 * utils/pagination.js
 * ------------------------------------------------------
 * Komponen Pagination reusable. Merender kontrol
 * pagination ke dalam container dan memanggil callback
 * saat pengguna berpindah halaman.
 * ------------------------------------------------------
 */

/**
 * Merender pagination.
 * @param {Object} options
 * @param {string} options.container - selector container pagination
 * @param {number} options.currentPage - halaman aktif (mulai dari 1)
 * @param {number} options.totalPages - jumlah total halaman
 * @param {number} [options.totalItems] - jumlah total data (opsional, untuk info teks)
 * @param {number} [options.pageSize] - jumlah data per halaman (opsional)
 * @param {(page: number) => void} options.onPageChange - callback saat halaman berubah
 */
export function renderPagination({
  container,
  currentPage = 1,
  totalPages = 1,
  totalItems,
  pageSize,
  onPageChange = () => {},
}) {
  const el = document.querySelector(container);
  if (!el) return;

  const infoText =
    totalItems != null && pageSize != null
      ? `Menampilkan ${Math.min((currentPage - 1) * pageSize + 1, totalItems)}–${Math.min(
          currentPage * pageSize,
          totalItems
        )} dari ${totalItems} data`
      : `Halaman ${currentPage} dari ${totalPages}`;

  const pageButtons = buildPageNumbers(currentPage, totalPages)
    .map((page) => {
      if (page === "...") {
        return `<span class="pagination__btn" style="pointer-events:none;">&hellip;</span>`;
      }
      const activeClass = page === currentPage ? "is-active" : "";
      return `<button type="button" class="pagination__btn ${activeClass}" data-page="${page}">${page}</button>`;
    })
    .join("");

  el.innerHTML = `
    <span class="pagination__info">${infoText}</span>
    <div class="pagination__controls">
      <button type="button" class="pagination__btn" data-page="prev" ${currentPage <= 1 ? "disabled" : ""}>
        <span class="material-symbols-outlined" style="font-size:18px;">chevron_left</span>
      </button>
      ${pageButtons}
      <button type="button" class="pagination__btn" data-page="next" ${currentPage >= totalPages ? "disabled" : ""}>
        <span class="material-symbols-outlined" style="font-size:18px;">chevron_right</span>
      </button>
    </div>
  `;

  el.querySelectorAll("[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const value = btn.dataset.page;
      if (value === "prev") return onPageChange(Math.max(1, currentPage - 1));
      if (value === "next") return onPageChange(Math.min(totalPages, currentPage + 1));
      onPageChange(Number(value));
    });
  });
}

/**
 * Memotong array data sesuai halaman aktif.
 * @param {Array} data - seluruh data (setelah filter/pencarian)
 * @param {number} page - halaman yang diminta (mulai dari 1)
 * @param {number} pageSize - jumlah data per halaman
 * @returns {{items: Array, page: number, totalPages: number, totalItems: number}}
 */
export function paginate(data, page, pageSize) {
  const totalItems = data.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(Math.max(1, page || 1), totalPages);
  const start = (safePage - 1) * pageSize;
  return {
    items: data.slice(start, start + pageSize),
    page: safePage,
    totalPages,
    totalItems,
  };
}

function buildPageNumbers(current, total) {
  const delta = 1;
  const pages = [];

  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= current - delta && i <= current + delta)) {
      pages.push(i);
    } else if (pages[pages.length - 1] !== "...") {
      pages.push("...");
    }
  }

  return pages;
}
