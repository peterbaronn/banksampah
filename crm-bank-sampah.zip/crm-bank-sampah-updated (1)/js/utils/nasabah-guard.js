/**
 * utils/nasabah-guard.js
 * ------------------------------------------------------
 * Guard akses khusus untuk seluruh halaman Portal Nasabah
 * (pages/user-*.html). Bagian dari Struktur Akses Admin vs User:
 *  - Memastikan ada sesi login yang valid.
 *  - Memastikan akun ini benar terdaftar sebagai Nasabah
 *    (punya baris di tabel "customers").
 *  - Jika akun ini justru akun Admin/Staff, alihkan ke
 *    Dashboard Admin (Admin tidak perlu portal Nasabah).
 *
 * Dipakai di setiap js/pages/user-*.js seperti ini:
 *
 *   import { requireNasabahProfile } from "../utils/nasabah-guard.js";
 *   const profile = await requireNasabahProfile();
 *   if (!profile) return; // guard sudah menangani redirect
 * ------------------------------------------------------
 */

import { getSession, getUserRole } from "../../supabase/auth.js";
import { getNasabahProfile } from "../../supabase/nasabah.js";

export async function requireNasabahProfile() {
  const { session } = await getSession();

  if (!session) {
    window.location.replace("/pages/login.html");
    return null;
  }

  const { profile, error } = await getNasabahProfile(session.user.id);

  if (error || !profile) {
    // Belum tentu akun tidak valid — bisa jadi ini akun Admin/Staff
    // yang salah membuka portal Nasabah. Cek dulu sebelum menendang ke login.
    const { role } = await getUserRole(session.user.id);

    if (role === "admin") {
      window.location.replace("/pages/dashboard.html");
      return null;
    }

    console.warn("[Nasabah Guard] Akun ini belum tertaut ke data nasabah.");
    window.location.replace("/pages/login.html");
    return null;
  }

  return profile;
}
