/**
 * app.js
 * ------------------------------------------------------
 * Entry point utama aplikasi. Di-import oleh setiap
 * halaman (via <script type="module">) untuk menyusun
 * layout dasar (sidebar, navbar, footer) dan mengaktifkan
 * perilaku komponen UI global (modal, alert, dropdown).
 *
 * * TAHAP 3 UPDATE: Penambahan Auth Guard global.
 * ------------------------------------------------------
 */

import { CONFIG } from "./config.js";
import { getCurrentPage, getCurrentPageTitle } from "./router.js";
import { initSidebar } from "./components/sidebar.js";
import { initNavbar } from "./components/navbar.js";
import { initFooter } from "./components/footer.js";
import { initModals } from "./utils/modal.js";
import { initAlerts } from "./utils/alert.js";
import { initAllDropdowns } from "./utils/dropdown.js";
import { getSession, getUserRole } from "../supabase/auth.js"; // Import Auth Service

async function bootstrapLayout() {
  // === AUTH GUARD START ===
  try {
    const { session, error } = await getSession();
    
    // Tangani kemungkinan API putus atau fetch error
    if (error && error.message.includes("Failed to fetch")) {
      console.warn("[Auth Guard] Koneksi internet bermasalah.");
    }

    // Jika tidak ada session / token expired, tendang ke login
    if (!session) {
      window.location.replace("/pages/login.html");
      return; // Hentikan render sisa komponen
    }

    // === STRUKTUR AKSES ADMIN vs USER ===
    // Halaman-halaman yang memuat app.js ini (lewat sidebar/navbar Admin)
    // adalah area khusus Admin/Staff. Jika ternyata akun yang login
    // adalah akun Nasabah, alihkan ke portal Nasabah miliknya sendiri
    // supaya nasabah tidak bisa mengakses data/panel Admin.
    const { role } = await getUserRole(session.user.id);

    if (role === "nasabah") {
      window.location.replace("/pages/user-dashboard.html");
      return;
    }

    if (role !== "admin") {
      // Akun ini tidak terdaftar sebagai Admin maupun Nasabah (data tidak lengkap)
      console.warn("[Auth Guard] Akun tidak memiliki profil Admin maupun Nasabah.");
      window.location.replace("/pages/login.html");
      return;
    }
  } catch (err) {
    console.error("[Auth Guard] Gagal memverifikasi sesi:", err);
    window.location.replace("/pages/login.html");
    return;
  }
  // === AUTH GUARD END ===

  document.title = `${getCurrentPageTitle() || CONFIG.APP_NAME} | ${CONFIG.APP_NAME}`;

  const currentPage = getCurrentPage();
  const currentTitle = getCurrentPageTitle();

  await Promise.all([
    initSidebar("#app-sidebar", currentPage),
    initNavbar("#app-navbar", currentTitle),
    initFooter("#app-footer"),
  ]);

  // Inisialisasi komponen UI global yang ada di dalam konten halaman
  initModals();
  initAlerts();
  initAllDropdowns();
}

document.addEventListener("DOMContentLoaded", bootstrapLayout);