/**
 * pages/customer-service.js
 * ------------------------------------------------------
 * Logika halaman Customer Service (Admin):
 *  - FAQ (CRUD, tampil di Portal Nasabah)
 *  - Chatbot (aturan balasan otomatis, CRUD)
 *  - Call Request & Appointment Booking (kelola permintaan nasabah)
 *  - Log Interaksi / Tiket Bantuan (sudah ada sebelumnya)
 * ------------------------------------------------------
 */

import {
  getCustomerServices,
  createCustomerService,
  updateCustomerService,
  deleteCustomerService,
  getFaqs,
  createFaq,
  updateFaq,
  deleteFaq,
  getChatbotRules,
  createChatbotRule,
  updateChatbotRule,
  deleteChatbotRule,
} from "../../supabase/customer-service.js";
import { getAllServiceRequests, updateServiceRequest, deleteServiceRequest } from "../../supabase/service-requests.js";
import { getCustomers } from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const formatDateTime = (isoString) => {
    const d = new Date(isoString);
    return `${d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" })} • ${d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}`;
  };
  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const PAGE_SIZE = 10;
  let csPage = 1;
  let requestPage = 1;

  // ==========================================================
  // 1. TIKET BANTUAN (Log Interaksi) — sudah ada sebelumnya
  // ==========================================================
  const tbody = document.getElementById("cs-tbody");
  const selectCustomer = document.getElementById("cs-customer");
  let csData = [];

  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getCustomerServices();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    csData = data || [];
    document.getElementById("stat-total-tickets").textContent = csData.length.toLocaleString("id-ID");
    document.getElementById("stat-open-tickets").textContent = csData.filter((c) => c.status === "Terbuka").length.toLocaleString("id-ID");

    csPage = 1;
    renderCsTable();
  }

  function renderCsTable() {
    if (csData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada tiket bantuan.</td></tr>`;
      document.getElementById("cs-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(csData, csPage, PAGE_SIZE);
    csPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((item) => {
      let badgeClass = "badge--danger";
      if (item.status === "Dijawab") badgeClass = "badge--info";
      if (item.status === "Ditutup") badgeClass = "badge--success";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="text-sm text-muted">${formatDateTime(item.created_at)}</td>
        <td class="font-medium">${item.customers?.full_name || "Nasabah Dihapus"}</td>
        <td class="text-sm">${item.category}</td>
        <td>
          <div class="text-sm" style="max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${item.message}
          </div>
        </td>
        <td><span class="badge ${badgeClass}">${item.status}</span></td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${item.id}" aria-label="Edit Status">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${item.id}" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#cs-pagination",
      currentPage: csPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        csPage = p;
        renderCsTable();
      },
    });
  }

  async function populateCustomerSelect() {
    const { data } = await getCustomers();
    if (data) {
      selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
      data
        .filter((c) => c.status === "Aktif")
        .forEach((cust) => {
          const option = document.createElement("option");
          option.value = cust.id;
          option.textContent = cust.full_name;
          selectCustomer.appendChild(option);
        });
    }
  }

  const formAdd = document.getElementById("form-add-cs");
  const btnSave = document.getElementById("btn-save-cs");

  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      customer_id: document.getElementById("cs-customer").value,
      category: document.getElementById("cs-category").value,
      message: document.getElementById("cs-message").value.trim(),
    };

    btnSave.disabled = true;
    const { error } = await createCustomerService(newData);
    btnSave.disabled = false;

    if (!error) {
      closeModal("modal-add-cs");
      formAdd.reset();
      loadTableData();
      showAlert("#cs-alert-container", "success", "Berhasil", "Tiket bantuan berhasil dicatat.");
    } else {
      showAlert("#cs-alert-container", "danger", "Gagal Menyimpan", error.message);
    }
  });

  tbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const item = csData.find((s) => s.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-cs-id").value = item.id;
        document.getElementById("edit-cs-status").value = item.status;
        openModal("modal-edit-cs");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-cs-id").value = btnDelete.dataset.id;
      openModal("modal-delete-cs");
    }
  });

  document.getElementById("form-edit-cs").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-cs-id").value;
    const updatedData = { status: document.getElementById("edit-cs-status").value };

    const { error } = await updateCustomerService(id, updatedData);
    if (!error) {
      closeModal("modal-edit-cs");
      loadTableData();
      showAlert("#cs-alert-container", "success", "Diperbarui", "Status tiket berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete").addEventListener("click", async () => {
    const id = document.getElementById("delete-cs-id").value;
    const { error } = await deleteCustomerService(id);
    if (!error) {
      closeModal("modal-delete-cs");
      loadTableData();
      showAlert("#cs-alert-container", "info", "Dihapus", "Catatan tiket/bantuan telah dihapus.");
    }
  });

  // ==========================================================
  // 2. FAQ MANAGEMENT
  // ==========================================================
  const faqTbody = document.getElementById("faq-tbody");
  let faqData = [];

  async function loadFaqs() {
    faqTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getFaqs();

    if (error) {
      faqTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat FAQ: ${error.message}</td></tr>`;
      return;
    }

    faqData = data || [];
    document.getElementById("stat-active-faqs").textContent = faqData.filter((f) => f.is_published).length.toLocaleString("id-ID");

    faqTbody.innerHTML = faqData.length
      ? faqData
          .map(
            (f) => `
        <tr>
          <td class="text-sm text-muted">${f.sort_order}</td>
          <td class="font-medium text-sm">${f.question}</td>
          <td><span class="badge ${f.is_published ? "badge--success" : "badge--neutral"}">${f.is_published ? "Tampil" : "Disembunyikan"}</span></td>
          <td>
            <div class="table__actions">
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-faq" data-id="${f.id}"><span class="material-symbols-outlined">edit</span></button>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-faq" data-id="${f.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
            </div>
          </td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada FAQ.</td></tr>`;
  }

  document.getElementById("form-add-faq").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      question: document.getElementById("faq-question").value.trim(),
      answer: document.getElementById("faq-answer").value.trim(),
      sort_order: parseInt(document.getElementById("faq-order").value, 10) || 0,
    };
    const { error } = await createFaq(newData);
    if (!error) {
      closeModal("modal-add-faq");
      e.target.reset();
      loadFaqs();
      showAlert("#cs-alert-container", "success", "Berhasil", "FAQ baru ditambahkan.");
    } else {
      showAlert("#cs-alert-container", "danger", "Gagal", "Pastikan migrasi tabel faqs sudah dijalankan.");
    }
  });

  faqTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-faq");
    if (btnEdit) {
      const item = faqData.find((f) => f.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-faq-id").value = item.id;
        document.getElementById("edit-faq-question").value = item.question;
        document.getElementById("edit-faq-answer").value = item.answer;
        document.getElementById("edit-faq-order").value = item.sort_order;
        document.getElementById("edit-faq-published").value = String(item.is_published);
        openModal("modal-edit-faq");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-faq");
    if (btnDelete) {
      document.getElementById("delete-faq-id").value = btnDelete.dataset.id;
      openModal("modal-delete-faq");
    }
  });

  document.getElementById("form-edit-faq").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-faq-id").value;
    const updatedData = {
      question: document.getElementById("edit-faq-question").value.trim(),
      answer: document.getElementById("edit-faq-answer").value.trim(),
      sort_order: parseInt(document.getElementById("edit-faq-order").value, 10) || 0,
      is_published: document.getElementById("edit-faq-published").value === "true",
    };
    const { error } = await updateFaq(id, updatedData);
    if (!error) {
      closeModal("modal-edit-faq");
      loadFaqs();
      showAlert("#cs-alert-container", "success", "Diperbarui", "FAQ berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-faq").addEventListener("click", async () => {
    const id = document.getElementById("delete-faq-id").value;
    const { error } = await deleteFaq(id);
    if (!error) {
      closeModal("modal-delete-faq");
      loadFaqs();
      showAlert("#cs-alert-container", "info", "Dihapus", "FAQ telah dihapus.");
    }
  });

  // ==========================================================
  // 3. CHATBOT RULES
  // ==========================================================
  const ruleTbody = document.getElementById("rule-tbody");
  let ruleData = [];

  async function loadRules() {
    ruleTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getChatbotRules();

    if (error) {
      ruleTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat aturan: ${error.message}</td></tr>`;
      return;
    }

    ruleData = data || [];

    ruleTbody.innerHTML = ruleData.length
      ? ruleData
          .map(
            (r) => `
        <tr>
          <td class="text-sm font-medium">${r.keyword}</td>
          <td class="text-sm" style="max-width: 280px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${r.response}</td>
          <td><span class="badge ${r.is_active ? "badge--success" : "badge--neutral"}">${r.is_active ? "Aktif" : "Nonaktif"}</span></td>
          <td>
            <div class="table__actions">
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-rule" data-id="${r.id}"><span class="material-symbols-outlined">edit</span></button>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-rule" data-id="${r.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
            </div>
          </td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada aturan chatbot.</td></tr>`;
  }

  document.getElementById("form-add-rule").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      keyword: document.getElementById("rule-keyword").value.trim(),
      response: document.getElementById("rule-response").value.trim(),
    };
    const { error } = await createChatbotRule(newData);
    if (!error) {
      closeModal("modal-add-rule");
      e.target.reset();
      loadRules();
      showAlert("#cs-alert-container", "success", "Berhasil", "Aturan chatbot ditambahkan.");
    } else {
      showAlert("#cs-alert-container", "danger", "Gagal", "Pastikan migrasi tabel chatbot_rules sudah dijalankan.");
    }
  });

  ruleTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-rule");
    if (btnEdit) {
      const item = ruleData.find((r) => r.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-rule-id").value = item.id;
        document.getElementById("edit-rule-keyword").value = item.keyword;
        document.getElementById("edit-rule-response").value = item.response;
        document.getElementById("edit-rule-active").value = String(item.is_active);
        openModal("modal-edit-rule");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-rule");
    if (btnDelete) {
      document.getElementById("delete-rule-id").value = btnDelete.dataset.id;
      openModal("modal-delete-rule");
    }
  });

  document.getElementById("form-edit-rule").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-rule-id").value;
    const updatedData = {
      keyword: document.getElementById("edit-rule-keyword").value.trim(),
      response: document.getElementById("edit-rule-response").value.trim(),
      is_active: document.getElementById("edit-rule-active").value === "true",
    };
    const { error } = await updateChatbotRule(id, updatedData);
    if (!error) {
      closeModal("modal-edit-rule");
      loadRules();
      showAlert("#cs-alert-container", "success", "Diperbarui", "Aturan chatbot berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-rule").addEventListener("click", async () => {
    const id = document.getElementById("delete-rule-id").value;
    const { error } = await deleteChatbotRule(id);
    if (!error) {
      closeModal("modal-delete-rule");
      loadRules();
      showAlert("#cs-alert-container", "info", "Dihapus", "Aturan chatbot telah dihapus.");
    }
  });

  // ==========================================================
  // 4. CALL REQUEST & APPOINTMENT BOOKING
  // ==========================================================
  const requestTbody = document.getElementById("service-request-tbody");
  let requestData = [];

  async function loadServiceRequests() {
    requestTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getAllServiceRequests();

    if (error) {
      requestTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    requestData = data || [];
    document.getElementById("stat-pending-requests").textContent = requestData.filter((r) => r.status === "Menunggu").length.toLocaleString("id-ID");

    requestPage = 1;
    renderRequestsTable();
  }

  function renderRequestsTable() {
    if (requestData.length === 0) {
      requestTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada permintaan layanan.</td></tr>`;
      document.getElementById("service-request-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(requestData, requestPage, PAGE_SIZE);
    requestPage = page;

    requestTbody.innerHTML = pageItems
          .map((r) => {
            let badgeClass = "badge--warning";
            if (r.status === "Diproses") badgeClass = "badge--info";
            if (r.status === "Selesai") badgeClass = "badge--success";
            return `
          <tr>
            <td class="text-sm text-muted">${formatDate(r.created_at)}</td>
            <td class="font-medium">${r.customers?.full_name || "Nasabah Dihapus"}</td>
            <td class="text-sm">${r.type === "appointment" ? "Janji Temu" : "Minta Ditelepon"}</td>
            <td class="text-sm">${r.preferred_time || "-"}</td>
            <td><span class="badge ${badgeClass}">${r.status}</span></td>
            <td>
              <div class="table__actions">
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-request" data-id="${r.id}"><span class="material-symbols-outlined">edit</span></button>
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-request" data-id="${r.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
              </div>
            </td>
          </tr>`;
          })
          .join("");

    renderPagination({
      container: "#service-request-pagination",
      currentPage: requestPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        requestPage = p;
        renderRequestsTable();
      },
    });
  }

  requestTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-request");
    if (btnEdit) {
      const item = requestData.find((r) => r.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-request-id").value = item.id;
        document.getElementById("edit-request-status").value = item.status;
        openModal("modal-edit-request");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-request");
    if (btnDelete) {
      document.getElementById("delete-request-id").value = btnDelete.dataset.id;
      openModal("modal-delete-request");
    }
  });

  document.getElementById("form-edit-request").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-request-id").value;
    const updatedData = { status: document.getElementById("edit-request-status").value };
    const { error } = await updateServiceRequest(id, updatedData);
    if (!error) {
      closeModal("modal-edit-request");
      loadServiceRequests();
      showAlert("#cs-alert-container", "success", "Diperbarui", "Status permintaan berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-request").addEventListener("click", async () => {
    const id = document.getElementById("delete-request-id").value;
    const { error } = await deleteServiceRequest(id);
    if (!error) {
      closeModal("modal-delete-request");
      loadServiceRequests();
      showAlert("#cs-alert-container", "info", "Dihapus", "Permintaan layanan telah dihapus.");
    }
  });

  // Inisialisasi awal
  loadTableData();
  populateCustomerSelect();
  loadFaqs();
  loadRules();
  loadServiceRequests();
});
