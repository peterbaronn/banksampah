import { getNasabahTransactions, getNasabahRewards, requestReward } from "../../supabase/nasabah.js";
import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  let currentBalance = 0;
  
  // Hitung Saldo
  const { data: tx } = await getNasabahTransactions(profile.id);
  if (tx) {
    tx.forEach(t => { if (t.status === 'Selesai') currentBalance += parseFloat(t.total_reward || 0); });
  }
  
  // Kurangi saldo dengan riwayat penukaran yang Disetujui/Menunggu
  const { data: rw } = await getNasabahRewards(profile.id);
  if (rw) {
    rw.forEach(r => {
      if (r.status === 'Disetujui' || r.status === 'Menunggu') {
        currentBalance -= parseFloat(r.points_used || 0);
      }
    });
  }

  document.getElementById("reward-balance").textContent = `Rp ${currentBalance.toLocaleString('id-ID')}`;

  // Logika Render Daftar Penukaran
  const listContainer = document.getElementById("list-reward");
  function renderList() {
    if (!rw || rw.length === 0) {
      listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada riwayat penukaran hadiah.</div>`;
      return;
    }

    listContainer.innerHTML = "";
    rw.forEach(item => {
      let badgeClass = "badge--warning";
      if (item.status === "Disetujui") badgeClass = "badge--success";
      if (item.status === "Ditolak") badgeClass = "badge--danger";

      const dateStr = new Date(item.created_at).toLocaleDateString('id-ID', {day: '2-digit', month: 'short'});
      const points = parseFloat(item.points_used).toLocaleString('id-ID');

      listContainer.innerHTML += `
        <div class="card flex items-center justify-between" style="padding: 12px 16px;">
          <div>
            <div class="font-medium text-sm text-brand">${item.reward_name}</div>
            <div class="text-caption text-muted mt-xs">${dateStr} • -Rp ${points}</div>
          </div>
          <span class="badge ${badgeClass}">${item.status}</span>
        </div>
      `;
    });
  }
  renderList();

  // Logika UI Input Tunai
  const selectItem = document.getElementById("r-item");
  const groupNominal = document.getElementById("group-nominal");
  const inputNominal = document.getElementById("r-nominal");
  
  selectItem.addEventListener("change", (e) => {
    groupNominal.style.display = e.target.value === "Tarik Tunai" ? "block" : "none";
    if (e.target.value !== "Tarik Tunai") inputNominal.value = "";
  });

  // Handle Form Submit
  const formReward = document.getElementById("form-reward");
  const btnSubmit = document.getElementById("btn-submit-reward");

  formReward.addEventListener("submit", async (e) => {
    e.preventDefault();
    const item = selectItem.value;
    let requiredPoints = 0;

    // Mapping harga barang
    if (item.includes("Beras 5kg")) requiredPoints = 65000;
    else if (item.includes("Minyak Goreng")) requiredPoints = 35000;
    else if (item.includes("Voucher Listrik")) requiredPoints = 52000;
    else if (item === "Tarik Tunai") requiredPoints = parseFloat(inputNominal.value);

    if (requiredPoints <= 0) return alert("Masukkan nominal penarikan yang valid.");
    
    if (currentBalance < requiredPoints) {
      return showAlert("#user-alert-container", "danger", "Saldo Tidak Cukup", "Saldo Anda tidak mencukupi untuk klaim ini.");
    }

    btnSubmit.disabled = true;
    const { error } = await requestReward({
      customer_id: profile.id,
      reward_name: item,
      points_used: requiredPoints,
      notes: "Diklaim via Aplikasi Nasabah"
    });
    btnSubmit.disabled = false;

    if (!error) {
      showAlert("#user-alert-container", "success", "Berhasil", "Pengajuan berhasil! Menunggu persetujuan Admin.");
      setTimeout(() => window.location.reload(), 2000); // Reload untuk update saldo
    } else {
      showAlert("#user-alert-container", "danger", "Gagal", error.message);
    }
  });
});