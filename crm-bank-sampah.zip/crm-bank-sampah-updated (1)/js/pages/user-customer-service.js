import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { getMyServiceRequests, createServiceRequest } from "../../supabase/service-requests.js";
import { getFaqs, getChatbotRules } from "../../supabase/customer-service.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });

  // ==========================================
  // FAQ (dikelola Admin lewat tabel "faqs".
  // Fallback ke konten statis jika migrasi belum dijalankan.)
  // ==========================================
  const fallbackFaqs = [
    { question: "Bagaimana cara menyetor sampah?", answer: "Pisahkan sampah sesuai kategori (plastik, kertas, logam, kaca, minyak jelantah), lalu ajukan booking penjemputan lewat menu Jemput, atau datang langsung ke kantor Bank Sampah." },
    { question: "Kapan saldo saya cair?", answer: "Saldo otomatis bertambah setelah petugas mengonfirmasi transaksi setoran berstatus 'Selesai'. Anda bisa memantaunya di menu Transaksi." },
    { question: "Bagaimana cara menukar poin reward?", answer: "Buka menu Hadiah, pilih hadiah yang diinginkan (voucher, cashback, atau sembako), lalu ajukan klaim. Admin akan memverifikasi sebelum hadiah diserahkan." },
    { question: "Apa itu Membership Level?", answer: "Tier keanggotaan (Bronze, Silver, Gold, Platinum) yang naik otomatis berdasarkan akumulasi saldo yang Anda kumpulkan dari setoran sampah." },
    { question: "Bagaimana cara mengajukan komplain?", answer: "Buka menu Profil > Pengaduan, isi formulir keluhan, dan pantau statusnya di halaman yang sama." },
  ];

  let chatbotRules = [];

  async function loadFaqAndChatbotRules() {
    const { data: faqData, error: faqError } = await getFaqs(true);
    const faqs = faqError || !faqData || faqData.length === 0 ? fallbackFaqs : faqData;

    document.getElementById("faq-list").innerHTML = faqs
      .map(
        (f) => `
      <details class="card" style="padding: 12px 16px;">
        <summary class="font-medium text-sm" style="cursor:pointer;">${f.question}</summary>
        <p class="text-caption text-muted mt-xs" style="line-height:1.5;">${f.answer}</p>
      </details>`
      )
      .join("");

    const { data: ruleData, error: ruleError } = await getChatbotRules(true);
    chatbotRules = ruleError || !ruleData ? [] : ruleData;
  }

  // ==========================================
  // CHATBOT (mengambil aturan dari tabel "chatbot_rules";
  // fallback ke aturan bawaan jika belum ada migrasi/aturan)
  // ==========================================
  const chatMessages = document.getElementById("chatbot-messages");
  const chatForm = document.getElementById("form-chatbot");
  const chatInput = document.getElementById("chatbot-input");

  function addBubble(text, fromUser) {
    const bubble = document.createElement("div");
    bubble.className = "text-caption";
    bubble.style.cssText = `padding: 8px 12px; border-radius: 12px; max-width: 85%; ${
      fromUser
        ? "background: var(--color-primary); color: white; align-self: flex-end;"
        : "background: var(--color-secondary); align-self: flex-start;"
    }`;
    bubble.textContent = text;
    chatMessages.appendChild(bubble);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function getBotReply(message) {
    const msg = message.toLowerCase();

    // 1. Coba cocokkan dengan aturan yang dikelola Admin
    for (const rule of chatbotRules) {
      const keywords = rule.keyword.split(",").map((k) => k.trim().toLowerCase());
      if (keywords.some((k) => k && msg.includes(k))) {
        return rule.response;
      }
    }

    // 2. Fallback bawaan jika belum ada aturan yang cocok/tersedia
    if (msg.includes("jadwal") || msg.includes("jemput")) {
      return "Untuk booking penjemputan, silakan buka menu Jemput dan isi tanggal serta waktu yang Anda inginkan.";
    }
    if (msg.includes("saldo")) {
      return "Saldo Anda bisa dicek di halaman Beranda atau menu Transaksi. Saldo bertambah setelah setoran berstatus Selesai.";
    }
    if (msg.includes("poin") || msg.includes("reward") || msg.includes("hadiah")) {
      return "Poin reward bisa ditukarkan di menu Hadiah. Semakin banyak setoran, semakin tinggi tier membership Anda.";
    }
    if (msg.includes("setor") || msg.includes("sampah")) {
      return "Pisahkan sampah sesuai jenisnya, lalu ajukan booking penjemputan lewat menu Jemput, atau antar langsung ke kantor kami.";
    }
    if (msg.includes("komplain") || msg.includes("pengaduan") || msg.includes("keluhan")) {
      return "Anda bisa mengajukan pengaduan di menu Profil > Pengaduan. Tim kami akan menindaklanjuti secepatnya.";
    }
    return "Maaf, saya belum memahami pertanyaan itu. Silakan hubungi admin lewat Live Chat WhatsApp di menu Pengaduan untuk bantuan lebih lanjut.";
  }

  chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;

    addBubble(message, true);
    chatInput.value = "";

    setTimeout(() => addBubble(getBotReply(message), false), 400);
  });

  // ==========================================
  // CALL REQUEST & APPOINTMENT BOOKING
  // ==========================================
  const listContainer = document.getElementById("list-service-requests");

  async function loadServiceRequests() {
    const { data, error } = await getMyServiceRequests(profile.id);

    if (error) {
      listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Fitur ini memerlukan migrasi database tambahan (tabel service_requests). Hubungi admin.</div>`;
      return;
    }

    if (!data || data.length === 0) {
      listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada permintaan yang diajukan.</div>`;
      return;
    }

    listContainer.innerHTML = "";
    data.forEach((item) => {
      let badgeClass = "badge--warning";
      if (item.status === "Diproses") badgeClass = "badge--info";
      if (item.status === "Selesai") badgeClass = "badge--success";

      listContainer.innerHTML += `
        <div class="card" style="padding: 12px 16px;">
          <div class="flex justify-between items-start">
            <div>
              <div class="font-medium text-sm">${item.type === "appointment" ? "Janji Temu" : "Minta Ditelepon"}</div>
              <div class="text-caption text-muted mt-xs">${formatDate(item.created_at)}${item.preferred_time ? " • " + item.preferred_time : ""}</div>
            </div>
            <span class="badge ${badgeClass}">${item.status}</span>
          </div>
        </div>
      `;
    });
  }

  document.getElementById("form-service-request").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-submit-service");
    const newData = {
      customer_id: profile.id,
      type: document.getElementById("sr-type").value,
      preferred_time: document.getElementById("sr-time").value.trim(),
      notes: document.getElementById("sr-notes").value.trim(),
    };

    btn.disabled = true;
    const { error } = await createServiceRequest(newData);
    btn.disabled = false;

    if (!error) {
      e.target.reset();
      showAlert("#user-alert-container", "success", "Terkirim", "Permintaan Anda sudah kami terima dan akan segera diproses.");
      loadServiceRequests();
    } else {
      showAlert("#user-alert-container", "danger", "Gagal Mengirim", "Fitur ini memerlukan migrasi database tambahan (tabel service_requests). Hubungi admin.");
    }
  });

  loadFaqAndChatbotRules();
  loadServiceRequests();
});
