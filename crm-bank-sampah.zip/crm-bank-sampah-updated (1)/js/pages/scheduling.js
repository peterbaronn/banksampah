/**
 * pages/scheduling.js
 * ------------------------------------------------------
 * Logika halaman Scheduling (Admin):
 *  - Booking Penjemputan (fitur lama)
 *  - Tracking Driver (CRUD driver + assign ke jadwal)
 *  - Estimasi Kedatangan (ETA)
 *  - Reschedule Jadwal
 * ------------------------------------------------------
 */

import {
  getSchedules,
  createSchedule,
  updateSchedule,
  deleteSchedule,
  rescheduleSchedule,
  getDrivers,
  createDriver,
  updateDriver,
  deleteDriver,
} from "../../supabase/scheduling.js";
import { getCustomers } from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const tbody = document.getElementById("schedules-tbody");
  const selectCustomer = document.getElementById("sched-customer");
  const editDriverSelect = document.getElementById("edit-sched-driver");
  let schedulesData = [];
  let driversData = [];
  const PAGE_SIZE = 10;
  let schedulesPage = 1;
  let driversPage = 1;

  const formatDate = (isoString) =>
    new Date(isoString).toLocaleDateString("id-ID", { weekday: "long", day: "2-digit", month: "short", year: "numeric" });

  // ==========================================================
  // 1. DAFTAR PENJADWALAN (Booking Penjemputan)
  // ==========================================================
  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getSchedules();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    schedulesData = data || [];
    document.getElementById("stat-total-schedules").textContent = schedulesData.length.toLocaleString("id-ID");
    document.getElementById("stat-scheduled").textContent = schedulesData.filter((s) => s.status === "Terjadwal").length.toLocaleString("id-ID");
    document.getElementById("stat-unassigned").textContent = schedulesData.filter((s) => s.status === "Terjadwal" && !s.driver_id).length.toLocaleString("id-ID");

    schedulesPage = 1;
    renderSchedulesTable();
  }

  function renderSchedulesTable() {
    if (schedulesData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada jadwal penjemputan.</td></tr>`;
      document.getElementById("schedules-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(schedulesData, schedulesPage, PAGE_SIZE);
    schedulesPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((sched) => {
      let badgeClass = "badge--info";
      if (sched.status === "Selesai") badgeClass = "badge--success";
      if (sched.status === "Dibatalkan") badgeClass = "badge--danger";

      const customer = sched.customers || {};
      const driver = sched.drivers;
      const driverInfo = driver
        ? `<div class="font-medium text-sm">${driver.name}</div><div class="text-caption text-muted">${sched.eta_minutes ? `ETA ~${sched.eta_minutes} menit` : driver.phone || ""}</div>`
        : '<span class="badge badge--neutral">Belum Ditugaskan</span>';

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>
          <div class="font-medium">${formatDate(sched.pickup_date)}</div>
          <div class="text-sm text-muted">Pukul ${sched.pickup_time}${sched.reschedule_count > 0 ? ` • <span class="text-warning">Reschedule ${sched.reschedule_count}x</span>` : ""}</div>
        </td>
        <td class="font-medium">${customer.full_name || "Nasabah Dihapus"}
          <div class="text-caption text-muted">${sched.address_notes || customer.address || "-"}</div>
        </td>
        <td>${customer.phone || "-"}</td>
        <td>${driverInfo}</td>
        <td><span class="badge ${badgeClass}">${sched.status}</span></td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-reschedule" data-id="${sched.id}" aria-label="Reschedule">
              <span class="material-symbols-outlined">event_repeat</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${sched.id}" aria-label="Kelola Jadwal">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${sched.id}" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#schedules-pagination",
      currentPage: schedulesPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        schedulesPage = p;
        renderSchedulesTable();
      },
    });
  }

  async function populateCustomerSelect() {
    const { data } = await getCustomers();
    if (data) {
      selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
      data
        .filter((c) => c.status === "Aktif")
        .forEach((cust) => {
          const option = document.createElement("option");
          option.value = cust.id;
          option.textContent = cust.full_name;
          selectCustomer.appendChild(option);
        });
    }
  }

  const formAdd = document.getElementById("form-add-schedule");
  const btnSave = document.getElementById("btn-save-schedule");

  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      customer_id: document.getElementById("sched-customer").value,
      pickup_date: document.getElementById("sched-date").value,
      pickup_time: document.getElementById("sched-time").value,
      address_notes: document.getElementById("sched-address").value.trim(),
    };

    btnSave.disabled = true;
    const { error } = await createSchedule(newData);
    btnSave.disabled = false;

    if (!error) {
      closeModal("modal-add-schedule");
      formAdd.reset();
      loadTableData();
      showAlert("#schedules-alert-container", "success", "Berhasil", "Jadwal penjemputan baru berhasil dibuat.");
    } else {
      showAlert("#schedules-alert-container", "danger", "Gagal", error.message);
    }
  });

  tbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const sched = schedulesData.find((s) => s.id === btnEdit.dataset.id);
      if (sched) {
        document.getElementById("edit-sched-id").value = sched.id;
        document.getElementById("edit-sched-status").value = sched.status;
        editDriverSelect.value = sched.driver_id || "";
        document.getElementById("edit-sched-eta").value = sched.eta_minutes || "";
        openModal("modal-edit-schedule");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-sched-id").value = btnDelete.dataset.id;
      openModal("modal-delete-schedule");
    }

    const btnReschedule = e.target.closest(".btn-reschedule");
    if (btnReschedule) {
      const sched = schedulesData.find((s) => s.id === btnReschedule.dataset.id);
      if (sched) {
        document.getElementById("reschedule-sched-id").value = sched.id;
        document.getElementById("reschedule-current-count").value = sched.reschedule_count || 0;
        document.getElementById("reschedule-date").value = sched.pickup_date;
        document.getElementById("reschedule-time").value = sched.pickup_time;
        openModal("modal-reschedule");
      }
    }
  });

  const formEdit = document.getElementById("form-edit-schedule");
  formEdit.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-sched-id").value;
    const updatedData = {
      status: document.getElementById("edit-sched-status").value,
      driver_id: editDriverSelect.value || null,
      eta_minutes: document.getElementById("edit-sched-eta").value ? parseInt(document.getElementById("edit-sched-eta").value, 10) : null,
    };

    const { error } = await updateSchedule(id, updatedData);
    if (!error) {
      closeModal("modal-edit-schedule");
      loadTableData();
      showAlert("#schedules-alert-container", "success", "Diperbarui", "Jadwal berhasil diperbarui.");
    } else {
      showAlert("#schedules-alert-container", "danger", "Gagal", "Pastikan migrasi kolom driver_id/eta_minutes sudah dijalankan.");
    }
  });

  document.getElementById("form-reschedule").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("reschedule-sched-id").value;
    const currentCount = parseInt(document.getElementById("reschedule-current-count").value, 10) || 0;
    const newDate = document.getElementById("reschedule-date").value;
    const newTime = document.getElementById("reschedule-time").value;

    const { error } = await rescheduleSchedule(id, newDate, newTime, currentCount);
    if (!error) {
      closeModal("modal-reschedule");
      loadTableData();
      showAlert("#schedules-alert-container", "success", "Dijadwalkan Ulang", "Jadwal penjemputan berhasil diubah.");
    } else {
      showAlert("#schedules-alert-container", "danger", "Gagal", "Pastikan migrasi kolom reschedule_count sudah dijalankan.");
    }
  });

  const btnConfirmDelete = document.getElementById("btn-confirm-delete");
  btnConfirmDelete.addEventListener("click", async () => {
    const id = document.getElementById("delete-sched-id").value;
    const { error } = await deleteSchedule(id);
    if (!error) {
      closeModal("modal-delete-schedule");
      loadTableData();
      showAlert("#schedules-alert-container", "info", "Dihapus", "Jadwal penjemputan telah dibatalkan/dihapus.");
    }
  });

  // ==========================================================
  // 2. TRACKING DRIVER (CRUD)
  // ==========================================================
  const driverTbody = document.getElementById("driver-tbody");

  async function loadDrivers() {
    driverTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getDrivers();

    if (error) {
      driverTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-danger">Gagal memuat data. Pastikan migrasi tabel drivers sudah dijalankan.</td></tr>`;
      return;
    }

    driversData = data || [];
    document.getElementById("stat-active-drivers").textContent = driversData.filter((d) => d.status === "Aktif").length.toLocaleString("id-ID");

    // Isi dropdown assign driver di modal edit jadwal
    editDriverSelect.innerHTML =
      '<option value="">Belum Ditugaskan</option>' +
      driversData
        .filter((d) => d.status === "Aktif")
        .map((d) => `<option value="${d.id}">${d.name}</option>`)
        .join("");

    driversPage = 1;
    renderDriversTable();
  }

  function renderDriversTable() {
    if (driversData.length === 0) {
      driverTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-muted">Belum ada driver terdaftar.</td></tr>`;
      document.getElementById("driver-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(driversData, driversPage, PAGE_SIZE);
    driversPage = page;

    driverTbody.innerHTML = pageItems
          .map(
            (d) => `
        <tr>
          <td class="font-medium">${d.name}</td>
          <td class="text-sm">${d.phone || "-"}</td>
          <td class="text-sm">${d.vehicle_plate || "-"}</td>
          <td><span class="badge ${d.status === "Aktif" ? "badge--success" : "badge--neutral"}">${d.status}</span></td>
          <td>
            <div class="table__actions">
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-driver" data-id="${d.id}"><span class="material-symbols-outlined">edit</span></button>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-driver" data-id="${d.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
            </div>
          </td>
        </tr>`
          )
          .join("");

    renderPagination({
      container: "#driver-pagination",
      currentPage: driversPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        driversPage = p;
        renderDriversTable();
      },
    });
  }

  document.getElementById("form-add-driver").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      name: document.getElementById("driver-name").value.trim(),
      phone: document.getElementById("driver-phone").value.trim(),
      vehicle_plate: document.getElementById("driver-plate").value.trim(),
    };
    const { error } = await createDriver(newData);
    if (!error) {
      closeModal("modal-add-driver");
      e.target.reset();
      loadDrivers();
      showAlert("#schedules-alert-container", "success", "Berhasil", "Driver baru ditambahkan.");
    } else {
      showAlert("#schedules-alert-container", "danger", "Gagal", "Pastikan migrasi tabel drivers sudah dijalankan.");
    }
  });

  driverTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-driver");
    if (btnEdit) {
      const item = driversData.find((d) => d.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-driver-id").value = item.id;
        document.getElementById("edit-driver-name").value = item.name;
        document.getElementById("edit-driver-phone").value = item.phone || "";
        document.getElementById("edit-driver-plate").value = item.vehicle_plate || "";
        document.getElementById("edit-driver-status").value = item.status;
        openModal("modal-edit-driver");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-driver");
    if (btnDelete) {
      document.getElementById("delete-driver-id").value = btnDelete.dataset.id;
      openModal("modal-delete-driver");
    }
  });

  document.getElementById("form-edit-driver").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-driver-id").value;
    const updatedData = {
      name: document.getElementById("edit-driver-name").value.trim(),
      phone: document.getElementById("edit-driver-phone").value.trim(),
      vehicle_plate: document.getElementById("edit-driver-plate").value.trim(),
      status: document.getElementById("edit-driver-status").value,
    };
    const { error } = await updateDriver(id, updatedData);
    if (!error) {
      closeModal("modal-edit-driver");
      loadDrivers();
      loadTableData();
      showAlert("#schedules-alert-container", "success", "Diperbarui", "Data driver berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-driver").addEventListener("click", async () => {
    const id = document.getElementById("delete-driver-id").value;
    const { error } = await deleteDriver(id);
    if (!error) {
      closeModal("modal-delete-driver");
      loadDrivers();
      loadTableData();
      showAlert("#schedules-alert-container", "info", "Dihapus", "Driver telah dihapus.");
    }
  });

  // ==========================================================
  // INISIALISASI AWAL
  // ==========================================================
  (async () => {
    await loadDrivers();
    loadTableData();
    populateCustomerSelect();
  })();
});
