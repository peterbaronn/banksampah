import { getNasabahTransactions } from "../../supabase/nasabah.js";
import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  // 1 & 2. Cek Sesi + Ambil Profil Nasabah (lewat guard bersama)
  const profile = await requireNasabahProfile();
  if (!profile) return; // guard sudah menangani redirect

  // Tampilkan Nama
  document.getElementById("nasabah-name").textContent = profile.full_name;
  
  // 3. Ambil Transaksi & Hitung Saldo
  const { data: tx } = await getNasabahTransactions(profile.id);
  const listContainer = document.getElementById("transaction-list");
  listContainer.innerHTML = "";
  let totalBalance = 0;

  if (!tx || tx.length === 0) {
    listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada riwayat setoran sampah.</div>`;
  } else {
    tx.forEach(t => {
      // Kalkulasi saldo (hanya yang berstatus 'Selesai')
      if (t.status === 'Selesai') totalBalance += parseFloat(t.total_reward || 0);

      // Desain dinamis berdasarkan status
      let icon = "pending_actions";
      let color = "var(--color-warning)";
      if (t.status === "Selesai") { icon = "check_circle"; color = "var(--color-success)"; }
      if (t.status === "Dibatalkan") { icon = "cancel"; color = "var(--color-danger)"; }

      const dateStr = new Date(t.created_at).toLocaleDateString('id-ID', {day: '2-digit', month: 'short'});

      listContainer.innerHTML += `
        <div class="card flex items-center gap-md" style="padding: 12px 16px; margin-bottom: 2px;">
          <div style="color: ${color}; display:flex;"><span class="material-symbols-outlined">${icon}</span></div>
          <div class="flex-1">
            <div class="font-medium text-sm">${t.waste_type}</div>
            <div class="text-caption text-muted">${dateStr} • ${t.weight_kg} kg</div>
          </div>
          <div class="font-semibold text-sm" style="color: ${color};">
            +Rp ${parseFloat(t.total_reward || 0).toLocaleString('id-ID')}
          </div>
        </div>
      `;
    });
  }

  document.getElementById("nasabah-balance").textContent = `Rp ${totalBalance.toLocaleString('id-ID')}`;
});