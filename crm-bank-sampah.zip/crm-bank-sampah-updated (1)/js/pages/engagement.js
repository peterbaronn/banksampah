/**
 * pages/engagement.js
 * ------------------------------------------------------
 * Logika halaman Customer Engagement (Admin):
 *  - Notifikasi, Broadcast (WA/Email/SMS/In-App), Reminder
 *  - Ucapan Ulang Tahun
 *  - Campaign
 *  - Edukasi
 *  - Log Interaksi Manual (fitur lama)
 * ------------------------------------------------------
 */

import {
  getEngagements,
  createEngagement,
  updateEngagement,
  deleteEngagement,
  getNotifications,
  createNotification,
  broadcastToCustomers,
  deleteNotification,
  getBirthdaysThisMonth,
  getCampaigns,
  createCampaign,
  updateCampaign,
  deleteCampaign,
  getEducationalContent,
  createEducationalContent,
  updateEducationalContent,
  deleteEducationalContent,
} from "../../supabase/engagement.js";
import { getCustomers } from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatDateShort = (isoString) => (isoString ? new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short" }) : "-");
  const ENGAGEMENT_PAGE_SIZE = 10;
  let engagementPage = 1;

  let allCustomers = [];

  async function loadAllCustomers() {
    const { data } = await getCustomers();
    allCustomers = (data || []).filter((c) => c.status === "Aktif");
    return allCustomers;
  }

  // ==========================================================
  // WA BLAST RUNNER
  // ------------------------------------------------------
  // WhatsApp tidak punya API gratis untuk kirim otomatis massal.
  // Runner ini membuka wa.me dengan pesan siap kirim untuk tiap
  // nasabah secara berurutan — admin tinggal klik "Kirim" di dalam
  // WhatsApp, lalu klik "Lanjut" di sini untuk nomor berikutnya.
  // ==========================================================
  let waBlastQueue = [];
  let waBlastIndex = 0;
  let waBlastMessage = "";

  // Ubah nomor telepon lokal (0812..., 62812..., +62812...) jadi format
  // internasional tanpa "+" yang dibutuhkan wa.me (628123456789)
  function normalizePhoneForWa(phone) {
    if (!phone) return null;
    let digits = phone.replace(/\D/g, "");
    if (digits.startsWith("0")) digits = "62" + digits.slice(1);
    if (!digits.startsWith("62")) digits = "62" + digits;
    return digits;
  }

  function buildWaLink(phone, message) {
    const normalized = normalizePhoneForWa(phone);
    return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
  }

  function renderWaBlastQueueTable() {
    const tbody = document.getElementById("wa-blast-queue-tbody");
    tbody.innerHTML = waBlastQueue
      .map((item, idx) => {
        let statusBadge = '<span class="badge badge--neutral">Menunggu</span>';
        if (item.status === "sent") statusBadge = '<span class="badge badge--success">Terbuka</span>';
        if (item.status === "skipped") statusBadge = '<span class="badge badge--danger">Dilewati</span>';
        if (item.status === "invalid") statusBadge = '<span class="badge badge--danger">No. HP Tidak Valid</span>';
        const highlight = idx === waBlastIndex ? "background: var(--color-primary-light);" : "";
        return `<tr style="${highlight}"><td class="text-sm">${item.name}</td><td class="text-sm">${item.phone || "-"}</td><td>${statusBadge}</td></tr>`;
      })
      .join("");
  }

  function updateWaBlastProgress() {
    const total = waBlastQueue.length;
    const done = waBlastQueue.filter((q) => q.status !== "pending").length;
    document.getElementById("wa-blast-progress").textContent = `${done} / ${total}`;
    document.getElementById("wa-blast-progress-bar").style.width = total ? `${(done / total) * 100}%` : "0%";
    renderWaBlastQueueTable();

    const currentBox = document.getElementById("wa-blast-current");
    const btnNext = document.getElementById("btn-wa-blast-next");
    const btnSkip = document.getElementById("btn-wa-blast-skip");

    if (waBlastIndex >= waBlastQueue.length) {
      currentBox.innerHTML = `
        <span class="material-symbols-outlined" style="font-size: 40px; color: var(--color-success); display:block; margin-bottom:8px;">check_circle</span>
        <p class="font-medium">Semua nomor sudah diproses!</p>
        <p class="text-caption text-muted">${done} dari ${total} chat WhatsApp berhasil dibuka.</p>
      `;
      btnNext.disabled = true;
      btnSkip.disabled = true;
      return;
    }

    const current = waBlastQueue[waBlastIndex];
    btnNext.disabled = false;
    btnSkip.disabled = false;
    currentBox.innerHTML = `
      <div class="text-caption text-muted mb-xs">Nasabah ke-${waBlastIndex + 1} dari ${waBlastQueue.length}</div>
      <div class="font-semibold" style="font-size: 1.1rem;">${current.name}</div>
      <div class="text-muted text-sm">${current.phone || "Tidak ada nomor HP"}</div>
    `;

    if (!current.phone) {
      btnNext.disabled = true;
    }
  }

  function openWaBlastRunner(targets, message) {
    waBlastQueue = targets.map((c) => ({
      id: c.id,
      name: c.full_name,
      phone: c.phone ? c.phone.trim() : "",
      status: "pending",
    }));
    waBlastIndex = 0;
    waBlastMessage = message;
    updateWaBlastProgress();
    openModal("modal-wa-blast");
  }

  document.getElementById("btn-wa-blast-next").addEventListener("click", () => {
    const current = waBlastQueue[waBlastIndex];
    if (!current) return;

    if (!current.phone) {
      current.status = "invalid";
    } else {
      window.open(buildWaLink(current.phone, waBlastMessage), "_blank");
      current.status = "sent";
    }
    waBlastIndex += 1;
    updateWaBlastProgress();
  });

  document.getElementById("btn-wa-blast-skip").addEventListener("click", () => {
    const current = waBlastQueue[waBlastIndex];
    if (!current) return;
    current.status = "skipped";
    waBlastIndex += 1;
    updateWaBlastProgress();
  });


  // ==========================================================
  // 1. NOTIFIKASI, BROADCAST & REMINDER
  // ==========================================================
  const notifTbody = document.getElementById("notification-tbody");
  const notifTargetSelect = document.getElementById("notif-target");
  const notifCustomerGroup = document.getElementById("notif-customer-group");
  const notifCustomerSelect = document.getElementById("notif-customer");

  notifTargetSelect.addEventListener("change", () => {
    notifCustomerGroup.style.display = notifTargetSelect.value === "single" ? "block" : "none";
  });

  async function populateNotifCustomerSelect() {
    notifCustomerSelect.innerHTML = '<option value="">Pilih Nasabah...</option>';
    allCustomers.forEach((c) => {
      const option = document.createElement("option");
      option.value = c.id;
      option.textContent = c.full_name;
      notifCustomerSelect.appendChild(option);
    });
  }

  async function loadNotifications() {
    notifTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getNotifications();

    if (error) {
      notifTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    const notifications = data || [];
    document.getElementById("stat-total-notifications").textContent = notifications.length.toLocaleString("id-ID");

    // Tampilkan 30 terbaru saja agar ringan
    const recent = notifications.slice(0, 30);

    notifTbody.innerHTML = recent.length
      ? recent
          .map((n) => {
            const typeBadge = { Info: "badge--info", Promo: "badge--warning", Reminder: "badge--neutral", "Ulang Tahun": "badge--success" }[n.type] || "badge--neutral";
            return `
          <tr>
            <td class="text-sm text-muted">${formatDate(n.created_at)}</td>
            <td class="font-medium">${n.customer_id ? n.customers?.full_name || "Nasabah Dihapus" : '<span class="badge badge--info">Semua Nasabah</span>'}</td>
            <td><span class="badge ${typeBadge}">${n.type}</span></td>
            <td class="text-sm">${n.channel}</td>
            <td>
              <div class="font-medium text-sm">${n.title}</div>
              <div class="text-caption text-muted" style="max-width:220px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${n.message}</div>
            </td>
            <td>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-notif" data-id="${n.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
            </td>
          </tr>`;
          })
          .join("")
      : `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada notifikasi terkirim.</td></tr>`;
  }

  document.getElementById("form-add-notification").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-save-notification");
    const base = {
      title: document.getElementById("notif-title").value.trim(),
      message: document.getElementById("notif-message").value.trim(),
      type: document.getElementById("notif-type").value,
      channel: document.getElementById("notif-channel").value,
    };

    btn.disabled = true;
    let error;
    if (notifTargetSelect.value === "all") {
      const ids = allCustomers.map((c) => c.id);
      ({ error } = await broadcastToCustomers(ids, base));
    } else {
      const customerId = notifCustomerSelect.value;
      if (!customerId) {
        showAlert("#engagement-alert-container", "danger", "Pilih Nasabah", "Silakan pilih nasabah tujuan.");
        btn.disabled = false;
        return;
      }
      ({ error } = await createNotification({ ...base, customer_id: customerId }));
    }
    btn.disabled = false;

    if (!error) {
      closeModal("modal-add-notification");
      e.target.reset();
      loadNotifications();

      if (base.channel === "WhatsApp") {
        const targets = notifTargetSelect.value === "all"
          ? allCustomers
          : allCustomers.filter((c) => c.id === notifCustomerSelect.value);
        const waMessage = `${base.title}\n\n${base.message}`;
        openWaBlastRunner(targets, waMessage);
      } else {
        showAlert("#engagement-alert-container", "success", "Terkirim", "Notifikasi berhasil dikirim/dicatat.");
      }
    } else {
      showAlert("#engagement-alert-container", "danger", "Gagal Mengirim", "Pastikan migrasi tabel notifications sudah dijalankan.");
    }
  });

  notifTbody.addEventListener("click", async (e) => {
    const btnDelete = e.target.closest(".btn-delete-notif");
    if (btnDelete) {
      const { error } = await deleteNotification(btnDelete.dataset.id);
      if (!error) loadNotifications();
    }
  });

  // ==========================================================
  // 2. UCAPAN ULANG TAHUN
  // ==========================================================
  const birthdayTbody = document.getElementById("birthday-tbody");

  async function loadBirthdays() {
    birthdayTbody.innerHTML = `<tr><td colspan="3" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getBirthdaysThisMonth();

    if (error) {
      birthdayTbody.innerHTML = `<tr><td colspan="3" class="text-center p-md text-danger">Gagal memuat data. Pastikan migrasi kolom birth_date sudah dijalankan.</td></tr>`;
      document.getElementById("stat-birthdays").textContent = "-";
      return;
    }

    document.getElementById("stat-birthdays").textContent = data.length.toLocaleString("id-ID");

    birthdayTbody.innerHTML = data.length
      ? data
          .map(
            (c) => `
        <tr>
          <td class="font-medium">${c.full_name}</td>
          <td class="text-sm">${formatDateShort(c.birth_date)}</td>
          <td><button type="button" class="btn btn--secondary btn--sm btn-send-birthday" data-id="${c.id}" data-name="${c.full_name}"><span class="material-symbols-outlined" style="font-size:16px;">cake</span> Kirim Ucapan</button></td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="3" class="text-center p-md text-muted">Tidak ada nasabah yang berulang tahun bulan ini.</td></tr>`;
  }

  birthdayTbody.addEventListener("click", async (e) => {
    const btn = e.target.closest(".btn-send-birthday");
    if (btn) {
      btn.disabled = true;
      const { error } = await createNotification({
        customer_id: btn.dataset.id,
        title: "Selamat Ulang Tahun! 🎉",
        message: `Selamat ulang tahun, ${btn.dataset.name}! Terima kasih sudah menjadi bagian dari keluarga Bank Sampah kami. Semoga sehat dan sukses selalu.`,
        type: "Ulang Tahun",
        channel: "In-App",
      });
      btn.disabled = false;

      if (!error) {
        showAlert("#engagement-alert-container", "success", "Terkirim", "Ucapan ulang tahun berhasil dikirim.");
        loadNotifications();
      } else {
        showAlert("#engagement-alert-container", "danger", "Gagal", "Pastikan migrasi tabel notifications sudah dijalankan.");
      }
    }
  });

  // ==========================================================
  // 3. CAMPAIGN
  // ==========================================================
  const campaignTbody = document.getElementById("campaign-tbody");
  let campaignData = [];

  async function loadCampaigns() {
    campaignTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getCampaigns();

    if (error) {
      campaignTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    campaignData = data || [];
    document.getElementById("stat-active-campaigns").textContent = campaignData.filter((c) => c.status === "Aktif").length.toLocaleString("id-ID");

    campaignTbody.innerHTML = campaignData.length
      ? campaignData
          .map((c) => {
            let badgeClass = "badge--neutral";
            if (c.status === "Aktif") badgeClass = "badge--success";
            if (c.status === "Selesai") badgeClass = "badge--info";
            return `
          <tr>
            <td class="font-medium">${c.name}</td>
            <td class="text-sm">${c.target_segment || "Semua Segmen"}</td>
            <td class="text-sm">${formatDateShort(c.start_date)} - ${formatDateShort(c.end_date)}</td>
            <td><span class="badge ${badgeClass}">${c.status}</span></td>
            <td>
              <div class="table__actions">
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-broadcast-campaign" data-id="${c.id}" aria-label="Broadcast ke Segmen"><span class="material-symbols-outlined">campaign</span></button>
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-campaign" data-id="${c.id}"><span class="material-symbols-outlined">edit</span></button>
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-campaign" data-id="${c.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
              </div>
            </td>
          </tr>`;
          })
          .join("")
      : `<tr><td colspan="5" class="text-center p-md text-muted">Belum ada campaign.</td></tr>`;
  }

  document.getElementById("form-add-campaign").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      name: document.getElementById("camp-name").value.trim(),
      description: document.getElementById("camp-desc").value.trim(),
      target_segment: document.getElementById("camp-segment").value || null,
      start_date: document.getElementById("camp-start").value || null,
      end_date: document.getElementById("camp-end").value || null,
    };
    const { error } = await createCampaign(newData);
    if (!error) {
      closeModal("modal-add-campaign");
      e.target.reset();
      loadCampaigns();
      showAlert("#engagement-alert-container", "success", "Berhasil", "Campaign baru dibuat.");
    } else {
      showAlert("#engagement-alert-container", "danger", "Gagal", "Pastikan migrasi tabel campaigns sudah dijalankan.");
    }
  });

  campaignTbody.addEventListener("click", async (e) => {
    const btnEdit = e.target.closest(".btn-edit-campaign");
    if (btnEdit) {
      const item = campaignData.find((c) => c.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-camp-id").value = item.id;
        document.getElementById("edit-camp-name").value = item.name;
        document.getElementById("edit-camp-desc").value = item.description || "";
        document.getElementById("edit-camp-segment").value = item.target_segment || "";
        document.getElementById("edit-camp-start").value = item.start_date || "";
        document.getElementById("edit-camp-end").value = item.end_date || "";
        document.getElementById("edit-camp-status").value = item.status;
        openModal("modal-edit-campaign");
      }
    }

    const btnDelete = e.target.closest(".btn-delete-campaign");
    if (btnDelete) {
      document.getElementById("delete-camp-id").value = btnDelete.dataset.id;
      openModal("modal-delete-campaign");
    }

    const btnBroadcast = e.target.closest(".btn-broadcast-campaign");
    if (btnBroadcast) {
      const item = campaignData.find((c) => c.id === btnBroadcast.dataset.id);
      if (!item) return;

      const targets = item.target_segment ? allCustomers.filter((c) => c.segment === item.target_segment) : allCustomers;

      if (targets.length === 0) {
        showAlert("#engagement-alert-container", "danger", "Tidak Ada Target", "Tidak ada nasabah aktif pada segmen ini.");
        return;
      }

      btnBroadcast.disabled = true;
      const { error } = await broadcastToCustomers(
        targets.map((t) => t.id),
        {
          title: `Campaign: ${item.name}`,
          message: item.description || `Ada campaign baru: ${item.name}`,
          type: "Promo",
          channel: "In-App",
        }
      );
      btnBroadcast.disabled = false;

      if (!error) {
        showAlert("#engagement-alert-container", "success", "Broadcast Terkirim", `Campaign berhasil dibroadcast ke ${targets.length} nasabah.`);
        loadNotifications();

        if (confirm(`Kirim juga campaign ini lewat WA Blast ke ${targets.length} nasabah?`)) {
          openWaBlastRunner(targets, `${item.name}\n\n${item.description || ""}`);
        }
      } else {
        showAlert("#engagement-alert-container", "danger", "Gagal", "Pastikan migrasi tabel notifications sudah dijalankan.");
      }
    }
  });

  document.getElementById("form-edit-campaign").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-camp-id").value;
    const updatedData = {
      name: document.getElementById("edit-camp-name").value.trim(),
      description: document.getElementById("edit-camp-desc").value.trim(),
      target_segment: document.getElementById("edit-camp-segment").value || null,
      start_date: document.getElementById("edit-camp-start").value || null,
      end_date: document.getElementById("edit-camp-end").value || null,
      status: document.getElementById("edit-camp-status").value,
    };
    const { error } = await updateCampaign(id, updatedData);
    if (!error) {
      closeModal("modal-edit-campaign");
      loadCampaigns();
      showAlert("#engagement-alert-container", "success", "Diperbarui", "Campaign berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-campaign").addEventListener("click", async () => {
    const id = document.getElementById("delete-camp-id").value;
    const { error } = await deleteCampaign(id);
    if (!error) {
      closeModal("modal-delete-campaign");
      loadCampaigns();
      showAlert("#engagement-alert-container", "info", "Dihapus", "Campaign telah dihapus.");
    }
  });

  // ==========================================================
  // 4. EDUKASI
  // ==========================================================
  const eduTbody = document.getElementById("education-tbody");
  let eduData = [];

  async function loadEducation() {
    eduTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getEducationalContent();

    if (error) {
      eduTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    eduData = data || [];

    eduTbody.innerHTML = eduData.length
      ? eduData
          .map(
            (c) => `
        <tr>
          <td class="text-sm text-muted">${c.sort_order}</td>
          <td class="font-medium text-sm">${c.title}</td>
          <td><span class="badge ${c.is_published ? "badge--success" : "badge--neutral"}">${c.is_published ? "Tampil" : "Disembunyikan"}</span></td>
          <td>
            <div class="table__actions">
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-edu" data-id="${c.id}"><span class="material-symbols-outlined">edit</span></button>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-edu" data-id="${c.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
            </div>
          </td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada konten edukasi.</td></tr>`;
  }

  document.getElementById("form-add-education").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      title: document.getElementById("edu-title").value.trim(),
      content: document.getElementById("edu-content").value.trim(),
      icon: document.getElementById("edu-icon").value.trim() || "eco",
      sort_order: parseInt(document.getElementById("edu-order").value, 10) || 0,
    };
    const { error } = await createEducationalContent(newData);
    if (!error) {
      closeModal("modal-add-education");
      e.target.reset();
      loadEducation();
      showAlert("#engagement-alert-container", "success", "Berhasil", "Konten edukasi ditambahkan.");
    } else {
      showAlert("#engagement-alert-container", "danger", "Gagal", "Pastikan migrasi tabel educational_content sudah dijalankan.");
    }
  });

  eduTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-edu");
    if (btnEdit) {
      const item = eduData.find((c) => c.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-edu-id").value = item.id;
        document.getElementById("edit-edu-title").value = item.title;
        document.getElementById("edit-edu-content").value = item.content;
        document.getElementById("edit-edu-icon").value = item.icon;
        document.getElementById("edit-edu-order").value = item.sort_order;
        document.getElementById("edit-edu-published").value = String(item.is_published);
        openModal("modal-edit-education");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-edu");
    if (btnDelete) {
      document.getElementById("delete-edu-id").value = btnDelete.dataset.id;
      openModal("modal-delete-education");
    }
  });

  document.getElementById("form-edit-education").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-edu-id").value;
    const updatedData = {
      title: document.getElementById("edit-edu-title").value.trim(),
      content: document.getElementById("edit-edu-content").value.trim(),
      icon: document.getElementById("edit-edu-icon").value.trim() || "eco",
      sort_order: parseInt(document.getElementById("edit-edu-order").value, 10) || 0,
      is_published: document.getElementById("edit-edu-published").value === "true",
    };
    const { error } = await updateEducationalContent(id, updatedData);
    if (!error) {
      closeModal("modal-edit-education");
      loadEducation();
      showAlert("#engagement-alert-container", "success", "Diperbarui", "Konten edukasi berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-education").addEventListener("click", async () => {
    const id = document.getElementById("delete-edu-id").value;
    const { error } = await deleteEducationalContent(id);
    if (!error) {
      closeModal("modal-delete-education");
      loadEducation();
      showAlert("#engagement-alert-container", "info", "Dihapus", "Konten edukasi telah dihapus.");
    }
  });

  // ==========================================================
  // 5. LOG INTERAKSI MANUAL (fitur lama, dipertahankan)
  // ==========================================================
  const tbody = document.getElementById("engagement-tbody");
  const selectCustomer = document.getElementById("eng-customer");
  let engagementsData = [];

  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getEngagements();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    engagementsData = data || [];
    document.getElementById("stat-total-interactions").textContent = engagementsData.length.toLocaleString("id-ID");
    engagementPage = 1;
    renderEngagementTable();
  }

  function renderEngagementTable() {
    if (engagementsData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada riwayat interaksi.</td></tr>`;
      document.getElementById("engagement-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(engagementsData, engagementPage, ENGAGEMENT_PAGE_SIZE);
    engagementPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((eng) => {
      let badgeClass = "badge--info";
      if (eng.status === "Direspons") badgeClass = "badge--success";
      if (eng.status === "Gagal") badgeClass = "badge--danger";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="text-sm text-muted">${formatDate(eng.created_at)}</td>
        <td class="font-medium">${eng.customers?.full_name || "Nasabah Dihapus"}</td>
        <td>${eng.interaction_type}</td>
        <td>
          <div class="font-medium">${eng.subject}</div>
          <div class="text-caption text-muted" style="max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${eng.notes || "-"}</div>
        </td>
        <td><span class="badge ${badgeClass}">${eng.status}</span></td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${eng.id}" aria-label="Edit Status">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${eng.id}" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#engagement-pagination",
      currentPage: engagementPage,
      totalPages,
      totalItems,
      pageSize: ENGAGEMENT_PAGE_SIZE,
      onPageChange: (p) => {
        engagementPage = p;
        renderEngagementTable();
      },
    });
  }

  async function populateCustomerSelect() {
    selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
    allCustomers.forEach((cust) => {
      const option = document.createElement("option");
      option.value = cust.id;
      option.textContent = cust.full_name;
      selectCustomer.appendChild(option);
    });
  }

  const formAdd = document.getElementById("form-add-engagement");
  const btnSave = document.getElementById("btn-save-engagement");

  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      customer_id: document.getElementById("eng-customer").value,
      interaction_type: document.getElementById("eng-type").value,
      subject: document.getElementById("eng-subject").value.trim(),
      notes: document.getElementById("eng-notes").value.trim(),
    };

    btnSave.disabled = true;
    const { error } = await createEngagement(newData);
    btnSave.disabled = false;

    if (!error) {
      closeModal("modal-add-engagement");
      formAdd.reset();
      loadTableData();
      showAlert("#engagement-alert-container", "success", "Berhasil", "Riwayat interaksi berhasil dicatat.");
    } else {
      showAlert("#engagement-alert-container", "danger", "Gagal Menyimpan", error.message);
    }
  });

  tbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const item = engagementsData.find((s) => s.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-eng-id").value = item.id;
        document.getElementById("edit-eng-status").value = item.status;
        openModal("modal-edit-engagement");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-eng-id").value = btnDelete.dataset.id;
      openModal("modal-delete-engagement");
    }
  });

  document.getElementById("form-edit-engagement").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-eng-id").value;
    const updatedData = { status: document.getElementById("edit-eng-status").value };

    const { error } = await updateEngagement(id, updatedData);
    if (!error) {
      closeModal("modal-edit-engagement");
      loadTableData();
      showAlert("#engagement-alert-container", "success", "Diperbarui", "Status interaksi berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete").addEventListener("click", async () => {
    const id = document.getElementById("delete-eng-id").value;
    const { error } = await deleteEngagement(id);
    if (!error) {
      closeModal("modal-delete-engagement");
      loadTableData();
      showAlert("#engagement-alert-container", "info", "Dihapus", "Catatan interaksi telah dihapus.");
    }
  });

  // ==========================================================
  // INISIALISASI AWAL
  // ==========================================================
  (async () => {
    await loadAllCustomers();
    populateNotifCustomerSelect();
    populateCustomerSelect();
    loadNotifications();
    loadBirthdays();
    loadCampaigns();
    loadEducation();
    loadTableData();
  })();
});
