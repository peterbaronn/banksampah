/**
 * pages/complaints.js
 * ------------------------------------------------------
 * Logika halaman Complaint Management:
 *  - Pengaduan (CRUD)
 *  - Tracking Status
 *  - Live Chat per keluhan
 *  - Rating Pelayanan (ditampilkan, diisi oleh nasabah)
 *  - SLA Monitoring (keluhan yang belum selesai > 24 jam)
 * ------------------------------------------------------
 */

import {
  getComplaints,
  createComplaint,
  updateComplaint,
  deleteComplaint,
  getComplaintMessages,
  sendComplaintMessage,
} from "../../supabase/complaints.js";
import { getCustomers } from "../../supabase/customers.js";
import { getSession, getUserProfile } from "../../supabase/auth.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

const SLA_HOURS = 24; // Ambang batas SLA: keluhan harus mulai ditangani/selesai dalam 24 jam

document.addEventListener("DOMContentLoaded", () => {
  const tbody = document.getElementById("complaints-tbody");
  const selectCustomer = document.getElementById("comp-customer");
  const filterStatus = document.getElementById("filter-status");
  let complaintsData = [];
  let currentAdminName = "Admin";
  const PAGE_SIZE = 10;
  let complaintsPage = 1;

  const formatDate = (isoString) =>
    new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatDateTime = (isoString) =>
    new Date(isoString).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

  function getSlaInfo(comp) {
    const hoursElapsed = (Date.now() - new Date(comp.created_at).getTime()) / (1000 * 60 * 60);

    if (comp.status === "Selesai") {
      return { label: "Selesai", badgeClass: "badge--success" };
    }
    if (hoursElapsed > SLA_HOURS) {
      return { label: `Terlambat (${Math.floor(hoursElapsed)}j)`, badgeClass: "badge--danger" };
    }
    return { label: `${Math.floor(hoursElapsed)}j berjalan`, badgeClass: "badge--info" };
  }

  // ==========================================
  // STAT CARDS (Total, Menunggu, SLA Breach, Rata-rata Rating)
  // ==========================================
  function renderStats(allComplaints) {
    const total = allComplaints.length;
    const pending = allComplaints.filter((c) => c.status === "Menunggu").length;
    const slaBreach = allComplaints.filter((c) => c.status !== "Selesai" && getSlaInfo(c).badgeClass === "badge--danger").length;
    const rated = allComplaints.filter((c) => c.rating);
    const avgRating = rated.length ? (rated.reduce((sum, c) => sum + c.rating, 0) / rated.length).toFixed(1) : "-";

    document.getElementById("stat-total-complaints").textContent = total.toLocaleString("id-ID");
    document.getElementById("stat-pending-complaints").textContent = pending.toLocaleString("id-ID");
    document.getElementById("stat-sla-breach").textContent = slaBreach.toLocaleString("id-ID");
    document.getElementById("stat-avg-rating").textContent = avgRating === "-" ? "-" : `${avgRating} ★`;
  }

  // ==========================================
  // READ & FILTER DATA
  // ==========================================
  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getComplaints();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    complaintsData = data || [];
    complaintsPage = 1;
    renderStats(complaintsData);
    renderTable();
  }

  function renderTable() {
    const statusFilter = filterStatus.value;
    const filtered = statusFilter ? complaintsData.filter((c) => c.status === statusFilter) : complaintsData;

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-muted">Tidak ada data keluhan.</td></tr>`;
      document.getElementById("complaints-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(filtered, complaintsPage, PAGE_SIZE);
    complaintsPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((comp) => {
      let badgeClass = "badge--danger";
      if (comp.status === "Diproses") badgeClass = "badge--warning";
      if (comp.status === "Selesai") badgeClass = "badge--success";

      const sla = getSlaInfo(comp);
      const ratingHtml = comp.rating
        ? `<span class="text-warning text-sm">${"★".repeat(comp.rating)}${"☆".repeat(5 - comp.rating)}</span>`
        : '<span class="text-muted text-sm">-</span>';

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="text-muted text-sm">${formatDate(comp.created_at)}</td>
        <td class="font-medium">${comp.customers?.full_name || "Nasabah Dihapus"}</td>
        <td>
          <div style="font-weight: 500;">${comp.subject}</div>
          <div class="text-caption text-muted" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">${comp.description}</div>
        </td>
        <td><span class="badge ${badgeClass}">${comp.status}</span></td>
        <td><span class="badge ${sla.badgeClass}">${sla.label}</span></td>
        <td>${ratingHtml}</td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-chat" data-id="${comp.id}" aria-label="Live Chat">
              <span class="material-symbols-outlined">chat</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${comp.id}" aria-label="Edit Status">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${comp.id}" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#complaints-pagination",
      currentPage: complaintsPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        complaintsPage = p;
        renderTable();
      },
    });
  }

  filterStatus.addEventListener("change", () => {
    complaintsPage = 1;
    renderTable();
  });

  async function populateCustomerSelect() {
    const { data } = await getCustomers();
    if (data) {
      selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
      data
        .filter((c) => c.status === "Aktif")
        .forEach((cust) => {
          const option = document.createElement("option");
          option.value = cust.id;
          option.textContent = cust.full_name;
          selectCustomer.appendChild(option);
        });
    }
  }

  async function loadCurrentAdminName() {
    const { session } = await getSession();
    if (!session) return;
    const { profile } = await getUserProfile(session.user.id);
    if (profile?.full_name) currentAdminName = profile.full_name;
  }

  // CREATE
  const formAdd = document.getElementById("form-add-complaint");
  const btnSave = document.getElementById("btn-save-complaint");
  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      customer_id: document.getElementById("comp-customer").value,
      subject: document.getElementById("comp-subject").value.trim(),
      description: document.getElementById("comp-desc").value.trim(),
    };
    btnSave.disabled = true;
    const { error } = await createComplaint(newData);
    btnSave.disabled = false;

    if (!error) {
      closeModal("modal-add-complaint");
      formAdd.reset();
      loadTableData();
      showAlert("#complaints-alert-container", "success", "Tercatat", "Keluhan berhasil dicatat.");
    }
  });

  // UPDATE, DELETE, & CHAT DELEGATION
  tbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const id = btnEdit.dataset.id;
      const comp = complaintsData.find((c) => c.id === id);
      if (comp) {
        document.getElementById("edit-comp-id").value = comp.id;
        document.getElementById("edit-comp-subject-view").value = comp.subject;
        document.getElementById("edit-comp-status").value = comp.status;
        openModal("modal-edit-complaint");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-comp-id").value = btnDelete.dataset.id;
      openModal("modal-delete-complaint");
    }

    const btnChat = e.target.closest(".btn-chat");
    if (btnChat) {
      const id = btnChat.dataset.id;
      const comp = complaintsData.find((c) => c.id === id);
      if (comp) openChat(comp);
    }
  });

  // SUBMIT UPDATE
  const formEdit = document.getElementById("form-edit-complaint");
  formEdit.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-comp-id").value;
    const updatedData = { status: document.getElementById("edit-comp-status").value };

    const { error } = await updateComplaint(id, updatedData);
    if (!error) {
      closeModal("modal-edit-complaint");
      loadTableData();
      showAlert("#complaints-alert-container", "success", "Diperbarui", "Status keluhan diubah.");
    }
  });

  // SUBMIT DELETE
  const btnConfirmDelete = document.getElementById("btn-confirm-delete");
  btnConfirmDelete.addEventListener("click", async () => {
    const id = document.getElementById("delete-comp-id").value;
    const { error } = await deleteComplaint(id);
    if (!error) {
      closeModal("modal-delete-complaint");
      loadTableData();
      showAlert("#complaints-alert-container", "info", "Dihapus", "Keluhan telah dihapus.");
    }
  });

  // ==========================================
  // LIVE CHAT
  // ==========================================
  async function openChat(comp) {
    document.getElementById("chat-complaint-id").value = comp.id;
    document.getElementById("chat-complaint-subject").textContent = `${comp.customers?.full_name || "Nasabah"} • ${comp.subject}`;

    const messagesContainer = document.getElementById("chat-messages");
    messagesContainer.innerHTML = `<div class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></div>`;
    openModal("modal-chat-complaint");

    await renderMessages(comp.id);
  }

  async function renderMessages(complaintId) {
    const messagesContainer = document.getElementById("chat-messages");
    const { data, error } = await getComplaintMessages(complaintId);

    if (error) {
      messagesContainer.innerHTML = `<div class="text-center p-md text-danger text-sm">Gagal memuat percakapan. Pastikan migrasi tabel complaint_messages sudah dijalankan.</div>`;
      return;
    }

    if (!data || data.length === 0) {
      messagesContainer.innerHTML = `<div class="text-center p-md text-muted text-sm">Belum ada percakapan. Kirim pesan pertama ke nasabah.</div>`;
      return;
    }

    messagesContainer.innerHTML = data
      .map((msg) => {
        const isAdmin = msg.sender_role === "Admin";
        return `
        <div style="max-width: 80%; align-self: ${isAdmin ? "flex-end" : "flex-start"};">
          <div class="text-caption" style="padding: 8px 12px; border-radius: 12px; ${
            isAdmin ? "background: var(--color-primary); color: white;" : "background: white; border: 1px solid var(--color-border);"
          }">
            ${msg.message}
          </div>
          <div class="text-caption text-muted" style="font-size: 10px; margin-top: 2px; text-align: ${isAdmin ? "right" : "left"};">
            ${msg.sender_name || (isAdmin ? "Admin" : "Nasabah")} • ${formatDateTime(msg.created_at)}
          </div>
        </div>`;
      })
      .join("");

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  document.getElementById("form-chat-message").addEventListener("submit", async (e) => {
    e.preventDefault();
    const complaintId = document.getElementById("chat-complaint-id").value;
    const input = document.getElementById("chat-message-input");
    const message = input.value.trim();
    if (!message) return;

    const { error } = await sendComplaintMessage({
      complaint_id: complaintId,
      sender_role: "Admin",
      sender_name: currentAdminName,
      message,
    });

    if (!error) {
      input.value = "";
      renderMessages(complaintId);
    } else {
      showAlert("#complaints-alert-container", "danger", "Gagal Mengirim", "Pastikan migrasi tabel complaint_messages sudah dijalankan.");
    }
  });

  loadTableData();
  populateCustomerSelect();
  loadCurrentAdminName();
});
