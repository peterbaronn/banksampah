import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { getMyLoyaltySummary } from "../../supabase/loyalty.js";
import { logout } from "../../supabase/auth.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  const formatNumber = (n) => (n || 0).toLocaleString("id-ID");

  const tierBadgeClass = { Platinum: "badge--info", Gold: "badge--warning", Silver: "badge--neutral", Bronze: "badge--neutral" };

  // Informasi Akun
  document.getElementById("profile-name").textContent = profile.full_name;
  document.getElementById("profile-phone").textContent = profile.phone || "-";
  const statusBadge = document.getElementById("profile-status");
  statusBadge.textContent = profile.status;
  statusBadge.className = `badge ${profile.status === "Aktif" ? "badge--success" : "badge--danger"}`;
  document.getElementById("profile-segment").textContent = profile.segment || "Belum diatur";
  document.getElementById("profile-address").textContent = profile.address || "-";
  document.getElementById("profile-joined").textContent = formatDate(profile.created_at);

  // Ringkasan Loyalty (Membership Level, Reward Point, Achievement Badge)
  const { tier, pointsBalance, totalWeight, badges } = await getMyLoyaltySummary(profile.id);

  const tierBadge = document.getElementById("profile-tier");
  tierBadge.textContent = tier;
  tierBadge.className = `badge ${tierBadgeClass[tier] || "badge--neutral"}`;
  document.getElementById("profile-points").textContent = `${formatNumber(pointsBalance)} poin`;
  document.getElementById("profile-weight").textContent = `${formatNumber(totalWeight)} kg`;

  const badgeContainer = document.getElementById("profile-badges");
  badgeContainer.innerHTML = badges.length
    ? badges.map((b) => `<span class="badge badge--neutral">${b}</span>`).join("")
    : '<span class="text-caption text-muted">Belum ada badge yang diraih.</span>';

  // Logout
  document.getElementById("btn-logout-nasabah").addEventListener("click", async () => {
    await logout();
    window.location.replace("/pages/login.html");
  });
});
