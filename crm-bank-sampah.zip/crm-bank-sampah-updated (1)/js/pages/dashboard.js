/**
 * pages/dashboard.js
 * ------------------------------------------------------
 * Logika halaman Dashboard & Analytics.
 * Mengambil data teragregasi dari Supabase dan menampilkannya
 * sebagai kartu statistik, grafik (Chart.js), dan leaderboard.
 * ------------------------------------------------------
 */

import { getDashboardData } from "../../supabase/dashboard.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  const statCustomers = document.getElementById("stat-customers");
  const statCustomersSub = document.getElementById("stat-customers-sub");
  const statTransactions = document.getElementById("stat-transactions");
  const statWeight = document.getElementById("stat-weight");
  const statReward = document.getElementById("stat-reward");
  const tbodyRecent = document.getElementById("recent-transactions-tbody");
  const tbodyLeaderboard = document.getElementById("leaderboard-tbody");

  const formatCurrency = (amount) =>
    new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount || 0);
  const formatDate = (isoString) =>
    new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatNumber = (n) => (n || 0).toLocaleString("id-ID");

  // Loading state
  [statCustomers, statTransactions, statWeight, statReward].forEach((el) => {
    if (el) el.innerHTML = '<span class="spinner spinner--sm"></span>';
  });

  const {
    stats,
    activityChart,
    growthChart,
    membershipCount,
    rewardStats,
    complaintStats,
    schedulingStats,
    leaderboard,
    recentTransactions,
    error,
  } = await getDashboardData();

  if (error) {
    showAlert("#dashboard-container", "danger", "Gagal Memuat Dashboard", error.message);
    statCustomers.textContent = "Error";
    statTransactions.textContent = "Error";
    statWeight.textContent = "Error";
    statReward.textContent = "Error";
    tbodyRecent.innerHTML = `<tr><td colspan="5" class="text-center p-md text-danger">Gagal memuat transaksi terbaru.</td></tr>`;
    tbodyLeaderboard.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat leaderboard.</td></tr>`;
    return;
  }

  // 1. Stat cards utama
  statCustomers.textContent = formatNumber(stats.customers);
  if (statCustomersSub) statCustomersSub.textContent = `${formatNumber(stats.activeCustomers)} aktif`;
  statTransactions.textContent = formatNumber(stats.transactions);
  statWeight.textContent = `${formatNumber(stats.weight)} kg`;
  statReward.textContent = formatCurrency(stats.reward);

  // 2. Grafik Aktivitas (line chart, 14 hari terakhir)
  if (activityChart && window.Chart) {
    new Chart(document.getElementById("chart-activity"), {
      type: "line",
      data: {
        labels: activityChart.labels,
        datasets: [
          {
            label: "Transaksi",
            data: activityChart.values,
            borderColor: "#16a34a",
            backgroundColor: "rgba(22, 163, 74, 0.12)",
            fill: true,
            tension: 0.35,
            pointRadius: 2,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    });
  }

  // 3. Grafik Pertumbuhan Nasabah (bar chart, 6 bulan terakhir)
  if (growthChart && window.Chart) {
    new Chart(document.getElementById("chart-growth"), {
      type: "bar",
      data: {
        labels: growthChart.labels,
        datasets: [
          {
            label: "Nasabah Baru",
            data: growthChart.values,
            backgroundColor: "#3b82f6",
            borderRadius: 6,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    });
  }

  // 4. Statistik Membership (doughnut chart)
  if (membershipCount && window.Chart) {
    new Chart(document.getElementById("chart-membership"), {
      type: "doughnut",
      data: {
        labels: Object.keys(membershipCount),
        datasets: [
          {
            data: Object.values(membershipCount),
            backgroundColor: ["#94a3b8", "#f59e0b", "#22c55e", "#3b82f6"].reverse(),
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 11 } } } },
      },
    });
  }

  // 5. Statistik Reward
  if (rewardStats) {
    document.getElementById("stat-reward-points").textContent = formatCurrency(rewardStats.totalPointsUsed);
    const container = document.getElementById("reward-status-badges");
    const badgeMap = { Menunggu: "badge--warning", Disetujui: "badge--success", Ditolak: "badge--danger" };
    container.innerHTML = Object.entries(rewardStats.byStatus)
      .map(([status, count]) => `<span class="badge ${badgeMap[status] || "badge--neutral"}">${status}: ${count}</span>`)
      .join("");
  }

  // 6. Statistik Complaint
  if (complaintStats) {
    document.getElementById("stat-complaints-total").textContent = formatNumber(complaintStats.total);
    const container = document.getElementById("complaint-status-badges");
    const badgeMap = { Menunggu: "badge--danger", Diproses: "badge--warning", Selesai: "badge--success" };
    container.innerHTML = Object.entries(complaintStats.byStatus)
      .map(([status, count]) => `<span class="badge ${badgeMap[status] || "badge--neutral"}">${status}: ${count}</span>`)
      .join("");
  }

  // 7. Statistik Penjemputan
  if (schedulingStats) {
    document.getElementById("stat-scheduling-total").textContent = formatNumber(schedulingStats.total);
    const container = document.getElementById("scheduling-status-badges");
    const badgeMap = { Terjadwal: "badge--info", Selesai: "badge--success", Dibatalkan: "badge--danger" };
    container.innerHTML = Object.entries(schedulingStats.byStatus)
      .map(([status, count]) => `<span class="badge ${badgeMap[status] || "badge--neutral"}">${status}: ${count}</span>`)
      .join("");
  }

  // 8. Leaderboard Nasabah
  if (!leaderboard || leaderboard.length === 0) {
    tbodyLeaderboard.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada data setoran.</td></tr>`;
  } else {
    const medal = ["🥇", "🥈", "🥉"];
    tbodyLeaderboard.innerHTML = "";
    leaderboard.forEach((entry, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="font-medium">${medal[index] || `#${index + 1}`}</td>
        <td class="font-medium">${entry.name}</td>
        <td>${formatNumber(entry.totalWeight)} kg</td>
        <td>${formatCurrency(entry.totalReward)}</td>
      `;
      tbodyLeaderboard.appendChild(tr);
    });
  }

  // 9. Render Transaksi Terbaru
  if (!recentTransactions || recentTransactions.length === 0) {
    tbodyRecent.innerHTML = `<tr><td colspan="5" class="text-center p-md text-muted">Belum ada transaksi.</td></tr>`;
    return;
  }

  tbodyRecent.innerHTML = "";
  recentTransactions.forEach((tx) => {
    let badgeClass = "badge--warning";
    if (tx.status === "Selesai") badgeClass = "badge--success";
    if (tx.status === "Dibatalkan") badgeClass = "badge--danger";

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="text-muted text-sm">${formatDate(tx.created_at)}</td>
      <td class="font-medium">${tx.customers?.full_name || "Nasabah Dihapus"}</td>
      <td>${tx.waste_type}</td>
      <td>${tx.weight_kg} kg</td>
      <td><span class="badge ${badgeClass}">${tx.status}</span></td>
    `;
    tbodyRecent.appendChild(tr);
  });
});
