/**
 * pages/settings.js
 * ------------------------------------------------------
 * Logika halaman Settings: Load profil admin yang sedang 
 * login, update nama, dan update password.
 * ------------------------------------------------------
 */

import { getSession, getUserProfile } from "../../supabase/auth.js";
import { updateProfileName, updatePassword } from "../../supabase/settings.js";
import { showAlert } from "../utils/alert.js";



document.addEventListener("DOMContentLoaded", async () => {
  const inputEmail = document.getElementById("set-email");
  const inputRole = document.getElementById("set-role");
  const inputFullName = document.getElementById("set-fullname");
  
  let currentUserId = null;

  // 1. LOAD DATA PROFIL
  async function loadProfile() {
    inputEmail.value = "Memuat...";
    inputRole.value = "Memuat...";
    inputFullName.value = "Memuat...";

    const { session, error: errSession } = await getSession();
    if (errSession || !session) return;

    currentUserId = session.user.id;
    inputEmail.value = session.user.email;

    const { profile, error: errProfile } = await getUserProfile(currentUserId);
    if (!errProfile && profile) {
      inputRole.value = profile.role;
      inputFullName.value = profile.full_name;
    }
  }

  // 2. HANDLE UPDATE NAMA PROFIL
  const formProfile = document.getElementById("form-profile");
  const btnSaveProfile = document.getElementById("btn-save-profile");

  formProfile.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!currentUserId) return;

    const newName = inputFullName.value.trim();
    
    btnSaveProfile.disabled = true;
    btnSaveProfile.textContent = "Menyimpan...";

    const { error } = await updateProfileName(currentUserId, newName);

    btnSaveProfile.disabled = false;
    btnSaveProfile.textContent = "Simpan Profil";

    if (error) {
      alert("Gagal mengupdate profil: " + error.message);
    } else {
      showAlert("#settings-alert-container", "success", "Berhasil", "Nama profil berhasil diperbarui. Muat ulang halaman (Refresh) untuk melihat perubahan pada Navbar.");
    }
  });

  // 3. HANDLE UPDATE PASSWORD
  const formPassword = document.getElementById("form-password");
  const inputPassword = document.getElementById("set-password");
  const inputConfirm = document.getElementById("set-confirm-password");
  const btnSavePassword = document.getElementById("btn-save-password");
  const groupConfirm = document.getElementById("group-confirm-pwd");
  const pwdErrorMsg = document.getElementById("pwd-error-msg");

  formPassword.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    // Reset status error
    groupConfirm.classList.remove("has-error");
    pwdErrorMsg.classList.add("hidden");

    const newPwd = inputPassword.value;
    const confirmPwd = inputConfirm.value;

    // Validasi panjang
    if (newPwd.length < 6) {
      alert("Password minimal harus 6 karakter!");
      return;
    }

    // Validasi kecocokan
    if (newPwd !== confirmPwd) {
      groupConfirm.classList.add("has-error");
      pwdErrorMsg.classList.remove("hidden");
      return;
    }

    btnSavePassword.disabled = true;
    btnSavePassword.textContent = "Memproses...";

    const { error } = await updatePassword(newPwd);

    btnSavePassword.disabled = false;
    btnSavePassword.textContent = "Ubah Password";

    if (error) {
      alert("Gagal merubah password: " + error.message);
    } else {
      formPassword.reset();
      showAlert("#settings-alert-container", "success", "Password Diubah", "Kata sandi Anda berhasil diperbarui. Silakan gunakan kata sandi baru untuk login berikutnya.");
    }
  });

  // Panggil saat pertama kali dimuat
  loadProfile();
});