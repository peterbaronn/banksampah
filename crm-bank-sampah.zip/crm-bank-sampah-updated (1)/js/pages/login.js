/**
 * pages/login.js
 * ------------------------------------------------------
 * Menangani validasi form login, komunikasi ke Supabase,
 * dan Smart Redirect berdasarkan Role Pengguna.
 * ------------------------------------------------------
 */

import { login, getSession, getUserProfile } from "../../supabase/auth.js";

document.addEventListener("DOMContentLoaded", async () => {

  // Fungsi untuk mengecek Role dan mengalihkan halaman
  async function redirectByRole(userId) {
    const { profile } = await getUserProfile(userId);
    
    // Jika dia Admin atau Staff, arahkan ke Dashboard Admin
    if (profile && (profile.role === "Administrator" || profile.role === "Staff")) {
      window.location.replace("/pages/dashboard.html");
    } else {
      // Jika profil bukan admin (nasabah) atau profil belum diset, arahkan ke User Portal
      window.location.replace("/pages/user-dashboard.html");
    }
  }

  // 1. Cek Sesi saat halaman baru dibuka
  const { session } = await getSession();
  if (session) {
    await redirectByRole(session.user.id);
    return;
  }

  // 2. Deklarasi DOM Elements
  const loginForm = document.getElementById("login-form");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const groupEmail = document.getElementById("group-email");
  const groupPassword = document.getElementById("group-password");
  const togglePasswordBtn = document.getElementById("toggle-password");
  const toggleIcon = togglePasswordBtn.querySelector("span");
  
  const btnLogin = document.getElementById("btn-login");
  const btnText = document.getElementById("btn-login-text");
  const btnSpinner = document.getElementById("btn-login-spinner");
  
  const alertBox = document.getElementById("login-alert");
  const alertMsg = document.getElementById("login-alert-msg");

  // 3. Logika Toggle Hide/Show Password
  togglePasswordBtn.addEventListener("click", () => {
    const isPassword = passwordInput.getAttribute("type") === "password";
    passwordInput.setAttribute("type", isPassword ? "text" : "password");
    toggleIcon.textContent = isPassword ? "visibility_off" : "visibility";
  });

  // 4. Handle Submit Form
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    // Reset state UI sebelum validasi
    groupEmail.classList.remove("has-error");
    groupPassword.classList.remove("has-error");
    alertBox.classList.add("hidden");

    const email = emailInput.value.trim();
    const password = passwordInput.value;
    let isValid = true;

    // Validasi Email
    if (!email) {
      groupEmail.classList.add("has-error");
      groupEmail.querySelector(".form-error").textContent = "Email wajib diisi.";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      groupEmail.classList.add("has-error");
      groupEmail.querySelector(".form-error").textContent = "Format email tidak valid.";
      isValid = false;
    }

    // Validasi Password
    if (!password || password.length < 6) {
      groupPassword.classList.add("has-error");
      groupPassword.querySelector(".form-error").textContent = "Password wajib diisi (Min. 6 karakter).";
      isValid = false;
    }

    // Stop jika validasi gagal
    if (!isValid) return;

    // Tampilkan Indikator Loading
    btnLogin.disabled = true;
    btnText.classList.add("hidden");
    btnSpinner.classList.remove("hidden");

    // 5. Eksekusi Login Service
    const { data, error } = await login(email, password);

    if (error) {
      let errorMessage = "Terjadi kesalahan sistem saat login.";

      if (error.message === "Invalid login credentials") {
        errorMessage = "Email atau password yang Anda masukkan salah.";
      } else if (error.message.includes("Failed to fetch")) {
        errorMessage = "Koneksi terputus. Pastikan internet Anda stabil.";
      } else {
        errorMessage = error.message; 
      }

      // Tampilkan pesan error di atas form
      alertMsg.textContent = errorMessage;
      alertBox.classList.remove("hidden");
      
      // Stop loading
      btnLogin.disabled = false;
      btnText.classList.remove("hidden");
      btnSpinner.classList.add("hidden");
    } else {
      // 6. Login Sukses, arahkan berdasarkan Role
      await redirectByRole(data.user.id);
    }
  });
});