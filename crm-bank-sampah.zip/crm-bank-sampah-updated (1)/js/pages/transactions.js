/**
 * pages/transactions.js
 * ------------------------------------------------------
 * Logika halaman Customer Transaction (Admin):
 *  - Riwayat Setoran Sampah (fitur lama, + E-Receipt)
 *  - Estimasi Harga Sampah (CRUD harga, auto-hitung saldo)
 *  - Saldo Digital (ringkasan per nasabah)
 *  - Riwayat Penarikan Saldo (CRUD + approval)
 * ------------------------------------------------------
 */

import {
  getTransactions,
  createTransaction,
  updateTransaction,
  deleteTransaction,
  getWastePrices,
  updateWastePrice,
  getSaldoDigitalOverview,
  getWithdrawals,
  createWithdrawal,
  updateWithdrawal,
  deleteWithdrawal,
} from "../../supabase/transactions.js";
import { getCustomers } from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const tbody = document.getElementById("transactions-tbody");
  const selectCustomer = document.getElementById("trans-customer");
  let transactionsData = [];
  let wastePricesData = [];
  let allActiveCustomers = [];
  const PAGE_SIZE = 10;
  let transactionsPage = 1;
  let withdrawalsPage = 1;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatCurrency = (amount) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount || 0);

  // ==========================================================
  // 1. RIWAYAT SETORAN (fitur lama + E-Receipt)
  // ==========================================================
  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getTransactions();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    transactionsData = data || [];
    document.getElementById("stat-total-tx").textContent = transactionsData.length.toLocaleString("id-ID");
    const totalWeight = transactionsData.filter((t) => t.status === "Selesai").reduce((s, t) => s + (parseFloat(t.weight_kg) || 0), 0);
    document.getElementById("stat-total-weight").textContent = totalWeight.toLocaleString("id-ID");

    if (transactionsData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center p-md text-muted">Belum ada transaksi setoran.</td></tr>`;
      document.getElementById("transactions-pagination").innerHTML = "";
      return;
    }

    transactionsPage = 1;
    renderTransactionsTable();
  }

  function renderTransactionsTable() {
    if (transactionsData.length === 0) return;

    const { items: pageItems, page, totalPages, totalItems } = paginate(transactionsData, transactionsPage, PAGE_SIZE);
    transactionsPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((trans) => {
      let badgeClass = "badge--warning";
      if (trans.status === "Selesai") badgeClass = "badge--success";
      if (trans.status === "Dibatalkan") badgeClass = "badge--danger";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="text-muted text-sm">${formatDate(trans.created_at)}</td>
        <td class="font-medium">${trans.customers?.full_name || "Nasabah Dihapus"}</td>
        <td>${trans.waste_type}</td>
        <td>${trans.weight_kg} kg</td>
        <td class="font-medium text-success">${formatCurrency(trans.total_reward)}</td>
        <td><span class="badge ${badgeClass}">${trans.status}</span></td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-receipt" data-id="${trans.id}" aria-label="Lihat Struk">
              <span class="material-symbols-outlined">receipt</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${trans.id}" aria-label="Edit Status">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${trans.id}" aria-label="Hapus" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#transactions-pagination",
      currentPage: transactionsPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        transactionsPage = p;
        renderTransactionsTable();
      },
    });
  }

  function openReceipt(trans) {
    document.getElementById("receipt-body").innerHTML = `
      <div style="text-align:center; margin-bottom: 12px;">
        <div class="font-semibold">BANK SAMPAH</div>
        <div class="text-caption text-muted">E-Receipt Setoran Sampah</div>
      </div>
      <hr style="border: none; border-top: 1px dashed var(--color-border); margin: 8px 0;" />
      <div class="flex justify-between text-sm mb-xs"><span>No. Transaksi</span><span>${trans.id.slice(0, 8).toUpperCase()}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Tanggal</span><span>${formatDate(trans.created_at)}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Nasabah</span><span>${trans.customers?.full_name || "Nasabah Dihapus"}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Jenis Sampah</span><span>${trans.waste_type}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Berat</span><span>${trans.weight_kg} kg</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Status</span><span>${trans.status}</span></div>
      <hr style="border: none; border-top: 1px dashed var(--color-border); margin: 8px 0;" />
      <div class="flex justify-between font-semibold"><span>Total Saldo</span><span>${formatCurrency(trans.total_reward)}</span></div>
    `;
    openModal("modal-receipt");
  }

  async function populateCustomerSelect() {
    const { data } = await getCustomers();
    allActiveCustomers = (data || []).filter((c) => c.status === "Aktif");

    selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
    allActiveCustomers.forEach((cust) => {
      const option = document.createElement("option");
      option.value = cust.id;
      option.textContent = cust.full_name;
      selectCustomer.appendChild(option);
    });

    const wdCustomerSelect = document.getElementById("wd-customer");
    wdCustomerSelect.innerHTML = '<option value="">Pilih Nasabah...</option>';
    allActiveCustomers.forEach((cust) => {
      const option = document.createElement("option");
      option.value = cust.id;
      option.textContent = cust.full_name;
      wdCustomerSelect.appendChild(option);
    });
  }

  // Auto-hitung Total Saldo/Reward berdasarkan Jenis Sampah + Berat + harga per kg
  const transType = document.getElementById("trans-type");
  const transWeight = document.getElementById("trans-weight");
  const transReward = document.getElementById("trans-reward");

  function autoCalculateReward() {
    const price = wastePricesData.find((p) => p.waste_type === transType.value);
    const weight = parseFloat(transWeight.value);
    if (price && weight) {
      transReward.value = Math.round(price.price_per_kg * weight);
    }
  }
  transType.addEventListener("change", autoCalculateReward);
  transWeight.addEventListener("input", autoCalculateReward);

  const formAdd = document.getElementById("form-add-transaction");
  const btnSave = document.getElementById("btn-save-transaction");

  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();

    const newData = {
      customer_id: document.getElementById("trans-customer").value,
      waste_type: document.getElementById("trans-type").value,
      weight_kg: parseFloat(document.getElementById("trans-weight").value),
      total_reward: parseFloat(document.getElementById("trans-reward").value || 0),
      notes: document.getElementById("trans-notes").value.trim(),
    };

    btnSave.disabled = true;
    btnSave.textContent = "Menyimpan...";

    const { error } = await createTransaction(newData);

    btnSave.disabled = false;
    btnSave.textContent = "Simpan Transaksi";

    if (error) {
      showAlert("#transactions-alert-container", "danger", "Gagal Menyimpan", error.message);
    } else {
      closeModal("modal-add-transaction");
      formAdd.reset();
      loadTableData();
      loadSaldoOverview();
      showAlert("#transactions-alert-container", "success", "Berhasil", "Transaksi setoran baru berhasil dicatat.");
    }
  });

  tbody.addEventListener("click", (e) => {
    const btnReceipt = e.target.closest(".btn-receipt");
    if (btnReceipt) {
      const trans = transactionsData.find((t) => t.id === btnReceipt.dataset.id);
      if (trans) openReceipt(trans);
    }

    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const id = btnEdit.dataset.id;
      const trans = transactionsData.find((t) => t.id === id);
      if (trans) {
        document.getElementById("edit-trans-id").value = trans.id;
        document.getElementById("edit-trans-status").value = trans.status;
        openModal("modal-edit-transaction");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-trans-id").value = btnDelete.dataset.id;
      openModal("modal-delete-transaction");
    }
  });

  const formEdit = document.getElementById("form-edit-transaction");
  const btnUpdate = document.getElementById("btn-update-transaction");

  formEdit.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-trans-id").value;
    const updatedData = { status: document.getElementById("edit-trans-status").value };

    btnUpdate.disabled = true;
    const { error } = await updateTransaction(id, updatedData);
    btnUpdate.disabled = false;

    if (!error) {
      closeModal("modal-edit-transaction");
      loadTableData();
      loadSaldoOverview();
      showAlert("#transactions-alert-container", "success", "Diperbarui", "Status transaksi berhasil diubah.");
    }
  });

  const btnConfirmDelete = document.getElementById("btn-confirm-delete");
  btnConfirmDelete.addEventListener("click", async () => {
    const id = document.getElementById("delete-trans-id").value;
    const { error } = await deleteTransaction(id);

    if (!error) {
      closeModal("modal-delete-transaction");
      loadTableData();
      loadSaldoOverview();
      showAlert("#transactions-alert-container", "info", "Dihapus", "Catatan transaksi telah dihapus.");
    }
  });

  // ==========================================================
  // 2. ESTIMASI HARGA SAMPAH
  // ==========================================================
  const priceTbody = document.getElementById("waste-price-tbody");

  async function loadWastePrices() {
    priceTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getWastePrices();

    if (error) {
      priceTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat data. Pastikan migrasi tabel waste_prices sudah dijalankan.</td></tr>`;
      return;
    }

    wastePricesData = data || [];

    priceTbody.innerHTML = wastePricesData.length
      ? wastePricesData
          .map(
            (p) => `
        <tr>
          <td class="font-medium">${p.waste_type}</td>
          <td>${formatCurrency(p.price_per_kg)}/kg</td>
          <td class="text-sm text-muted">${formatDate(p.updated_at)}</td>
          <td><button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-price" data-id="${p.id}"><span class="material-symbols-outlined">edit</span></button></td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada data harga.</td></tr>`;
  }

  priceTbody.addEventListener("click", (e) => {
    const btn = e.target.closest(".btn-edit-price");
    if (btn) {
      const item = wastePricesData.find((p) => p.id === btn.dataset.id);
      if (item) {
        document.getElementById("edit-price-id").value = item.id;
        document.getElementById("edit-price-label").textContent = item.waste_type;
        document.getElementById("edit-price-value").value = item.price_per_kg;
        openModal("modal-edit-price");
      }
    }
  });

  document.getElementById("form-edit-price").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-price-id").value;
    const updatedData = { price_per_kg: parseFloat(document.getElementById("edit-price-value").value) };

    const { error } = await updateWastePrice(id, updatedData);
    if (!error) {
      closeModal("modal-edit-price");
      loadWastePrices();
      showAlert("#transactions-alert-container", "success", "Diperbarui", "Harga sampah berhasil diubah.");
    }
  });

  // ==========================================================
  // 3. SALDO DIGITAL
  // ==========================================================
  const saldoTbody = document.getElementById("saldo-tbody");

  async function loadSaldoOverview() {
    saldoTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getSaldoDigitalOverview();

    if (error) {
      saldoTbody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    const totalBalance = data.reduce((sum, d) => sum + d.currentBalance, 0);
    document.getElementById("stat-total-balance").textContent = formatCurrency(totalBalance);

    const top15 = data.slice(0, 15);
    saldoTbody.innerHTML = top15.length
      ? top15
          .map(
            (d) => `
        <tr>
          <td class="font-medium">${d.name}</td>
          <td>${formatCurrency(d.totalEarned)}</td>
          <td class="text-danger">-${formatCurrency(d.totalWithdrawn)}</td>
          <td class="font-medium text-success">${formatCurrency(d.currentBalance)}</td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada data saldo.</td></tr>`;
  }

  // ==========================================================
  // 4. RIWAYAT PENARIKAN SALDO
  // ==========================================================
  const wdTbody = document.getElementById("withdrawal-tbody");
  let withdrawalsData = [];

  async function loadWithdrawals() {
    wdTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getWithdrawals();

    if (error) {
      wdTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data. Pastikan migrasi tabel withdrawals sudah dijalankan.</td></tr>`;
      return;
    }

    withdrawalsData = data || [];
    document.getElementById("stat-pending-withdrawals").textContent = withdrawalsData.filter((w) => w.status === "Menunggu").length.toLocaleString("id-ID");

    withdrawalsPage = 1;
    renderWithdrawalsTable();
  }

  function renderWithdrawalsTable() {
    if (withdrawalsData.length === 0) {
      wdTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada permintaan penarikan.</td></tr>`;
      document.getElementById("withdrawal-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(withdrawalsData, withdrawalsPage, PAGE_SIZE);
    withdrawalsPage = page;

    wdTbody.innerHTML = pageItems
          .map((w) => {
            let badgeClass = "badge--warning";
            if (w.status === "Disetujui") badgeClass = "badge--success";
            if (w.status === "Ditolak") badgeClass = "badge--danger";
            return `
          <tr>
            <td class="text-sm text-muted">${formatDate(w.created_at)}</td>
            <td class="font-medium">${w.customers?.full_name || "Nasabah Dihapus"}</td>
            <td>${formatCurrency(w.amount)}</td>
            <td class="text-sm">${w.method}</td>
            <td><span class="badge ${badgeClass}">${w.status}</span></td>
            <td>
              <div class="table__actions">
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-wd" data-id="${w.id}"><span class="material-symbols-outlined">edit</span></button>
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-wd" data-id="${w.id}" style="color: var(--color-danger);"><span class="material-symbols-outlined">delete</span></button>
              </div>
            </td>
          </tr>`;
          })
          .join("");

    renderPagination({
      container: "#withdrawal-pagination",
      currentPage: withdrawalsPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        withdrawalsPage = p;
        renderWithdrawalsTable();
      },
    });
  }

  document.getElementById("form-add-withdrawal").addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      customer_id: document.getElementById("wd-customer").value,
      amount: parseFloat(document.getElementById("wd-amount").value),
      method: document.getElementById("wd-method").value,
      notes: document.getElementById("wd-notes").value.trim(),
      status: "Menunggu",
    };
    const { error } = await createWithdrawal(newData);
    if (!error) {
      closeModal("modal-add-withdrawal");
      e.target.reset();
      loadWithdrawals();
      showAlert("#transactions-alert-container", "success", "Berhasil", "Catatan penarikan saldo ditambahkan.");
    } else {
      showAlert("#transactions-alert-container", "danger", "Gagal", "Pastikan migrasi tabel withdrawals sudah dijalankan.");
    }
  });

  wdTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-wd");
    if (btnEdit) {
      const item = withdrawalsData.find((w) => w.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-wd-id").value = item.id;
        document.getElementById("edit-wd-status").value = item.status;
        openModal("modal-edit-withdrawal");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-wd");
    if (btnDelete) {
      document.getElementById("delete-wd-id").value = btnDelete.dataset.id;
      openModal("modal-delete-withdrawal");
    }
  });

  document.getElementById("form-edit-withdrawal").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-wd-id").value;
    const updatedData = { status: document.getElementById("edit-wd-status").value };
    const { error } = await updateWithdrawal(id, updatedData);
    if (!error) {
      closeModal("modal-edit-withdrawal");
      loadWithdrawals();
      loadSaldoOverview();
      showAlert("#transactions-alert-container", "success", "Diperbarui", "Status penarikan berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-withdrawal").addEventListener("click", async () => {
    const id = document.getElementById("delete-wd-id").value;
    const { error } = await deleteWithdrawal(id);
    if (!error) {
      closeModal("modal-delete-withdrawal");
      loadWithdrawals();
      loadSaldoOverview();
      showAlert("#transactions-alert-container", "info", "Dihapus", "Catatan penarikan telah dihapus.");
    }
  });

  // ==========================================================
  // INISIALISASI AWAL
  // ==========================================================
  (async () => {
    await loadWastePrices();
    loadTableData();
    populateCustomerSelect();
    loadSaldoOverview();
    loadWithdrawals();
  })();
});
