import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { getComplaintsByCustomer, createComplaint, updateComplaint, getComplaintMessages, sendComplaintMessage } from "../../supabase/complaints.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatDateTime = (isoString) => new Date(isoString).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  const listContainer = document.getElementById("list-complaints");

  async function loadComplaints() {
    listContainer.innerHTML = '<div class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></div>';
    const { data, error } = await getComplaintsByCustomer(profile.id);

    if (error) {
      listContainer.innerHTML = `<div class="card text-center p-md text-danger text-sm">Gagal memuat data pengaduan.</div>`;
      return;
    }

    if (!data || data.length === 0) {
      listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada pengaduan yang diajukan.</div>`;
      return;
    }

    listContainer.innerHTML = "";
    data.forEach((item) => {
      let badgeClass = "badge--danger";
      if (item.status === "Diproses") badgeClass = "badge--warning";
      if (item.status === "Selesai") badgeClass = "badge--success";

      const card = document.createElement("div");
      card.className = "card";
      card.style.padding = "12px 16px";

      let ratingHtml = "";
      if (item.status === "Selesai") {
        if (item.rating) {
          ratingHtml = `<div class="text-caption text-warning mt-xs">${"★".repeat(item.rating)}${"☆".repeat(5 - item.rating)} (Rating Anda)</div>`;
        } else {
          ratingHtml = `
            <div class="text-caption text-muted mt-xs">Beri rating pelayanan:</div>
            <div class="rating-input flex gap-xs mt-xs" data-id="${item.id}">
              ${[1, 2, 3, 4, 5].map((n) => `<span class="material-symbols-outlined rating-star" data-value="${n}" style="cursor:pointer; color: var(--color-warning);">star_border</span>`).join("")}
            </div>
          `;
        }
      }

      card.innerHTML = `
        <div class="flex justify-between items-start">
          <div class="flex-1">
            <div class="font-medium text-sm">${item.subject}</div>
            <div class="text-caption text-muted mt-xs">${formatDate(item.created_at)}</div>
          </div>
          <span class="badge ${badgeClass}">${item.status}</span>
        </div>
        <div class="text-caption text-muted mt-xs" style="line-height:1.4;">${item.description}</div>
        ${ratingHtml}
        <button type="button" class="btn btn--secondary btn--sm btn-toggle-chat mt-sm" data-id="${item.id}" style="width:100%;">
          <span class="material-symbols-outlined" style="font-size:16px;">chat</span> Chat dengan Admin
        </button>
        <div class="chat-thread" data-id="${item.id}" style="display:none; margin-top: 8px;">
          <div class="chat-messages" style="max-height: 200px; overflow-y:auto; display:flex; flex-direction:column; gap:6px; padding: 8px; background: var(--color-secondary); border-radius: var(--radius-md); margin-bottom: 8px;">
            <div class="text-center p-sm text-muted text-caption"><span class="spinner spinner--sm"></span></div>
          </div>
          <form class="chat-form flex gap-xs" data-id="${item.id}">
            <input type="text" class="form-control chat-input" placeholder="Ketik pesan..." style="flex:1;" required />
            <button type="submit" class="btn btn--primary btn--icon btn--sm"><span class="material-symbols-outlined" style="font-size:16px;">send</span></button>
          </form>
        </div>
      `;
      listContainer.appendChild(card);
    });

    // Wire tombol toggle chat
    listContainer.querySelectorAll(".btn-toggle-chat").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const thread = listContainer.querySelector(`.chat-thread[data-id="${id}"]`);
        const isVisible = thread.style.display !== "none";
        thread.style.display = isVisible ? "none" : "block";
        if (!isVisible) await loadChatMessages(id);
      });
    });

    // Wire form kirim pesan
    listContainer.querySelectorAll(".chat-form").forEach((form) => {
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const id = form.dataset.id;
        const input = form.querySelector(".chat-input");
        const message = input.value.trim();
        if (!message) return;

        const { error } = await sendComplaintMessage({
          complaint_id: id,
          sender_role: "Nasabah",
          sender_name: profile.full_name,
          message,
        });

        if (!error) {
          input.value = "";
          loadChatMessages(id);
        } else {
          showAlert("#user-alert-container", "danger", "Gagal Mengirim", "Fitur chat memerlukan migrasi tabel complaint_messages. Hubungi admin.");
        }
      });
    });

    // Wire rating stars
    listContainer.querySelectorAll(".rating-input").forEach((group) => {
      const stars = group.querySelectorAll(".rating-star");
      stars.forEach((star) => {
        star.addEventListener("click", async () => {
          const value = parseInt(star.dataset.value, 10);
          const complaintId = group.dataset.id;
          const { error } = await updateComplaint(complaintId, { rating: value });
          if (!error) {
            showAlert("#user-alert-container", "success", "Terima Kasih", "Rating pelayanan Anda telah dikirim.");
            loadComplaints();
          } else {
            showAlert("#user-alert-container", "danger", "Gagal", "Kolom rating belum tersedia di database. Hubungi admin untuk menjalankan migrasi.");
          }
        });
      });
    });
  }

  async function loadChatMessages(complaintId) {
    const thread = listContainer.querySelector(`.chat-thread[data-id="${complaintId}"] .chat-messages`);
    const { data, error } = await getComplaintMessages(complaintId);

    if (error) {
      thread.innerHTML = `<div class="text-center p-sm text-danger text-caption">Fitur chat belum aktif (migrasi database diperlukan).</div>`;
      return;
    }

    if (!data || data.length === 0) {
      thread.innerHTML = `<div class="text-center p-sm text-muted text-caption">Belum ada percakapan. Kirim pesan pertama Anda.</div>`;
      return;
    }

    thread.innerHTML = data
      .map((msg) => {
        const isMine = msg.sender_role === "Nasabah";
        return `
        <div style="max-width: 85%; align-self: ${isMine ? "flex-end" : "flex-start"};">
          <div class="text-caption" style="padding: 6px 10px; border-radius: 10px; ${
            isMine ? "background: var(--color-primary); color:white;" : "background:white; border:1px solid var(--color-border);"
          }">${msg.message}</div>
          <div class="text-caption text-muted" style="font-size:9px; margin-top:2px; text-align:${isMine ? "right" : "left"};">${msg.sender_name || (isMine ? "Anda" : "Admin")} • ${formatDateTime(msg.created_at)}</div>
        </div>`;
      })
      .join("");
    thread.scrollTop = thread.scrollHeight;
  }

  document.getElementById("form-complaint").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-submit-complaint");
    const newData = {
      customer_id: profile.id,
      subject: document.getElementById("c-subject").value.trim(),
      description: document.getElementById("c-description").value.trim(),
      status: "Menunggu",
    };

    btn.disabled = true;
    btn.textContent = "Mengirim...";
    const { error } = await createComplaint(newData);
    btn.disabled = false;
    btn.textContent = "Kirim Pengaduan";

    if (!error) {
      e.target.reset();
      showAlert("#user-alert-container", "success", "Terkirim", "Pengaduan Anda berhasil dikirim dan akan segera ditindaklanjuti.");
      loadComplaints();
    } else {
      showAlert("#user-alert-container", "danger", "Gagal Mengirim", error.message);
    }
  });

  loadComplaints();
});
