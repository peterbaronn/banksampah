/**
 * pages/loyalty.js
 * ------------------------------------------------------
 * Logika halaman Loyalty Program:
 *  - Membership Level & Reward Point (ringkasan otomatis)
 *  - Achievement Badge (ringkasan otomatis)
 *  - Reward Catalog (Voucher/Cashback/Sembako) CRUD
 *  - Riwayat Penukaran Hadiah CRUD
 *  - Referral Program CRUD
 * ------------------------------------------------------
 */

import {
  getRedemptions,
  createRedemption,
  updateRedemption,
  deleteRedemption,
  getRewardCatalog,
  createCatalogItem,
  updateCatalogItem,
  deleteCatalogItem,
  getReferrals,
  createReferral,
  updateReferral,
  deleteReferral,
  getLoyaltyOverview,
} from "../../supabase/loyalty.js";
import { getCustomers } from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const formatCurrency = (amount) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount || 0);
  const formatNumber = (n) => (n || 0).toLocaleString("id-ID");

  let redemptionsData = [];
  let catalogData = [];
  let referralsData = [];
  const PAGE_SIZE = 10;
  let redemptionsPage = 1;

  const tierBadgeClass = { Platinum: "badge--info", Gold: "badge--warning", Silver: "badge--neutral", Bronze: "badge--neutral" };
  const categoryBadgeClass = { Voucher: "badge--info", Cashback: "badge--success", Sembako: "badge--warning", Lainnya: "badge--neutral" };

  // ==========================================================
  // 1. LOYALTY OVERVIEW: Stat cards + Membership Level + Badges
  // ==========================================================
  async function loadOverview() {
    const membershipTbody = document.getElementById("membership-tbody");
    const badgeGrid = document.getElementById("badge-grid");

    const {
      customerSummaries,
      membershipCount,
      totalPointsBalance,
      totalRedemptions,
      totalReferralsApproved,
      badgeStats,
      error,
    } = await getLoyaltyOverview();

    if (error) {
      membershipTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-danger">Gagal memuat ringkasan loyalty: ${error.message}</td></tr>`;
      badgeGrid.innerHTML = `<div class="text-center p-md text-danger">Gagal memuat data badge.</div>`;
      return;
    }

    // Stat cards
    document.getElementById("stat-total-points").textContent = formatNumber(totalPointsBalance);
    document.getElementById("stat-gold-plus").textContent = formatNumber((membershipCount?.Gold || 0) + (membershipCount?.Platinum || 0));
    document.getElementById("stat-total-redemptions").textContent = formatNumber(totalRedemptions);
    document.getElementById("stat-referrals").textContent = formatNumber(totalReferralsApproved);

    // Membership table (top 20 by points)
    const top20 = customerSummaries.slice(0, 20);
    membershipTbody.innerHTML = top20.length
      ? top20
          .map(
            (s) => `
        <tr>
          <td class="font-medium">${s.name}</td>
          <td><span class="badge ${tierBadgeClass[s.tier] || "badge--neutral"}">${s.tier}</span></td>
          <td>${formatNumber(s.pointsBalance)} poin</td>
          <td>${formatNumber(s.totalWeight)} kg</td>
          <td>${s.badges.length ? s.badges.map((b) => `<span class="badge badge--neutral" style="margin: 2px;">${b}</span>`).join("") : '<span class="text-muted text-sm">-</span>'}</td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="5" class="text-center p-md text-muted">Belum ada data nasabah.</td></tr>`;

    // Badge grid
    badgeGrid.innerHTML = badgeStats
      .map(
        (b) => `
      <div class="card" style="box-shadow:none; border: 1px solid var(--color-border);">
        <div class="flex gap-sm" style="align-items:center;">
          <div class="stat-card__icon"><span class="material-symbols-outlined">${b.icon}</span></div>
          <div>
            <div class="font-medium">${b.key}</div>
            <div class="text-caption text-muted">${b.description}</div>
          </div>
        </div>
        <div style="margin-top: var(--space-sm);">
          <span class="stat-card__value" style="font-size:1.5rem;">${b.count}</span>
          <span class="text-caption text-muted"> nasabah</span>
        </div>
        ${b.holders.length ? `<div class="text-caption text-muted" style="margin-top:4px;">${b.holders.join(", ")}${b.count > b.holders.length ? ", ..." : ""}</div>` : ""}
      </div>`
      )
      .join("");
  }

  // ==========================================================
  // 2. REWARD CATALOG (Voucher / Cashback / Sembako)
  // ==========================================================
  const catalogTbody = document.getElementById("catalog-tbody");
  const rewardNameSelect = document.getElementById("reward-name");

  async function loadCatalog() {
    catalogTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getRewardCatalog();

    if (error) {
      catalogTbody.innerHTML = `<tr><td colspan="5" class="text-center p-md text-danger">Gagal memuat katalog: ${error.message}</td></tr>`;
      rewardNameSelect.innerHTML = '<option value="">Gagal memuat katalog</option>';
      return;
    }

    catalogData = data || [];

    catalogTbody.innerHTML = catalogData.length
      ? catalogData
          .map(
            (item) => `
        <tr>
          <td class="font-medium">${item.name}</td>
          <td><span class="badge ${categoryBadgeClass[item.category] || "badge--neutral"}">${item.category}</span></td>
          <td>${formatNumber(item.points_cost)} poin</td>
          <td><span class="badge ${item.is_active ? "badge--success" : "badge--neutral"}">${item.is_active ? "Aktif" : "Nonaktif"}</span></td>
          <td>
            <div class="table__actions">
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-catalog" data-id="${item.id}" aria-label="Edit"><span class="material-symbols-outlined">edit</span></button>
              <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-catalog" data-id="${item.id}" style="color: var(--color-danger);" aria-label="Hapus"><span class="material-symbols-outlined">delete</span></button>
            </div>
          </td>
        </tr>`
          )
          .join("")
      : `<tr><td colspan="5" class="text-center p-md text-muted">Belum ada hadiah di katalog.</td></tr>`;

    // Isi dropdown "Pilih Hadiah" pada form klaim, hanya yang aktif
    const activeItems = catalogData.filter((i) => i.is_active);
    rewardNameSelect.innerHTML = activeItems.length
      ? '<option value="">Pilih...</option>' + activeItems.map((i) => `<option value="${i.id}">${i.name} (${formatNumber(i.points_cost)} poin)</option>`).join("") + '<option value="__custom__">Lainnya (isi manual)...</option>'
      : '<option value="__custom__">Lainnya (isi manual)...</option>';
  }

  // Auto-fill poin saat memilih hadiah dari katalog
  rewardNameSelect.addEventListener("change", () => {
    const selected = catalogData.find((i) => i.id === rewardNameSelect.value);
    const pointsInput = document.getElementById("reward-points");
    if (selected) pointsInput.value = selected.points_cost;
  });

  document.getElementById("form-add-catalog").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-save-catalog");
    const newData = {
      name: document.getElementById("cat-name").value.trim(),
      category: document.getElementById("cat-category").value,
      points_cost: parseFloat(document.getElementById("cat-points").value),
      is_active: true,
    };
    btn.disabled = true;
    const { error } = await createCatalogItem(newData);
    btn.disabled = false;
    if (error) {
      showAlert("#loyalty-alert-container", "danger", "Gagal Menyimpan", error.message);
    } else {
      closeModal("modal-add-catalog");
      e.target.reset();
      loadCatalog();
      showAlert("#loyalty-alert-container", "success", "Berhasil", "Hadiah baru ditambahkan ke katalog.");
    }
  });

  catalogTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-catalog");
    if (btnEdit) {
      const item = catalogData.find((i) => i.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-cat-id").value = item.id;
        document.getElementById("edit-cat-name").value = item.name;
        document.getElementById("edit-cat-category").value = item.category;
        document.getElementById("edit-cat-points").value = item.points_cost;
        document.getElementById("edit-cat-active").value = String(item.is_active);
        openModal("modal-edit-catalog");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-catalog");
    if (btnDelete) {
      document.getElementById("delete-cat-id").value = btnDelete.dataset.id;
      openModal("modal-delete-catalog");
    }
  });

  document.getElementById("form-edit-catalog").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-cat-id").value;
    const updatedData = {
      name: document.getElementById("edit-cat-name").value.trim(),
      category: document.getElementById("edit-cat-category").value,
      points_cost: parseFloat(document.getElementById("edit-cat-points").value),
      is_active: document.getElementById("edit-cat-active").value === "true",
    };
    const { error } = await updateCatalogItem(id, updatedData);
    if (!error) {
      closeModal("modal-edit-catalog");
      loadCatalog();
      showAlert("#loyalty-alert-container", "success", "Diperbarui", "Data hadiah berhasil diubah.");
    } else {
      showAlert("#loyalty-alert-container", "danger", "Gagal", error.message);
    }
  });

  document.getElementById("btn-confirm-delete-catalog").addEventListener("click", async () => {
    const id = document.getElementById("delete-cat-id").value;
    const { error } = await deleteCatalogItem(id);
    if (!error) {
      closeModal("modal-delete-catalog");
      loadCatalog();
      showAlert("#loyalty-alert-container", "info", "Dihapus", "Hadiah telah dihapus dari katalog.");
    }
  });

  // ==========================================================
  // 3. RIWAYAT PENUKARAN HADIAH
  // ==========================================================
  const tbody = document.getElementById("loyalty-tbody");
  const selectCustomer = document.getElementById("reward-customer");

  async function loadTableData() {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const { data, error } = await getRedemptions();

    if (error) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    redemptionsData = data || [];
    redemptionsPage = 1;
    renderRedemptionsTable();
  }

  function renderRedemptionsTable() {
    if (redemptionsData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada riwayat penukaran hadiah.</td></tr>`;
      document.getElementById("loyalty-pagination").innerHTML = "";
      return;
    }

    const { items: pageItems, page, totalPages, totalItems } = paginate(redemptionsData, redemptionsPage, PAGE_SIZE);
    redemptionsPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((item) => {
      let badgeClass = "badge--warning";
      if (item.status === "Disetujui") badgeClass = "badge--success";
      if (item.status === "Ditolak") badgeClass = "badge--danger";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="text-sm text-muted">${formatDate(item.created_at)}</td>
        <td class="font-medium">${item.customers?.full_name || "Nasabah Dihapus"}</td>
        <td class="font-medium text-brand">${item.reward_name}${item.category ? ` <span class="badge ${categoryBadgeClass[item.category] || "badge--neutral"}" style="margin-left:4px;">${item.category}</span>` : ""}</td>
        <td><span class="text-danger">-${formatCurrency(item.points_used)}</span></td>
        <td><span class="badge ${badgeClass}">${item.status}</span></td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${item.id}" aria-label="Edit Status">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${item.id}" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#loyalty-pagination",
      currentPage: redemptionsPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        redemptionsPage = p;
        renderRedemptionsTable();
      },
    });
  }

  async function populateCustomerSelects() {
    const { data } = await getCustomers();
    if (data) {
      const activeCustomers = data.filter((c) => c.status === "Aktif");

      selectCustomer.innerHTML = '<option value="">Pilih Nasabah...</option>';
      activeCustomers.forEach((cust) => {
        const option = document.createElement("option");
        option.value = cust.id;
        option.textContent = cust.full_name;
        selectCustomer.appendChild(option);
      });

      const referrerSelect = document.getElementById("ref-referrer");
      referrerSelect.innerHTML = '<option value="">Pilih Nasabah...</option>';
      activeCustomers.forEach((cust) => {
        const option = document.createElement("option");
        option.value = cust.id;
        option.textContent = cust.full_name;
        referrerSelect.appendChild(option);
      });
    }
  }

  document.getElementById("form-add-reward").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btnSave = document.getElementById("btn-save-reward");
    const selectedCatalogId = rewardNameSelect.value;
    const selectedCatalogItem = catalogData.find((i) => i.id === selectedCatalogId);

    const newData = {
      customer_id: selectCustomer.value,
      reward_name: selectedCatalogItem ? selectedCatalogItem.name : "Hadiah Lainnya",
      category: selectedCatalogItem ? selectedCatalogItem.category : "Lainnya",
      points_used: parseFloat(document.getElementById("reward-points").value),
      notes: document.getElementById("reward-notes").value.trim(),
    };

    btnSave.disabled = true;
    const { error } = await createRedemption(newData);
    btnSave.disabled = false;

    if (!error) {
      closeModal("modal-add-reward");
      e.target.reset();
      loadTableData();
      loadOverview();
      showAlert("#loyalty-alert-container", "success", "Berhasil", "Pengajuan klaim hadiah berhasil dicatat.");
    } else {
      showAlert("#loyalty-alert-container", "danger", "Gagal Memproses", error.message);
    }
  });

  tbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const item = redemptionsData.find((s) => s.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-reward-id").value = item.id;
        document.getElementById("edit-reward-status").value = item.status;
        openModal("modal-edit-reward");
      }
    }

    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-reward-id").value = btnDelete.dataset.id;
      openModal("modal-delete-reward");
    }
  });

  document.getElementById("form-edit-reward").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-reward-id").value;
    const updatedData = { status: document.getElementById("edit-reward-status").value };

    const { error } = await updateRedemption(id, updatedData);
    if (!error) {
      closeModal("modal-edit-reward");
      loadTableData();
      loadOverview();
      showAlert("#loyalty-alert-container", "success", "Diperbarui", "Status persetujuan hadiah berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-reward").addEventListener("click", async () => {
    const id = document.getElementById("delete-reward-id").value;
    const { error } = await deleteRedemption(id);
    if (!error) {
      closeModal("modal-delete-reward");
      loadTableData();
      loadOverview();
      showAlert("#loyalty-alert-container", "info", "Dihapus", "Catatan klaim hadiah telah dibatalkan/dihapus.");
    }
  });

  // ==========================================================
  // 4. REFERRAL PROGRAM
  // ==========================================================
  const referralTbody = document.getElementById("referral-tbody");

  async function loadReferrals() {
    referralTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    const { data, error } = await getReferrals();

    if (error) {
      referralTbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    referralsData = data || [];

    referralTbody.innerHTML = referralsData.length
      ? referralsData
          .map((r) => {
            let badgeClass = "badge--warning";
            if (r.status === "Disetujui") badgeClass = "badge--success";
            if (r.status === "Ditolak") badgeClass = "badge--danger";
            return `
          <tr>
            <td class="text-sm text-muted">${formatDate(r.created_at)}</td>
            <td class="font-medium">${r.referrer?.full_name || "Nasabah Dihapus"}</td>
            <td>${r.referred_name}</td>
            <td>${formatNumber(r.bonus_points)} poin</td>
            <td><span class="badge ${badgeClass}">${r.status}</span></td>
            <td>
              <div class="table__actions">
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit-referral" data-id="${r.id}" aria-label="Edit"><span class="material-symbols-outlined">edit</span></button>
                <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete-referral" data-id="${r.id}" style="color: var(--color-danger);" aria-label="Hapus"><span class="material-symbols-outlined">delete</span></button>
              </div>
            </td>
          </tr>`;
          })
          .join("")
      : `<tr><td colspan="6" class="text-center p-md text-muted">Belum ada data referral.</td></tr>`;
  }

  document.getElementById("form-add-referral").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-save-referral");
    const newData = {
      referrer_id: document.getElementById("ref-referrer").value,
      referred_name: document.getElementById("ref-referred-name").value.trim(),
      bonus_points: parseFloat(document.getElementById("ref-bonus").value) || 0,
    };
    btn.disabled = true;
    const { error } = await createReferral(newData);
    btn.disabled = false;
    if (!error) {
      closeModal("modal-add-referral");
      e.target.reset();
      loadReferrals();
      showAlert("#loyalty-alert-container", "success", "Berhasil", "Referral baru berhasil dicatat.");
    } else {
      showAlert("#loyalty-alert-container", "danger", "Gagal Menyimpan", error.message);
    }
  });

  referralTbody.addEventListener("click", (e) => {
    const btnEdit = e.target.closest(".btn-edit-referral");
    if (btnEdit) {
      const item = referralsData.find((r) => r.id === btnEdit.dataset.id);
      if (item) {
        document.getElementById("edit-ref-id").value = item.id;
        document.getElementById("edit-ref-status").value = item.status;
        openModal("modal-edit-referral");
      }
    }
    const btnDelete = e.target.closest(".btn-delete-referral");
    if (btnDelete) {
      document.getElementById("delete-ref-id").value = btnDelete.dataset.id;
      openModal("modal-delete-referral");
    }
  });

  document.getElementById("form-edit-referral").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-ref-id").value;
    const updatedData = { status: document.getElementById("edit-ref-status").value };
    const { error } = await updateReferral(id, updatedData);
    if (!error) {
      closeModal("modal-edit-referral");
      loadReferrals();
      loadOverview(); // status disetujui mempengaruhi total poin & badge referral
      showAlert("#loyalty-alert-container", "success", "Diperbarui", "Status referral berhasil diubah.");
    }
  });

  document.getElementById("btn-confirm-delete-referral").addEventListener("click", async () => {
    const id = document.getElementById("delete-ref-id").value;
    const { error } = await deleteReferral(id);
    if (!error) {
      closeModal("modal-delete-referral");
      loadReferrals();
      loadOverview();
      showAlert("#loyalty-alert-container", "info", "Dihapus", "Data referral telah dihapus.");
    }
  });

  // ==========================================================
  // INISIALISASI AWAL
  // ==========================================================
  loadOverview();
  loadCatalog();
  loadTableData();
  populateCustomerSelects();
  loadReferrals();
});
