import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { getMyNotifications, getEducationalContent } from "../../supabase/engagement.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });

  // ==========================================
  // NOTIFIKASI, PROMO, CAMPAIGN, UCAPAN ULANG TAHUN
  // (dikirim Admin lewat modul Customer Engagement)
  // ==========================================
  const notifContainer = document.getElementById("notification-list");

  async function loadNotifications() {
    const { data, error } = await getMyNotifications(profile.id);

    if (error || !data || data.length === 0) {
      notifContainer.innerHTML = `
        <div class="card text-center p-md text-muted text-sm">
          <span class="material-symbols-outlined" style="font-size: 32px; display:block; margin-bottom: 8px;">notifications_off</span>
          Belum ada notifikasi atau campaign aktif saat ini.
        </div>`;
      return;
    }

    const typeIcon = { Info: "info", Promo: "local_offer", Reminder: "alarm", "Ulang Tahun": "cake" };

    notifContainer.innerHTML = data
      .map(
        (n) => `
      <div class="card flex items-start gap-md" style="padding: 14px 16px;">
        <span class="material-symbols-outlined text-brand">${typeIcon[n.type] || "notifications"}</span>
        <div class="flex-1">
          <div class="font-medium text-sm">${n.title}</div>
          <div class="text-caption text-muted mt-xs" style="line-height:1.5;">${n.message}</div>
          <div class="text-caption text-muted mt-xs" style="font-size: 10px;">${formatDate(n.created_at)}</div>
        </div>
      </div>`
      )
      .join("");
  }

  // ==========================================
  // EDUKASI (dikelola Admin lewat tabel educational_content;
  // fallback ke konten bawaan jika migrasi belum dijalankan)
  // ==========================================
  const fallbackTips = [
    { icon: "recycling", title: "Pisahkan Sampah dari Rumah", content: "Pisahkan plastik, kertas, logam, kaca, dan minyak jelantah sejak dari rumah agar proses penimbangan lebih cepat." },
    { icon: "water_drop", title: "Bersihkan Sebelum Disetor", content: "Cuci bersih wadah plastik/kaca dari sisa makanan agar bernilai lebih tinggi dan tidak berbau." },
    { icon: "eco", title: "Kurangi Sampah Sekali Pakai", content: "Bawa kantong belanja sendiri dan gunakan botol minum isi ulang untuk mengurangi sampah plastik." },
    { icon: "savings", title: "Konsisten Menabung Sampah", content: "Setor sampah secara rutin agar saldo dan poin reward Anda terus bertambah, dan naik tier membership lebih cepat." },
  ];

  async function loadEducation() {
    const { data, error } = await getEducationalContent(true);
    const tips = error || !data || data.length === 0 ? fallbackTips : data;

    document.getElementById("edukasi-list").innerHTML = tips
      .map(
        (t) => `
      <div class="card flex items-start gap-md" style="padding: 14px 16px;">
        <span class="material-symbols-outlined text-brand">${t.icon}</span>
        <div class="flex-1">
          <div class="font-medium text-sm">${t.title}</div>
          <div class="text-caption text-muted mt-xs" style="line-height:1.5;">${t.content}</div>
        </div>
      </div>`
      )
      .join("");
  }

  loadNotifications();
  loadEducation();
});
