import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { getNasabahTransactions } from "../../supabase/nasabah.js";
import { getWastePrices, getMySaldoDigital, getMyWithdrawals, requestWithdrawal } from "../../supabase/transactions.js";
import { openModal, initModals } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();
  initModals();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const formatDate = (isoString) => new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  const formatCurrency = (amount) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount || 0);

  // ==========================================
  // TAB SWITCHING
  // ==========================================
  const tabButtons = document.querySelectorAll("#tx-tabs [data-tab]");
  const panels = {
    setoran: document.getElementById("panel-setoran"),
    penarikan: document.getElementById("panel-penarikan"),
    estimasi: document.getElementById("panel-estimasi"),
  };

  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabButtons.forEach((b) => b.classList.replace("btn--primary", "btn--secondary"));
      btn.classList.replace("btn--secondary", "btn--primary");
      Object.entries(panels).forEach(([key, el]) => {
        el.style.display = key === btn.dataset.tab ? "block" : "none";
      });
    });
  });

  // ==========================================
  // ESTIMASI HARGA (dari tabel waste_prices yang dikelola Admin;
  // fallback ke referensi statis jika migrasi belum dijalankan)
  // ==========================================
  const fallbackHarga = [
    { waste_type: "Plastik PET", price_per_kg: 3000 },
    { waste_type: "Kertas / Kardus", price_per_kg: 1500 },
    { waste_type: "Logam / Kaleng", price_per_kg: 5000 },
    { waste_type: "Kaca / Beling", price_per_kg: 800 },
    { waste_type: "Minyak Jelantah", price_per_kg: 4000 },
  ];

  async function loadEstimasiHarga() {
    const { data, error } = await getWastePrices();
    const prices = error || !data || data.length === 0 ? fallbackHarga : data;

    document.getElementById("estimasi-tbody").innerHTML = prices
      .map((p) => `<tr><td>${p.waste_type}</td><td>${formatCurrency(p.price_per_kg)}/kg</td></tr>`)
      .join("");
  }

  // ==========================================
  // RIWAYAT SETORAN + E-RECEIPT
  // ==========================================
  let transactionsData = [];
  const listSetoran = document.getElementById("list-setoran");

  async function loadTransactions() {
    const { data } = await getNasabahTransactions(profile.id);
    transactionsData = data || [];

    if (transactionsData.length === 0) {
      listSetoran.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada riwayat setoran sampah.</div>`;
      return;
    }

    listSetoran.innerHTML = "";
    transactionsData.forEach((t) => {
      let badgeClass = "badge--warning";
      if (t.status === "Selesai") badgeClass = "badge--success";
      if (t.status === "Dibatalkan") badgeClass = "badge--danger";

      const card = document.createElement("div");
      card.className = "card flex items-center gap-md";
      card.style.cssText = "padding: 12px 16px; cursor: pointer;";
      card.innerHTML = `
        <div class="flex-1">
          <div class="font-medium text-sm">${t.waste_type}</div>
          <div class="text-caption text-muted">${formatDate(t.created_at)} • ${t.weight_kg} kg</div>
        </div>
        <span class="badge ${badgeClass}">${t.status}</span>
        <span class="material-symbols-outlined text-muted">chevron_right</span>
      `;
      card.addEventListener("click", () => openReceipt(t));
      listSetoran.appendChild(card);
    });
  }

  function openReceipt(t) {
    document.getElementById("receipt-body").innerHTML = `
      <div style="text-align:center; margin-bottom: 12px;">
        <div class="font-semibold">BANK SAMPAH</div>
        <div class="text-caption text-muted">E-Receipt Setoran Sampah</div>
      </div>
      <hr style="border: none; border-top: 1px dashed var(--color-border); margin: 8px 0;" />
      <div class="flex justify-between text-sm mb-xs"><span>No. Transaksi</span><span>${t.id.slice(0, 8).toUpperCase()}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Tanggal</span><span>${formatDate(t.created_at)}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Nasabah</span><span>${profile.full_name}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Jenis Sampah</span><span>${t.waste_type}</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Berat</span><span>${t.weight_kg} kg</span></div>
      <div class="flex justify-between text-sm mb-xs"><span>Status</span><span>${t.status}</span></div>
      <hr style="border: none; border-top: 1px dashed var(--color-border); margin: 8px 0;" />
      <div class="flex justify-between font-semibold"><span>Total Saldo</span><span>${formatCurrency(t.total_reward)}</span></div>
    `;
    openModal("modal-receipt");
  }

  // ==========================================
  // SALDO DIGITAL & RIWAYAT PENARIKAN
  // ==========================================
  const listPenarikan = document.getElementById("list-penarikan");
  let currentBalance = 0;

  async function loadSaldoDigital() {
    const { currentBalance: balance, error } = await getMySaldoDigital(profile.id);
    currentBalance = error ? 0 : balance;
    document.getElementById("saldo-current").textContent = formatCurrency(currentBalance);
  }

  async function loadPenarikan() {
    const { data, error } = await getMyWithdrawals(profile.id);

    if (error) {
      listPenarikan.innerHTML = `<div class="card text-center p-md text-muted text-sm">Fitur ini memerlukan migrasi database tambahan (tabel withdrawals). Hubungi admin.</div>`;
      return;
    }

    if (!data || data.length === 0) {
      listPenarikan.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada riwayat penarikan saldo.</div>`;
      return;
    }

    listPenarikan.innerHTML = "";
    data.forEach((item) => {
      let badgeClass = "badge--warning";
      if (item.status === "Disetujui") badgeClass = "badge--success";
      if (item.status === "Ditolak") badgeClass = "badge--danger";

      listPenarikan.innerHTML += `
        <div class="card flex items-center justify-between" style="padding: 12px 16px;">
          <div>
            <div class="font-medium text-sm text-brand">${item.method}</div>
            <div class="text-caption text-muted mt-xs">${formatDate(item.created_at)} • -${formatCurrency(item.amount)}</div>
          </div>
          <span class="badge ${badgeClass}">${item.status}</span>
        </div>
      `;
    });
  }

  document.getElementById("form-request-withdrawal").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-request-withdrawal");
    const amount = parseFloat(document.getElementById("wd-request-amount").value);

    if (amount > currentBalance) {
      showAlert("#user-alert-container", "danger", "Saldo Tidak Cukup", `Saldo Anda saat ini hanya ${formatCurrency(currentBalance)}.`);
      return;
    }

    const newData = {
      customer_id: profile.id,
      amount,
      method: document.getElementById("wd-request-method").value,
    };

    btn.disabled = true;
    const { error } = await requestWithdrawal(newData);
    btn.disabled = false;

    if (!error) {
      e.target.reset();
      showAlert("#user-alert-container", "success", "Terkirim", "Permintaan penarikan saldo berhasil diajukan, menunggu persetujuan admin.");
      loadPenarikan();
    } else {
      showAlert("#user-alert-container", "danger", "Gagal Mengajukan", "Fitur ini memerlukan migrasi database tambahan (tabel withdrawals). Hubungi admin.");
    }
  });

  loadTransactions();
  loadEstimasiHarga();
  loadSaldoDigital();
  loadPenarikan();
});
