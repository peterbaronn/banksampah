import { getNasabahSchedules, requestPenjemputan } from "../../supabase/nasabah.js";
import { rescheduleSchedule } from "../../supabase/scheduling.js";
import { requireNasabahProfile } from "../utils/nasabah-guard.js";
import { initUserBottomNav } from "../components/user-bottom-nav.js";
import { openModal, closeModal, initModals } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";

document.addEventListener("DOMContentLoaded", async () => {
  initUserBottomNav();
  initModals();

  const profile = await requireNasabahProfile();
  if (!profile) return;

  const listContainer = document.getElementById("list-jemput");
  const formJemput = document.getElementById("form-jemput");
  const btnSubmit = document.getElementById("btn-submit-jemput");

  // Load Riwayat Penjemputan
  async function loadSchedules() {
    listContainer.innerHTML = '<div class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></div>';
    const { data } = await getNasabahSchedules(profile.id);
    
    if (!data || data.length === 0) {
      listContainer.innerHTML = `<div class="card text-center p-md text-muted text-sm">Belum ada riwayat booking penjemputan.</div>`;
      return;
    }

    listContainer.innerHTML = "";
    data.forEach(item => {
      let badgeClass = "badge--info";
      let icon = "schedule";
      if (item.status === "Selesai") { badgeClass = "badge--success"; icon = "check_circle"; }
      if (item.status === "Dibatalkan") { badgeClass = "badge--danger"; icon = "cancel"; }

      const dateStr = new Date(item.pickup_date).toLocaleDateString('id-ID', {day: '2-digit', month: 'short', year: 'numeric'});
      const driver = item.drivers;
      const driverInfo = driver
        ? `<div class="text-caption mt-xs" style="color: var(--color-primary);">🚚 ${driver.name}${item.eta_minutes ? ` • ETA ~${item.eta_minutes} menit` : ""}</div>`
        : "";
      const rescheduleBtn = item.status === "Terjadwal"
        ? `<button type="button" class="btn btn--secondary btn--sm btn-reschedule" data-id="${item.id}" data-date="${item.pickup_date}" data-time="${item.pickup_time}" data-count="${item.reschedule_count || 0}" style="margin-top:8px;">
            <span class="material-symbols-outlined" style="font-size:16px;">event_repeat</span> Reschedule
          </button>`
        : "";

      listContainer.innerHTML += `
        <div class="card flex items-start gap-sm" style="padding: 12px 16px;">
          <span class="material-symbols-outlined text-muted" style="margin-top:2px;">${icon}</span>
          <div class="flex-1">
            <div class="font-medium text-sm">${dateStr} • ${item.pickup_time}</div>
            <div class="text-caption text-muted mt-xs" style="line-height:1.3;">${item.address_notes || 'Sesuai alamat profil'}</div>
            ${driverInfo}
            ${rescheduleBtn}
          </div>
          <span class="badge ${badgeClass}">${item.status}</span>
        </div>
      `;
    });

    // Wire tombol reschedule
    listContainer.querySelectorAll(".btn-reschedule").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.getElementById("reschedule-id").value = btn.dataset.id;
        document.getElementById("reschedule-count").value = btn.dataset.count;
        document.getElementById("reschedule-date").value = btn.dataset.date;
        document.getElementById("reschedule-time").value = btn.dataset.time;
        openModal("modal-reschedule");
      });
    });
  }

  document.getElementById("form-reschedule").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("reschedule-id").value;
    const currentCount = parseInt(document.getElementById("reschedule-count").value, 10) || 0;
    const newDate = document.getElementById("reschedule-date").value;
    const newTime = document.getElementById("reschedule-time").value;

    const { error } = await rescheduleSchedule(id, newDate, newTime, currentCount);
    if (!error) {
      closeModal("modal-reschedule");
      showAlert("#user-alert-container", "success", "Berhasil", "Jadwal penjemputan berhasil diubah.");
      loadSchedules();
    } else {
      showAlert("#user-alert-container", "danger", "Gagal", "Pastikan migrasi kolom reschedule_count sudah dijalankan.");
    }
  });

  // Handle Form Submit
  formJemput.addEventListener("submit", async (e) => {
    e.preventDefault();
    btnSubmit.disabled = true;
    btnSubmit.textContent = "Memproses...";

    const reqData = {
      customer_id: profile.id,
      pickup_date: document.getElementById("j-date").value,
      pickup_time: document.getElementById("j-time").value,
      address_notes: document.getElementById("j-notes").value
    };

    const { error } = await requestPenjemputan(reqData);
    
    btnSubmit.disabled = false;
    btnSubmit.textContent = "Pesan Sekarang";

    if (!error) {
      formJemput.reset();
      showAlert("#user-alert-container", "success", "Berhasil", "Booking penjemputan terkirim! Tim kami akan segera menghubungi.");
      loadSchedules();
    } else {
      showAlert("#user-alert-container", "danger", "Gagal", error.message);
    }
  });

  loadSchedules();
});