/**
 * pages/customers.js
 * ------------------------------------------------------
 * Logika halaman Customer Data Management:
 *  - Profil pelanggan (CRUD)
 *  - Segmentasi pelanggan (field + filter)
 *  - Status keaktifan pelanggan
 *  - Riwayat aktivitas pelanggan (modal detail)
 * ------------------------------------------------------
 */

import {
  getCustomers,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  getLastActivityMap,
  getCustomerActivity,
} from "../../supabase/customers.js";
import { openModal, closeModal } from "../utils/modal.js";
import { showAlert } from "../utils/alert.js";
import { renderPagination, paginate } from "../utils/pagination.js";

document.addEventListener("DOMContentLoaded", () => {
  const tbody = document.getElementById("customers-tbody");
  const searchInput = document.getElementById("search-customer");
  const segmentFilter = document.getElementById("filter-segment");

  const statTotal = document.getElementById("stat-total-customers");
  const statActive = document.getElementById("stat-active-customers");
  const statInactive = document.getElementById("stat-inactive-customers");
  const statNew = document.getElementById("stat-new-customers");

  // State penyimpan data sementara untuk keperluan Edit/Delete/Riwayat
  let customersData = [];
  let lastActivityMap = {};
  let searchTimeout = null;
  const PAGE_SIZE = 10;
  let customersPage = 1;

  const formatDate = (isoString) =>
    isoString ? new Date(isoString).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }) : "-";

  const formatCurrency = (amount) =>
    new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount || 0);

  // ==========================================
  // 0. STAT CARDS
  // ==========================================
  function renderStats(allCustomers) {
    const total = allCustomers.length;
    const active = allCustomers.filter((c) => c.status === "Aktif").length;
    const inactive = total - active;
    const now = new Date();
    const newThisMonth = allCustomers.filter((c) => {
      const d = new Date(c.created_at);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).length;

    statTotal.textContent = total.toLocaleString("id-ID");
    statActive.textContent = active.toLocaleString("id-ID");
    statInactive.textContent = inactive.toLocaleString("id-ID");
    statNew.textContent = newThisMonth.toLocaleString("id-ID");
  }

  // ==========================================
  // 1. READ & SEARCH & FILTER DATA
  // ==========================================
  async function loadTableData(searchQuery = "", segment = "") {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span> Memuat data...</td></tr>`;

    const [{ data, error }, { map, error: mapError }] = await Promise.all([
      getCustomers(searchQuery, segment),
      getLastActivityMap(),
    ]);

    if (error) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-danger">Gagal memuat data: ${error.message}</td></tr>`;
      return;
    }

    if (!mapError) lastActivityMap = map;

    customersData = data || [];

    // Stat cards selalu dihitung dari keseluruhan data nasabah (tanpa filter pencarian/segmen)
    if (!searchQuery && !segment) {
      renderStats(customersData);
    } else if (statTotal.textContent === "-") {
      // Saat pertama load dengan filter aktif (jarang terjadi), tetap ambil total sekali
      const { data: allData } = await getCustomers();
      if (allData) renderStats(allData);
    }

    if (customersData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center p-md text-muted">Tidak ada data nasabah ditemukan.</td></tr>`;
      document.getElementById("customers-pagination").innerHTML = "";
      return;
    }

    customersPage = 1;
    renderCustomersTable();
  }

  function renderCustomersTable() {
    if (customersData.length === 0) return;

    const { items: pageItems, page, totalPages, totalItems } = paginate(customersData, customersPage, PAGE_SIZE);
    customersPage = page;

    tbody.innerHTML = "";
    pageItems.forEach((cust) => {
      const badgeClass = cust.status === "Aktif" ? "badge--success" : "badge--danger";
      const lastActive = lastActivityMap[cust.id];

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="font-medium">${cust.full_name}</td>
        <td>${cust.phone || "-"}</td>
        <td>${cust.segment ? `<span class="badge badge--neutral">${cust.segment}</span>` : '<span class="text-muted text-sm">Belum diatur</span>'}</td>
        <td><span class="badge ${badgeClass}">${cust.status}</span></td>
        <td class="text-sm ${lastActive ? "" : "text-muted"}">${lastActive ? formatDate(lastActive) : "Belum ada aktivitas"}</td>
        <td>
          <div class="table__actions">
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-history" data-id="${cust.id}" aria-label="Riwayat Aktivitas">
              <span class="material-symbols-outlined">history</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-edit" data-id="${cust.id}" aria-label="Edit">
              <span class="material-symbols-outlined">edit</span>
            </button>
            <button type="button" class="btn btn--icon btn--ghost btn--sm btn-delete" data-id="${cust.id}" aria-label="Hapus" style="color: var(--color-danger);">
              <span class="material-symbols-outlined">delete</span>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderPagination({
      container: "#customers-pagination",
      currentPage: customersPage,
      totalPages,
      totalItems,
      pageSize: PAGE_SIZE,
      onPageChange: (p) => {
        customersPage = p;
        renderCustomersTable();
      },
    });
  }

  // Event listener untuk search box (dengan debounce 300ms agar tidak spam API)
  searchInput.addEventListener("input", (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      loadTableData(e.target.value.trim(), segmentFilter.value);
    }, 300);
  });

  // Event listener untuk filter segmen
  segmentFilter.addEventListener("change", () => {
    loadTableData(searchInput.value.trim(), segmentFilter.value);
  });

  // ==========================================
  // 2. CREATE DATA (TAMBAH)
  // ==========================================
  const formAdd = document.getElementById("form-add-customer");
  const btnSave = document.getElementById("btn-save-customer");

  formAdd.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newData = {
      full_name: document.getElementById("cust-name").value.trim(),
      phone: document.getElementById("cust-phone").value.trim(),
      address: document.getElementById("cust-address").value.trim(),
      segment: document.getElementById("cust-segment").value,
      birth_date: document.getElementById("cust-birthdate").value || null,
    };

    btnSave.disabled = true;
    btnSave.textContent = "Menyimpan...";

    const { error } = await createCustomer(newData);

    btnSave.disabled = false;
    btnSave.textContent = "Simpan Nasabah";

    if (error) {
      showAlert("#customers-alert-container", "danger", "Gagal Menyimpan", error.message);
    } else {
      closeModal("modal-add-customer");
      formAdd.reset();
      loadTableData(searchInput.value, segmentFilter.value);
      showAlert("#customers-alert-container", "success", "Berhasil", "Data nasabah baru ditambahkan.");
    }
  });

  // ==========================================
  // 3. UPDATE, DELETE & RIWAYAT (Delegasi Event)
  // ==========================================
  tbody.addEventListener("click", (e) => {
    // Tangkap tombol edit
    const btnEdit = e.target.closest(".btn-edit");
    if (btnEdit) {
      const id = btnEdit.dataset.id;
      const cust = customersData.find((c) => c.id === id);
      if (cust) {
        document.getElementById("edit-cust-id").value = cust.id;
        document.getElementById("edit-cust-name").value = cust.full_name;
        document.getElementById("edit-cust-phone").value = cust.phone;
        document.getElementById("edit-cust-address").value = cust.address;
        document.getElementById("edit-cust-segment").value = cust.segment || "Rumah Tangga";
        document.getElementById("edit-cust-birthdate").value = cust.birth_date || "";
        document.getElementById("edit-cust-status").value = cust.status;
        openModal("modal-edit-customer");
      }
    }

    // Tangkap tombol delete
    const btnDelete = e.target.closest(".btn-delete");
    if (btnDelete) {
      document.getElementById("delete-cust-id").value = btnDelete.dataset.id;
      openModal("modal-delete-customer");
    }

    // Tangkap tombol riwayat aktivitas
    const btnHistory = e.target.closest(".btn-history");
    if (btnHistory) {
      const id = btnHistory.dataset.id;
      const cust = customersData.find((c) => c.id === id);
      if (cust) openCustomerHistory(cust);
    }
  });

  // Handle Update Submit
  const formEdit = document.getElementById("form-edit-customer");
  const btnUpdate = document.getElementById("btn-update-customer");

  formEdit.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-cust-id").value;
    const updatedData = {
      full_name: document.getElementById("edit-cust-name").value.trim(),
      phone: document.getElementById("edit-cust-phone").value.trim(),
      address: document.getElementById("edit-cust-address").value.trim(),
      segment: document.getElementById("edit-cust-segment").value,
      birth_date: document.getElementById("edit-cust-birthdate").value || null,
      status: document.getElementById("edit-cust-status").value,
    };

    btnUpdate.disabled = true;
    btnUpdate.textContent = "Menyimpan...";

    const { error } = await updateCustomer(id, updatedData);

    btnUpdate.disabled = false;
    btnUpdate.textContent = "Update Data";

    if (error) {
      showAlert("#customers-alert-container", "danger", "Gagal Memperbarui", error.message);
    } else {
      closeModal("modal-edit-customer");
      loadTableData(searchInput.value, segmentFilter.value);
      showAlert("#customers-alert-container", "success", "Diperbarui", "Data nasabah berhasil diubah.");
    }
  });

  // Handle Delete Confirmation
  const btnConfirmDelete = document.getElementById("btn-confirm-delete");
  btnConfirmDelete.addEventListener("click", async () => {
    const id = document.getElementById("delete-cust-id").value;

    btnConfirmDelete.disabled = true;
    btnConfirmDelete.textContent = "Menghapus...";

    const { error } = await deleteCustomer(id);

    btnConfirmDelete.disabled = false;
    btnConfirmDelete.textContent = "Ya, Hapus";

    if (error) {
      showAlert("#customers-alert-container", "danger", "Gagal Menghapus", error.message);
    } else {
      closeModal("modal-delete-customer");
      loadTableData(searchInput.value, segmentFilter.value);
      showAlert("#customers-alert-container", "info", "Dihapus", "Data nasabah telah dihapus dari sistem.");
    }
  });

  // ==========================================
  // 4. RIWAYAT AKTIVITAS NASABAH
  // ==========================================
  async function openCustomerHistory(cust) {
    document.getElementById("history-cust-name").textContent = cust.full_name;
    document.getElementById("history-cust-meta").textContent = `${cust.phone || "-"} • ${cust.address || "Alamat belum diisi"} • Bergabung ${formatDate(cust.created_at)}`;
    document.getElementById("history-cust-segment").textContent = cust.segment || "Segmen belum diatur";
    const statusBadge = document.getElementById("history-cust-status");
    statusBadge.textContent = cust.status;
    statusBadge.className = `badge ${cust.status === "Aktif" ? "badge--success" : "badge--danger"}`;

    const txBody = document.getElementById("history-transactions-tbody");
    const compBody = document.getElementById("history-complaints-tbody");
    const schedBody = document.getElementById("history-schedules-tbody");
    const redeemBody = document.getElementById("history-redemptions-tbody");

    txBody.innerHTML = `<tr><td colspan="4" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    compBody.innerHTML = `<tr><td colspan="3" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    schedBody.innerHTML = `<tr><td colspan="3" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;
    redeemBody.innerHTML = `<tr><td colspan="3" class="text-center p-md text-muted"><span class="spinner spinner--sm"></span></td></tr>`;

    openModal("modal-customer-history");

    const { transactions, complaints, schedules, redemptions, error } = await getCustomerActivity(cust.id);

    if (error) {
      const errRow = `<tr><td colspan="4" class="text-center p-md text-danger">Gagal memuat riwayat.</td></tr>`;
      txBody.innerHTML = compBody.innerHTML = schedBody.innerHTML = redeemBody.innerHTML = errRow;
      return;
    }

    // Transaksi
    txBody.innerHTML = transactions.length
      ? transactions
          .map((tx) => {
            let badgeClass = "badge--warning";
            if (tx.status === "Selesai") badgeClass = "badge--success";
            if (tx.status === "Dibatalkan") badgeClass = "badge--danger";
            return `<tr><td class="text-sm">${formatDate(tx.created_at)}</td><td>${tx.waste_type}</td><td>${tx.weight_kg} kg</td><td><span class="badge ${badgeClass}">${tx.status}</span></td></tr>`;
          })
          .join("")
      : `<tr><td colspan="4" class="text-center p-md text-muted">Belum ada transaksi.</td></tr>`;

    // Pengaduan
    compBody.innerHTML = complaints.length
      ? complaints
          .map((c) => {
            let badgeClass = "badge--danger";
            if (c.status === "Diproses") badgeClass = "badge--warning";
            if (c.status === "Selesai") badgeClass = "badge--success";
            return `<tr><td class="text-sm">${formatDate(c.created_at)}</td><td>${c.subject}</td><td><span class="badge ${badgeClass}">${c.status}</span></td></tr>`;
          })
          .join("")
      : `<tr><td colspan="3" class="text-center p-md text-muted">Belum ada pengaduan.</td></tr>`;

    // Penjemputan
    schedBody.innerHTML = schedules.length
      ? schedules
          .map((s) => {
            let badgeClass = "badge--info";
            if (s.status === "Selesai") badgeClass = "badge--success";
            if (s.status === "Dibatalkan") badgeClass = "badge--danger";
            return `<tr><td class="text-sm">${formatDate(s.pickup_date)}</td><td>${s.pickup_time || "-"}</td><td><span class="badge ${badgeClass}">${s.status}</span></td></tr>`;
          })
          .join("")
      : `<tr><td colspan="3" class="text-center p-md text-muted">Belum ada jadwal penjemputan.</td></tr>`;

    // Penukaran Reward
    redeemBody.innerHTML = redemptions.length
      ? redemptions
          .map((r) => {
            let badgeClass = "badge--warning";
            if (r.status === "Disetujui") badgeClass = "badge--success";
            if (r.status === "Ditolak") badgeClass = "badge--danger";
            return `<tr><td class="text-sm">${formatDate(r.created_at)}</td><td>${formatCurrency(r.points_used)}</td><td><span class="badge ${badgeClass}">${r.status}</span></td></tr>`;
          })
          .join("")
      : `<tr><td colspan="3" class="text-center p-md text-muted">Belum ada penukaran reward.</td></tr>`;
  }

  // Inisialisasi awal
  loadTableData();
});
