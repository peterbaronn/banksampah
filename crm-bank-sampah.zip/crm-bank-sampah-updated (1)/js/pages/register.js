/**
 * pages/register.js
 * ------------------------------------------------------
 * Menangani validasi dan pendaftaran Nasabah Baru secara aman.
 * ------------------------------------------------------
 */

import { registerNasabah, getSession } from "../../supabase/auth.js";

document.addEventListener("DOMContentLoaded", () => {
  // 1. DEKLARASI DOM ELEMENTS DULUAN (Wajib)
  const registerForm = document.getElementById("register-form");
  const nameInput = document.getElementById("fullname");
  const phoneInput = document.getElementById("phone");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  
  const togglePasswordBtn = document.getElementById("toggle-password");
  const btnRegister = document.getElementById("btn-register");
  const btnText = document.getElementById("btn-register-text");
  const btnSpinner = document.getElementById("btn-register-spinner");
  
  const alertBox = document.getElementById("register-alert");
  const alertMsg = document.getElementById("register-alert-msg");

  // 2. PASANG PENAHAN FORM (Event Listener) AGAR TIDAK REFRESH
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault(); // Ini fungsi penahan ajaibnya!

      // Reset error classes
      document.querySelectorAll(".form-group").forEach(g => g.classList.remove("has-error"));
      alertBox.classList.add("hidden");

      const fullName = nameInput.value.trim();
      const phone = phoneInput.value.trim();
      const email = emailInput.value.trim();
      const password = passwordInput.value;
      let isValid = true;

      // Validasi Input
      if (!fullName) { document.getElementById("group-name").classList.add("has-error"); isValid = false; }
      if (!phone) { document.getElementById("group-phone").classList.add("has-error"); isValid = false; }
      if (!email || !/\S+@\S+\.\S+/.test(email)) { document.getElementById("group-email").classList.add("has-error"); isValid = false; }
      if (!password || password.length < 6) { document.getElementById("group-password").classList.add("has-error"); isValid = false; }

      if (!isValid) return;

      // Ubah tombol jadi "Loading"
      btnRegister.disabled = true;
      btnText.classList.add("hidden");
      btnSpinner.classList.remove("hidden");

      try {
        // Eksekusi Pendaftaran ke Supabase
        const { error } = await registerNasabah(email, password, fullName, phone);

        if (error) {
          let errorMessage = error.message || error.details || JSON.stringify(error);
          if (errorMessage.includes("User already registered")) {
            errorMessage = "Email ini sudah terdaftar. Silakan menuju halaman Login.";
          }

          alertMsg.textContent = errorMessage;
          alertBox.classList.remove("hidden");
          
          // Kembalikan tombol seperti semula
          btnRegister.disabled = false;
          btnText.classList.remove("hidden");
          btnSpinner.classList.add("hidden");
        } else {
          // Jika Berhasil -> Pindah ke Dashboard Nasabah
          window.location.replace("/pages/user-dashboard.html");
        }
      } catch (err) {
        // Tangkap jika terjadi koneksi putus
        alertMsg.textContent = "Terjadi masalah jaringan atau database.";
        alertBox.classList.remove("hidden");
        btnRegister.disabled = false;
        btnText.classList.remove("hidden");
        btnSpinner.classList.add("hidden");
      }
    });
  }

  // 3. TOGGLE PASSWORD
  if (togglePasswordBtn) {
    togglePasswordBtn.addEventListener("click", () => {
      const isPassword = passwordInput.getAttribute("type") === "password";
      passwordInput.setAttribute("type", isPassword ? "text" : "password");
      togglePasswordBtn.querySelector("span").textContent = isPassword ? "visibility_off" : "visibility";
    });
  }

  // 4. CEK SESI BELAKANGAN AGAR TIDAK MENGGANGGU FORM
  (async () => {
    try {
      const { session } = await getSession();
      if (session) {
        window.location.replace("/pages/user-dashboard.html");
      }
    } catch (err) {
      console.warn("Gagal mengecek sesi aktif.", err);
    }
  })();
});