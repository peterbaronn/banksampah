/**
 * config.js
 * ------------------------------------------------------
 * Satu-satunya sumber konfigurasi aplikasi.
 * ------------------------------------------------------
 */

export const CONFIG = {
  // Informasi Aplikasi
  APP_NAME: "CRM Bank Sampah",
  APP_VERSION: "0.1.0",
  APP_ENV: "development", 

  // Konfigurasi Supabase (Ganti dengan kredensial proyek Supabase Anda)
  SUPABASE_URL: "https://pzhxnnlitwxreuqvknge.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB6aHhubmxpdHd4cmV1cXZrbmdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMzMjQwODMsImV4cCI6MjA5ODkwMDA4M30.0A8rgVnRZZwcUxIewbgSeM7RHuFynEfiJOCsGlSkl-g",

  // Konfigurasi Path
  BASE_PATH: "/",
  PAGES_PATH: "/pages/",
  PARTIALS_PATH: "/partials/",
};

export default CONFIG;