-- ============================================================
-- Migration: Customer Engagement Management (Admin)
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Kolom birth_date pada customers (untuk Ucapan Ulang Tahun)
--   2. Tabel notifications (Notifikasi, Broadcast, Reminder, Ucapan Ulang Tahun)
--   3. Tabel campaigns (Campaign)
--   4. Tabel educational_content (Edukasi, dikelola Admin)
-- ============================================================

-- 1. Tanggal lahir nasabah, dipakai untuk Ucapan Ulang Tahun otomatis
ALTER TABLE customers
ADD COLUMN IF NOT EXISTS birth_date DATE;

-- 2. Notifikasi / Broadcast / Reminder / Ucapan Ulang Tahun
-- customer_id NULL berarti broadcast ke SEMUA nasabah aktif
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'Info', -- Info | Promo | Reminder | Ulang Tahun
  channel TEXT NOT NULL DEFAULT 'In-App', -- In-App | WhatsApp | Email | SMS
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Campaign pemasaran/edukasi ke segmen tertentu
CREATE TABLE IF NOT EXISTS campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  target_segment TEXT, -- kosong/NULL berarti semua segmen
  start_date DATE,
  end_date DATE,
  status TEXT NOT NULL DEFAULT 'Draft', -- Draft | Aktif | Selesai
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Konten Edukasi (dikelola Admin, ditampilkan di Portal Nasabah)
CREATE TABLE IF NOT EXISTS educational_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  icon TEXT NOT NULL DEFAULT 'eco', -- nama ikon Material Symbols
  is_published BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO educational_content (title, content, icon, sort_order)
VALUES
  ('Pisahkan Sampah dari Rumah', 'Pisahkan plastik, kertas, logam, kaca, dan minyak jelantah sejak dari rumah agar proses penimbangan lebih cepat.', 'recycling', 1),
  ('Bersihkan Sebelum Disetor', 'Cuci bersih wadah plastik/kaca dari sisa makanan agar bernilai lebih tinggi dan tidak berbau.', 'water_drop', 2),
  ('Kurangi Sampah Sekali Pakai', 'Bawa kantong belanja sendiri dan gunakan botol minum isi ulang untuk mengurangi sampah plastik.', 'eco', 3),
  ('Konsisten Menabung Sampah', 'Setor sampah secara rutin agar saldo dan poin reward Anda terus bertambah, dan naik tier membership lebih cepat.', 'savings', 4)
ON CONFLICT DO NOTHING;
