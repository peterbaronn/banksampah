-- ============================================================
-- Migration: Struktur Akses Admin vs User (Portal Nasabah)
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Kolom "rating" pada complaints (Rating Pelayanan - Nasabah)
--   2. Tabel service_requests (Call Request & Appointment Booking)
-- ============================================================

-- 1. Rating Pelayanan yang diberikan nasabah setelah pengaduan selesai
ALTER TABLE complaints
ADD COLUMN IF NOT EXISTS rating INT CHECK (rating BETWEEN 1 AND 5);

-- 2. Tabel Permintaan Layanan (Call Request & Appointment Booking)
-- dipakai oleh modul Customer Service pada Portal Nasabah
CREATE TABLE IF NOT EXISTS service_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
  type TEXT NOT NULL DEFAULT 'call_request', -- call_request | appointment
  preferred_time TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Menunggu', -- Menunggu | Diproses | Selesai
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- Tambahan: Live Chat per Pengaduan (Complaint Management)
-- Percakapan antara Admin dan Nasabah untuk satu tiket keluhan.
-- ============================================================
CREATE TABLE IF NOT EXISTS complaint_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id UUID REFERENCES complaints(id) ON DELETE CASCADE,
  sender_role TEXT NOT NULL DEFAULT 'Nasabah', -- 'Admin' | 'Nasabah'
  sender_name TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
