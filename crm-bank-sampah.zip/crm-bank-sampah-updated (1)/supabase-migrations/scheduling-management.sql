-- ============================================================
-- Migration: Scheduling Management (Admin & Nasabah)
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Tabel drivers (untuk Tracking Driver)
--   2. Kolom driver_id, eta_minutes, reschedule_count pada schedules
-- ============================================================

-- 1. Master data driver/petugas penjemputan
CREATE TABLE IF NOT EXISTS drivers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT,
  vehicle_plate TEXT,
  status TEXT NOT NULL DEFAULT 'Aktif', -- Aktif | Nonaktif
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Tambahan kolom pada schedules untuk Tracking Driver,
-- Estimasi Kedatangan (ETA), dan riwayat Reschedule
ALTER TABLE schedules
ADD COLUMN IF NOT EXISTS driver_id UUID REFERENCES drivers(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS eta_minutes INT,
ADD COLUMN IF NOT EXISTS reschedule_count INT NOT NULL DEFAULT 0;
