-- ============================================================
-- Migration: Loyalty Program module
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Kolom "category" pada reward_redemptions (Voucher/Cashback/Sembako/Lainnya)
--   2. Tabel reward_catalog (katalog hadiah yang bisa dikelola admin)
--   3. Tabel referrals (Referral Program)
-- ============================================================

-- 1. Tambah kolom category pada riwayat penukaran hadiah
ALTER TABLE reward_redemptions
ADD COLUMN IF NOT EXISTS category TEXT;

-- 2. Tabel Katalog Reward (Voucher, Cashback, Sembako, dll)
CREATE TABLE IF NOT EXISTS reward_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Lainnya', -- Voucher | Cashback | Sembako | Lainnya
  points_cost NUMERIC NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Seed data awal (menggantikan opsi hardcode yang sebelumnya ada di form)
INSERT INTO reward_catalog (name, category, points_cost, is_active)
VALUES
  ('Sembako (Beras 5kg)', 'Sembako', 50000, true),
  ('Sembako (Minyak Goreng 2L)', 'Sembako', 35000, true),
  ('Voucher Listrik Rp 50.000', 'Voucher', 50000, true),
  ('Tarik Tunai', 'Cashback', 10000, true)
ON CONFLICT DO NOTHING;

-- 3. Tabel Referral Program
CREATE TABLE IF NOT EXISTS referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
  referred_name TEXT NOT NULL,
  referred_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  bonus_points NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Menunggu', -- Menunggu | Disetujui | Ditolak
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
