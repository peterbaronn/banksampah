-- Jalankan ini sekali di Supabase SQL Editor
-- untuk mengaktifkan fitur Segmentasi Pelanggan di modul
-- Customer Data Management.

ALTER TABLE customers
ADD COLUMN IF NOT EXISTS segment TEXT;

-- (Opsional) beri nilai default untuk data lama yang belum punya segmen
UPDATE customers
SET segment = 'Rumah Tangga'
WHERE segment IS NULL;
