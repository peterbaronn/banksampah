-- ============================================================
-- Migration: Customer Service Management (Admin)
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Tabel faqs (dikelola Admin, ditampilkan di Portal Nasabah)
--   2. Tabel chatbot_rules (aturan balasan chatbot, dikelola Admin)
-- ============================================================

-- 1. FAQ yang dikelola Admin
CREATE TABLE IF NOT EXISTS faqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  is_published BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO faqs (question, answer, sort_order)
VALUES
  ('Bagaimana cara menyetor sampah?', 'Pisahkan sampah sesuai kategori (plastik, kertas, logam, kaca, minyak jelantah), lalu ajukan booking penjemputan lewat menu Jemput, atau datang langsung ke kantor Bank Sampah.', 1),
  ('Kapan saldo saya cair?', 'Saldo otomatis bertambah setelah petugas mengonfirmasi transaksi setoran berstatus ''Selesai''. Anda bisa memantaunya di menu Transaksi.', 2),
  ('Bagaimana cara menukar poin reward?', 'Buka menu Hadiah, pilih hadiah yang diinginkan (voucher, cashback, atau sembako), lalu ajukan klaim. Admin akan memverifikasi sebelum hadiah diserahkan.', 3),
  ('Apa itu Membership Level?', 'Tier keanggotaan (Bronze, Silver, Gold, Platinum) yang naik otomatis berdasarkan akumulasi saldo yang Anda kumpulkan dari setoran sampah.', 4),
  ('Bagaimana cara mengajukan komplain?', 'Buka menu Profil > Pengaduan, isi formulir keluhan, dan pantau statusnya di halaman yang sama.', 5)
ON CONFLICT DO NOTHING;

-- 2. Aturan Balasan Chatbot (keyword -> response)
CREATE TABLE IF NOT EXISTS chatbot_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  keyword TEXT NOT NULL, -- kata kunci, dipisah koma jika lebih dari satu, contoh: "jadwal,jemput"
  response TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO chatbot_rules (keyword, response)
VALUES
  ('jadwal,jemput', 'Untuk booking penjemputan, silakan buka menu Jemput dan isi tanggal serta waktu yang Anda inginkan.'),
  ('saldo', 'Saldo Anda bisa dicek di halaman Beranda atau menu Transaksi. Saldo bertambah setelah setoran berstatus Selesai.'),
  ('poin,reward,hadiah', 'Poin reward bisa ditukarkan di menu Hadiah. Semakin banyak setoran, semakin tinggi tier membership Anda.'),
  ('setor,sampah', 'Pisahkan sampah sesuai jenisnya, lalu ajukan booking penjemputan lewat menu Jemput, atau antar langsung ke kantor kami.'),
  ('komplain,pengaduan,keluhan', 'Anda bisa mengajukan pengaduan di menu Profil > Pengaduan. Tim kami akan menindaklanjuti secepatnya.')
ON CONFLICT DO NOTHING;
