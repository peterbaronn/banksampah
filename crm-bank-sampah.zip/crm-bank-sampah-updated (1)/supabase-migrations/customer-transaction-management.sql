-- ============================================================
-- Migration: Customer Transaction Management (Admin)
-- Jalankan di Supabase SQL Editor (sekali saja).
-- Menambahkan:
--   1. Tabel waste_prices (Estimasi Harga Sampah, dikelola Admin)
--   2. Tabel withdrawals (Riwayat Penarikan Saldo)
-- ============================================================

-- 1. Daftar harga sampah per kg (dikelola Admin, dipakai untuk
-- estimasi harga & auto-hitung saldo saat mencatat transaksi)
CREATE TABLE IF NOT EXISTS waste_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  waste_type TEXT NOT NULL UNIQUE,
  price_per_kg NUMERIC NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO waste_prices (waste_type, price_per_kg)
VALUES
  ('Plastik PET', 3000),
  ('Kertas / Kardus', 1500),
  ('Logam / Kaleng', 5000),
  ('Kaca / Beling', 800),
  ('Minyak Jelantah', 4000)
ON CONFLICT (waste_type) DO NOTHING;

-- 2. Riwayat Penarikan Saldo Digital nasabah (terpisah dari
-- penukaran poin/hadiah di Loyalty Program)
CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL DEFAULT 0,
  method TEXT NOT NULL DEFAULT 'Tunai', -- Tunai | Transfer Bank
  status TEXT NOT NULL DEFAULT 'Menunggu', -- Menunggu | Disetujui | Ditolak
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
